#!/usr/bin/env python3
"""출력 비활성 sensor_link 앱의 단일 UART 소유자. 모터 DRIVE 전송을 허용하지 않는다."""
import argparse
from collections import Counter
import gc
import json
from pathlib import Path
import time

from arena_vehicle_interface.actuation_wire import Decoder as ControlDecoder, encode
from arena_vehicle_interface.sensor_link_wire import SensorLinkDecoder
from arena_vehicle_interface.imu_read_clock import ImuReadClock
from probe_esp32_imu import Decoder as ImuDecoder


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--port',required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--seconds',type=float,default=20.)
    args=p.parse_args()
    if not 1<=args.seconds<=120: p.error('seconds outside 1..120')
    import serial
    import rclpy
    from rclpy.node import Node
    from rclpy.qos import qos_profile_sensor_data
    from sensor_msgs.msg import Imu
    from std_msgs.msg import UInt8MultiArray, String
    args.output.mkdir(parents=True,exist_ok=False)
    rclpy.init(args=[]); node=Node('sensor_link_preview')
    if node.get_parameter('use_sim_time').value: raise RuntimeError('wall clock required')
    pub=node.create_publisher(Imu,'/hardware_preview/imu',qos_profile_sensor_data)
    rx=node.create_publisher(UInt8MultiArray,'/actuation/rx',10)
    status=node.create_publisher(String,'/hardware_preview/imu_status',10)
    wire=SensorLinkDecoder(); imu=ImuDecoder(); control=ControlDecoder(); tx=ControlDecoder()
    clock=ImuReadClock(); counts=Counter(); boots=set(); offer_boots=set(); complete=False
    link=serial.Serial(port=None,baudrate=921600,timeout=.002,write_timeout=.2)
    link.dtr=False;link.rts=False;link.port=args.port
    was_gc=gc.isenabled(); began=time.monotonic(); last_status=0.; error=None
    with (args.output/'uart.bin').open('xb') as raw, (args.output/'imu.jsonl').open('x') as frames, \
            (args.output/'control.jsonl').open('x') as operations:
        def outgoing(message):
            # 진단 앱에는 출력 코드가 없지만 호스트 송신도 명시 제어 네 종류로 한정한다.
            for payload in tx.feed(bytes(message.data)):
                command=payload.get('command',{})
                if payload.get('type')!='command' or command.get('kind') not in ('ARM','CLEAR','DISARM','STOP'):
                    counts['tx_rejected']+=1; continue
                packet=encode(payload)
                written=link.write(packet)
                if written!=len(packet): raise RuntimeError('partial serial write')
                counts['tx_'+command['kind']]+=1
                operations.write(json.dumps(dict(direction='tx',host_ns=time.monotonic_ns(),payload=payload))+'\n')
        node.create_subscription(UInt8MultiArray,'/actuation/tx',outgoing,10)
        def receive():
            nonlocal last_status
            data=link.read(max(1,min(link.in_waiting,8192)))
            mono=time.monotonic_ns(); ros=node.get_clock().now().nanoseconds
            raw.write(data); gyros=[]
            for kind,packet in wire.feed(data):
                if kind=='control':
                    for row in control.feed(packet):
                        counts['rx_'+row.get('type','unknown')]+=1
                        if row.get('type')=='offer':
                            offer_boots.add(row['boot'])
                            if row.get('output_ready') is not False: raise RuntimeError('output-enabled firmware is outside this preview')
                        operations.write(json.dumps(dict(direction='rx',host_ns=mono,payload=row))+'\n')
                    rx.publish(UInt8MultiArray(data=list(packet)))
                else:
                    for row in imu.feed(packet):
                        boots.add(row['boot'])
                        frames.write(json.dumps(dict(row,host_monotonic_ns=mono,host_ros_ns=ros))+'\n')
                        counts['imu_frames']+=1
                        if 'gyro_rad_s' in row:gyros.append(row)
            for stamp in clock.convert_batch(gyros,host_monotonic_ns=mono,ros_receipt_ns=ros):
                msg=Imu();msg.header.frame_id='lsm6dsox_sensor'
                msg.header.stamp.sec,msg.header.stamp.nanosec=divmod(stamp.stamp_ns,1_000_000_000)
                msg.orientation_covariance[0]=-1.;msg.linear_acceleration_covariance[0]=-1.
                msg.angular_velocity.x,msg.angular_velocity.y,msg.angular_velocity.z=stamp.sample['gyro_rad_s']
                pub.publish(msg);counts['gyro_published']+=1
            now=time.monotonic()
            if now-last_status>=1.:
                status.publish(String(data=json.dumps(dict(time_basis=clock.time_basis,time_contract_verified=False,
                    sensor_acquisition_timestamp=False,mounting_calibrated=False,counts=dict(counts)))))
                last_status=now
            rclpy.spin_once(node,timeout_sec=0.)
        try:
            link.open();gc.disable()
            (args.output/'ready').write_text('serial owner ready')
            while time.monotonic()-began<args.seconds:receive()
            complete=True
        except BaseException as exc:
            error=type(exc).__name__+': '+str(exc);raise
        finally:
            try:
                if link.is_open:
                    outgoing(UInt8MultiArray(data=list(encode(dict(type='command',request='preview-final-stop',command=dict(v=1,kind='STOP'))))))
                    until=time.monotonic()+.5
                    while time.monotonic()<until:receive()
            finally:
                link.close()
                if was_gc:gc.enable()
                result=dict(complete=complete,error=error,duration_s=time.monotonic()-began,counts=dict(counts),
                    wire=dict(wire.counters),imu_decoder=dict(imu.counters),control_errors=control.errors,
                    tx_decode_errors=tx.errors,clock=dict(clock.counts),imu_boots=sorted(boots),offer_boots=sorted(offer_boots),
                    matching_boot=bool(boots) and {format(b,'08x') for b in boots}==offer_boots,
                    time_contract_verified=False,mounting_calibrated=False,drive_output=False)
                (args.output/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
                node.destroy_node();rclpy.shutdown()
    print(json.dumps(result))


if __name__=='__main__':main()
