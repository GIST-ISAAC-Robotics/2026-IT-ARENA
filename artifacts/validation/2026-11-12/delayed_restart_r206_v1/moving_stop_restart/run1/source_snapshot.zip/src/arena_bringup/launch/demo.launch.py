"""빨간 신호 대기 후 본선을 계속 도는 단일 차량 기초 데모."""
from pathlib import Path

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, OpaqueFunction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import SetParameter


def _include_simulation(context):
    launch_file = Path(get_package_share_directory("arena_bringup")) / "launch/simulation.launch.py"
    mode = LaunchConfiguration("autonomy_mode").perform(context)
    depth = LaunchConfiguration("depth_camera").perform(context)
    if depth == "auto":
        depth = "true" if mode == "stereo" else "false"
    if mode == "stereo" and depth != "true":
        raise RuntimeError("stereo 모드는 depth_camera:=true가 필요합니다.")
    return [IncludeLaunchDescription(PythonLaunchDescriptionSource(str(launch_file)), launch_arguments={
        "headless": LaunchConfiguration("headless"), "grid_slot": LaunchConfiguration("grid_slot"),
        "render_backend": LaunchConfiguration("render_backend"),
        "collision_detector": LaunchConfiguration("collision_detector"),
        "scene_broadcaster": LaunchConfiguration("scene_broadcaster"),
        "red_duration_s": LaunchConfiguration("red_duration_s"), "track": LaunchConfiguration("track"),
        "depth_camera": depth,
        "tof_profile": LaunchConfiguration("tof_profile"),
        "lidar_rate_hz": LaunchConfiguration("lidar_rate_hz"),
        "lidar_acquisition": LaunchConfiguration("lidar_acquisition"),
        "lidar_test_profile": LaunchConfiguration("lidar_test_profile"),
        "motion_test_profile": LaunchConfiguration("motion_test_profile"),
        "local_sensor_config": LaunchConfiguration("local_sensor_config"),
        "pilot_marker_z": LaunchConfiguration("pilot_marker_z"),
        "lidar_compensation": LaunchConfiguration("lidar_compensation"),
        "autonomy_control_rate_hz": LaunchConfiguration("autonomy_control_rate_hz"),
        "sensor_wall_timeout_s": LaunchConfiguration("sensor_wall_timeout_s"),
        "speed_profile": LaunchConfiguration("speed_profile"),
        "differential_profile": LaunchConfiguration("differential_profile"),
        "tof_safety": LaunchConfiguration("tof_safety"),
        "drive_mode": LaunchConfiguration("drive_mode"),
        "autonomy_mode": mode,
        "actuation_mode": LaunchConfiguration("actuation_mode"),
        "timing_probe": LaunchConfiguration("timing_probe"),
        "chase_camera": LaunchConfiguration("chase_camera"),
        "speed_bump": LaunchConfiguration("speed_bump"),
        "runtime_artifacts": LaunchConfiguration("runtime_artifacts"),
        "evaluation_course_markers": LaunchConfiguration("evaluation_course_markers"),
        "batch_static_visuals": LaunchConfiguration("batch_static_visuals"),
        "d435i_profile": "low_load_30", "autonomy": "true", "traffic_light": "true",
    }.items())]


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('g1_parallel_hold_trial', default_value='false', choices=['true', 'false']),
        SetParameter(name='g1_parallel_hold_trial', value=LaunchConfiguration('g1_parallel_hold_trial')),
        DeclareLaunchArgument('g1_pass_release_trial', default_value='false', choices=['true', 'false']),
        SetParameter(name='g1_pass_release_trial', value=LaunchConfiguration('g1_pass_release_trial')),
        DeclareLaunchArgument('g1_guard_curve_trial', default_value='false', choices=['true', 'false']),
        DeclareLaunchArgument('g1_traffic_recovery_trial', default_value='false', choices=['true', 'false']),
        DeclareLaunchArgument('g1_traffic_path_recovery_trial', default_value='false', choices=['true', 'false']),
        SetParameter(name='g1_guard_curve_trial', value=LaunchConfiguration('g1_guard_curve_trial')),
        SetParameter(name='g1_traffic_recovery_trial', value=LaunchConfiguration('g1_traffic_recovery_trial')),
        SetParameter(name='g1_traffic_path_recovery_trial', value=LaunchConfiguration('g1_traffic_path_recovery_trial')),
        DeclareLaunchArgument('partial_observation_policy', default_value='strict',
                              choices=['strict', 'bounded_side_v1', 'bounded_local_v2', 'bounded_local_v3', 'bounded_local_v4']),
        SetParameter(name='partial_observation_policy', value=LaunchConfiguration('partial_observation_policy')),
        DeclareLaunchArgument('actuation_mode', default_value='legacy', choices=['legacy', 'virtual_mcu']),
        DeclareLaunchArgument('timing_probe', default_value='false', choices=['true', 'false']),
        DeclareLaunchArgument("headless", default_value="false"),
        DeclareLaunchArgument("render_backend", default_value="system", choices=["auto", "system", "wsl_nvidia", "software"]),
        DeclareLaunchArgument("collision_detector", default_value="configured", choices=["configured", "ode", "bullet", "fcl"]),
        DeclareLaunchArgument("scene_broadcaster", default_value="true"),
        DeclareLaunchArgument("grid_slot", default_value="0"),
        DeclareLaunchArgument("red_duration_s", default_value="8.0"),
        DeclareLaunchArgument("track", default_value="official", choices=["official", "official_v2026_11_06"],
                              description="공식 2×5 신호 팀 파생 월드. 기본은 기존 v2026.11.01 파생본"),
        DeclareLaunchArgument("autonomy_mode", default_value="lidar", choices=["lidar", "stereo", "local_pursuit"],
                              description="lidar=C1+ToF6, stereo=전방 D435i 깊이+측면 ToF4"),
        DeclareLaunchArgument("depth_camera", default_value="auto", choices=["auto", "true", "false"],
                              description="auto는 stereo에서 켜고 lidar에서 끕니다."),
        DeclareLaunchArgument("chase_camera", default_value="false", description="검증 영상 전용 3인칭 카메라"),
        DeclareLaunchArgument("tof_profile", default_value="configured", description="하부 ToF 영역·주기 프로필"),
        DeclareLaunchArgument("lidar_rate_hz", default_value="configured", description="라이다 주기 비교용 실행 덮어쓰기"),
        DeclareLaunchArgument("lidar_acquisition", default_value="snapshot", choices=["snapshot", "sequential"]),
        DeclareLaunchArgument("lidar_test_profile", default_value="", description="명시적 시험용 거리오차/지연 JSON"),
        DeclareLaunchArgument("motion_test_profile", default_value="", description="시험 전용 IMU/엔코더 오차 JSON"),
        DeclareLaunchArgument("local_sensor_config", default_value="", description="local_pursuit 센서/장착 YAML 선택"),
        DeclareLaunchArgument("pilot_marker_z", default_value="", description="파일럿 전용 ID49 판 중심 높이 덮어쓰기"),
        DeclareLaunchArgument("lidar_compensation", default_value="none", choices=["none", "deskew", "shift", "both"]),
        DeclareLaunchArgument("autonomy_control_rate_hz", default_value="20.0", description="단독 고속 시험용 제어 주기; 기본 20 Hz 유지"),
        DeclareLaunchArgument("sensor_wall_timeout_s", default_value="3.0", description="느린 오프라인 시뮬레이션용 벽시계 감시 한도; 센서 취득 시각 제한은 유지"),
        DeclareLaunchArgument("speed_profile", default_value="cautious"),
        DeclareLaunchArgument("differential_profile", default_value="configured"),
        DeclareLaunchArgument("tof_safety", default_value="true"),
        DeclareLaunchArgument("drive_mode", default_value="configured"),
        DeclareLaunchArgument("speed_bump", default_value="true"),
        DeclareLaunchArgument("runtime_artifacts", default_value=""),
        DeclareLaunchArgument('evaluation_course_markers', default_value='visible', choices=['visible','blank_30','blank_20_30','blank_all']),
        DeclareLaunchArgument("batch_static_visuals", default_value="false"),
        OpaqueFunction(function=_include_simulation),
    ])
