"""선택형 시험: 후방으로 사라진 옆 위협 쪽으로의 중앙 복귀를 해제 직후 짧게 보류한다. 기본 OFF.

`rear`/`unknown`으로 사라진 쪽을 기존 확장 측방 창으로 해제한 뒤 `hold_s` 동안, 기존 RELEASED 선택이
기존 G1 출력을 고르고 그 출력의 현재/직전 조향 원호에서 그쪽 차체 모서리의 경로 횡위치가 해제 때
기준과 현재 중 큰 값보다 조금이라도 커지면(누적 접근 포함) 같은 호출의 평행 후보 출력을 쓴다. GUARD 곡선 후보의
1 cm 허용을 쓰지 않는 이유: 1 cm 아래의 첫 복귀 조향이 적용되면 다음 호출의 평행 후보가 직전 조향 원호의
1 cm 횡변위 검사로 진행 불가가 되어 보류가 시작되지 못했다(합성 복합 오차 B). 평행 후보도 정지하지 않는 후보다.
횡위치는 앞 두 모서리로 잰다. 반대쪽으로 꺾을 때 뒤 돌출부가 그쪽으로 최대 약 1.25 mm 흔들리는 것을 접근으로
세지 않기 위한 것이며, 전진 중 그쪽으로의 복귀·방향 편차는 앞 모서리가 먼저 드러낸다.
평행 후보는 현재 횡위치 유지·0.35 m/s 상한·점유·1 cm 횡변위 검사를 그대로 받는다. 평행 후보가 진행할 수
없으면(곡선·부분 관측·간격 정지·출발 대기) 기존 RELEASED 판단을 바꾸지 않는다. 평행 후보가 min(G1, 0.35 m/s)보다
느리면(유지한 차선 쪽 관측 점유가 더 가까움) 그 해제의 보류를 끝내고 기존 판단으로 돌아간다. 유지할 차선의
반대쪽 옆·앞(2.5 m 스윕 범위)에 차체 옆면 밖 관측 반환이 현재 점유 팽창 + 물체 이동 상한×스캔 길이 안에 있어도
보류를 끝낸다. 같은 종방향 위치(차체 길이 안)에 통로 안쪽 반환도 있는 물체(앞차처럼 통로를 가로막는 물체)는
추종 대상이므로 세지 않는다. 다음 스캔 전 팽창이 커져 기존 간격 정지/재출발 확인이 반복되는 근접 물체 옆에 차선을
묶지 않기 위한 것이다. 확인된 점유를 숨은 후방 가능성보다 앞세우며, 차선 유지가 기존 판단보다 더 막히는 상태를 만들지 않는다.
보류는 원래 선택기의 고정 `rear` 기록이 아니라 이번에 사라진 방향(마지막 관측의 최후단이 앞면+여유보다 뒤,
또는 시간 단절 뒤 unknown)으로 정한다. 앞으로 지나간 물체에는 걸지 않는다. 새 정지·새 경로·자유 공간을
만들지 않고, 위협·통과 기록·창 확인·영역 검사·고장 처리는 원래 선택기가 수행한다.

입력은 기존 선택기와 같은 현재 장면 시각과 기존 G1 경로뿐이다. 지도·actor 정답·그리드는 쓰지 않는다.
숨은 차량의 부재 증명이 아니며 보류 시간 뒤의 재접근 위험과 곡선에서의 복귀 위험은 그대로 남는다.
"""
from dataclasses import dataclass
import math

import numpy as np

import arena_autonomy.m3_execution_trial as mx
from arena_autonomy.m3_observed_follow import command_arc
from arena_autonomy.pass_release_trial import SIDES, extrema_arc

# parallel_lane_trial.proposal의 swept_limit(horizon=2.5)와 같은 범위. 새 근거값이 아니다.
SWEPT_HORIZON_M = 2.5
from arena_autonomy.traffic_path_recovery_trial import SuspendedPassageSelector


@dataclass(frozen=True)
class LaneKeepConfig:
    # 기존 운동 이력 보존 길이(MotionConfig.history_s 2.0 s)와 같게 둔 개발 시험값.
    # 과거 경로 좌표의 횡위치를 비교하는 기간의 상한이며 숨은 차량의 재접근 시각에 대한 근거가 아니다.
    hold_s: float = 2.

    def __post_init__(self):
        if isinstance(self.hold_s, bool) or not math.isfinite(self.hold_s) or not 0 < self.hold_s <= 2.:
            raise ValueError('lane keep hold must be finite, positive and within the motion history')


def front_extent(frame, poses, sign, cfg):
    """경로 좌표에서 차체 앞 두 모서리의 한쪽 방향 최대 횡위치. 표본 자세 사이 연속 극값 인증은 아니다."""
    p = np.asarray(poses, dtype=float).reshape(-1, 3)
    corner = np.array([[cfg.length_m/2, y] for y in (-cfg.width_m/2, cfg.width_m/2)])
    c, s = np.cos(p[:, 2])[:, None], np.sin(p[:, 2])[:, None]
    points = np.stack((p[:, :1]+c*corner[None, :, 0]-s*corner[None, :, 1],
                       p[:, 1:2]+s*corner[None, :, 0]+c*corner[None, :, 1]), axis=-1).reshape(-1, 2)
    _, lateral = frame.project(points)
    return float(np.max(sign*lateral))


class RearLaneKeepSelector(SuspendedPassageSelector):
    def _opposite_near(self, scene, p_detail, toward):
        """유지할 평행 경로의 반대쪽 옆면 밖 근접 관측 반환 수. 경로가 없으면 None."""
        trial = p_detail.get('parallel_hold_trial') or {}
        path, padding = trial.get('path_points'), trial.get('maximum_padding_m')
        if path is None or len(path) < 2 or padding is None or not math.isfinite(padding):
            return None
        try:
            frame = mx.ExecutionFrame(np.asarray(path, dtype=float).reshape(-1, 2))
        except (ValueError, TypeError):
            return None
        points = np.asarray(scene.occupied_endpoints_xy_m, dtype=float).reshape(-1, 2)
        span = scene.rays[-1].acquired_at_s-scene.source_first_s
        margin = float(padding)+self.follow_config.object_motion_bound_mps*max(0., span)
        result = {'count': 0, 'margin_m': margin, 'horizon_m': SWEPT_HORIZON_M}
        if not len(points):
            return result
        s, l = frame.project(points)
        half, length = self.follow_config.width_m/2, self.follow_config.length_m
        window = (s >= -length/2) & (s <= SWEPT_HORIZON_M)
        inside = s[window & (np.abs(l) <= half)]
        for name in toward:
            opposite = -dict(SIDES)[name]
            exterior = opposite*l-half
            mask = window & (exterior > 1e-9) & (exterior < margin)
            if len(inside) and np.any(mask):
                # 통로 안쪽 반환과 같은 종방향 위치의 가장자리는 통로를 가로막는 물체(추종 대상)의 일부로 본다.
                blocked = np.min(np.abs(s[mask][:, None]-inside[None, :]), axis=1) <= length
                mask[np.flatnonzero(mask)[blocked]] = False
            result['count'] += int(np.sum(mask))
        return result

    def __init__(self, follow_config, config=None, lane_keep=None):
        self.lane_keep_config = lane_keep or LaneKeepConfig()
        super().__init__(follow_config, config)

    def reset(self):
        self.lane_keep = {}
        self.last_direction = {}
        super().reset()

    def invalidate(self, reason):
        # 시간 연결을 잃으면 원래 선택기가 양쪽을 unknown으로 둔다. 새 해제 때 기준을 다시 잡는다.
        self.lane_keep = {}
        sides = getattr(self, 'sides', {})
        # 원래 선택기와 같이 위협을 본 적이 있으면 양쪽 모두 방향을 모르는 소실로 둔다.
        self.last_direction = ({name: 'unknown' for name in sides}
                               if any(side['seen'] for side in sides.values()) else {})
        return super().invalidate(reason)

    def _select(self, scene, baseline, parallel, speed, previous, dt, *, raw_scan=None):
        released_before = {name: side['seen'] and side['passed'] and not side['present']
                           for name, side in self.sides.items()}
        present_before = {name: side['present'] for name, side in self.sides.items()}
        output = super()._select(scene, baseline, parallel, speed, previous, dt, raw_scan=raw_scan)
        front = self.follow_config.length_m/2+self.config.pass_front_margin_m
        for name, side in self.sides.items():
            if side['present']:
                self.last_direction[name] = None
            elif present_before[name] and side['seen']:
                if side['last_present'] is None:
                    # 시간 단절(invalidate)로 사라졌다. 방향을 모른다.
                    self.last_direction[name] = 'unknown'
                    continue
                # 원래 선택기와 같은 기준으로 이번 소실 방향만 따로 기록한다(원래 vanish 기록은 바꾸지 않음).
                rear = side['last_present'].get('rearmost_ds_m')
                self.last_direction[name] = 'forward' if rear is not None and rear >= front else 'rear'
        now = scene.t_ref_s
        frame = None
        path = baseline[2].get('path_points')
        try:
            if path is not None and len(path) >= 2:
                frame = mx.ExecutionFrame(np.asarray(path, dtype=float).reshape(-1, 2))
        except (ValueError, TypeError):
            frame = None
        for name, sign in SIDES:
            side = self.sides[name]
            released = side['seen'] and side['passed'] and not side['present']
            if (not released or side['vanish'] not in ('rear', 'unknown')
                    or self.last_direction.get(name) not in ('rear', 'unknown')):
                self.lane_keep.pop(name, None)
                continue
            if name not in self.lane_keep and not released_before[name] and frame is not None:
                # 이번 호출에서 처음 해제됐다. 해제 시 차체 모서리의 경로 횡위치를 기준으로 둔다.
                self.lane_keep[name] = {'released_s': now, 'vanish': side['vanish'],
                                        'direction': self.last_direction.get(name),
                                        'anchor_m': front_extent(frame, [[0., 0., 0.]], sign, self.lat)}
        for name in [n for n, r in self.lane_keep.items() if not 0 <= now-r['released_s'] <= self.lane_keep_config.hold_s]:
            self.lane_keep.pop(name)
        info = {'active_sides': sorted(self.lane_keep), 'hold_s': self.lane_keep_config.hold_s,
                'unknown_filled': False, 'hidden_rear_risk_unresolved': True, 'applied': False}
        detail = output[2]
        if (not self.lane_keep or detail.get('selector_mode') != 'RELEASED'
                or detail.get('selector_choice') != 'baseline' or not output[0] > 0):
            return output[0], output[1], {**detail, 'rear_lane_keep': info}
        if frame is None:
            info['reason'] = 'no_baseline_frame'
            return output[0], output[1], {**detail, 'rear_lane_keep': info}
        age = scene.t_ref_s-scene.source_first_s
        v = max(speed, output[0])
        distance = mx.envelope_distance(v, age, dt, mx.ExecutionConfig())
        poses = np.vstack([np.vstack((command_arc(a, max(distance, .01), self.lat),
                                      extrema_arc(a, max(distance, .01), self.lat)))
                           for a in sorted({float(output[1]), float(previous)})])
        toward = []
        for name, sign in SIDES:
            record = self.lane_keep.get(name)
            if record is None:
                continue
            current = front_extent(frame, [[0., 0., 0.]], sign, self.lat)
            predicted = front_extent(frame, poses, sign, self.lat)
            info.setdefault('sides', {})[name] = {**record, 'current_m': current, 'predicted_m': predicted}
            if predicted > max(record['anchor_m'], current)+1e-9:
                toward.append(name)
        info['toward_sides'] = toward
        if not toward:
            info['reason'] = 'not_toward_recent_rear_side'
            return output[0], output[1], {**detail, 'rear_lane_keep': info}
        p_speed, p_steer, p_detail = parallel
        info.update(baseline_clearance_m=baseline[2].get('swept_clearance_m'),
                    parallel_clearance_m=(p_detail.get('parallel_hold_trial') or {}).get('clearance_m'),
                    parallel_speed_mps=p_speed, parallel_reason=p_detail.get('reason'),
                    parallel_trial_reason=(p_detail.get('parallel_hold_trial') or {}).get('reason'))
        if not p_speed > 0:
            # 현재 위치 유지가 진행할 수 없으면 기존 판단을 쓴다(새 정지 금지).
            info['reason'] = 'parallel_not_moving_keep_original'
            return output[0], output[1], {**detail, 'rear_lane_keep': info}
        if p_speed < min(output[0], self.config.guard_speed_cap_mps)-1e-6:
            # 유지한 차선 쪽 관측 점유가 더 가깝다. 이 해제의 보류를 끝낸다(다음 해제 때 새 기준).
            for name in toward:
                self.lane_keep.pop(name, None)
            info.update(reason='parallel_slower_end_hold', ended_sides=toward)
            return output[0], output[1], {**detail, 'rear_lane_keep': info}
        near = self._opposite_near(scene, p_detail, toward)
        info['opposite_near_returns'] = near
        if near is None or near['count']:
            for name in toward:
                self.lane_keep.pop(name, None)
            info.update(reason='opposite_near_occupancy_end_hold' if near else 'parallel_path_unavailable_end_hold',
                        ended_sides=toward)
            return output[0], output[1], {**detail, 'rear_lane_keep': info}
        info.update(applied=True, reason='parallel_lane_keep', replaced_speed_mps=output[0],
                    replaced_steering_rad=output[1])
        selector = {k: v for k, v in detail.items() if k.startswith('selector_') or k in (
            'pass_release_trial', 'retained_passage', 'same_path_gap', 'suspended_passage_history',
            'restored_passage_history', 'restored_history_is_current_free_space')}
        return p_speed, p_steer, {**p_detail, **selector, 'selector_choice': 'parallel',
                                  'selector_reason': 'released_recent_rear_lane_keep', 'rear_lane_keep': info}
