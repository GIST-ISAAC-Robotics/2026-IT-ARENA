"""직각 경로의 기하·관측 범위와 옵션 OFF 재현성."""
import numpy as np
import pytest

from arena_autonomy.local_path import local_path
from arena_autonomy.piecewise_wall import corner_path
from arena_autonomy.local_follow import FollowConfig


def polyline(*vertices):
    return np.vstack([np.linspace(a, b, max(6, int(np.linalg.norm(np.array(b)-a)/.02)+1))[:-1]
                      for a, b in zip(vertices, vertices[1:])] + [np.array(vertices[-1:])])


@pytest.mark.parametrize('mirror', [1, -1])
def test_inner_outer_corner_agree_and_respect_steering(mirror):
    inner = polyline([-.4, .505], [.5, .505], [.5, 2.0])*[1, mirror]
    outer = polyline([-.4, -.505], [1.51, -.505], [1.51, 2.0])*[1, mirror]
    p = corner_path(inner, 'left' if mirror == 1 else 'right', .505, .347)
    q = corner_path(outer, 'right' if mirror == 1 else 'left', .505, .347)
    assert p is not None and q is not None
    assert np.max(np.linalg.norm(p-q, axis=1)) < .025
    assert np.min(np.diff(p[:, 0])) > -1e-9
    assert np.min(mirror*np.diff(p[:, 1])) > -1e-9
    arc = p[(p[:, 0] > .52) & (mirror*p[:, 1] < .48)]
    assert np.max(np.abs(np.linalg.norm(arc-[.5, mirror*.505], axis=1)-.505)) < .002
    assert corner_path(outer, 'right' if mirror == 1 else 'left', .505, .6) is None


def test_clipped_corner_does_not_append_reverse_segment():
    cloud = polyline([.8, -.505], [1.51, -.505], [1.51, .2])
    path = corner_path(cloud, 'right', .505, .347)
    assert path is not None
    assert np.min(np.diff(path[:, 0])) >= -1e-9
    assert np.min(np.diff(path[:, 1])) >= -1e-9
    assert path[-1, 1] < .505  # observed outgoing face ends before the arc tangent


@pytest.mark.parametrize('vertices', [
    [[-.4, -.505], [2., -.505]],
    [[-.4, -.505], [.8, -.505], [.8, -.42]],
    [[-.4, -.505], [.8, -.505], [.8, .5], [1.5, .5]],
])
def test_no_invented_corner_from_straight_short_or_multiple_faces(vertices):
    assert corner_path(polyline(*vertices), 'right', .505, .347) is None


def test_straight_and_default_output_unchanged_and_missing_wall_is_not_filled():
    cloud = polyline([-.4, -.505], [2., -.505])
    old, old_info = local_path(cloud, 'right', .505)
    trial, info = local_path(cloud, 'right', .505, piecewise_corner=True, minimum_radius=.347)
    np.testing.assert_array_equal(old, trial)
    assert old_info == info
    assert local_path(cloud, 'left', .505, piecewise_corner=True)[0] is None
    assert FollowConfig().piecewise_wall_trial is False
    with pytest.raises(ValueError, match='boolean'):
        FollowConfig(piecewise_wall_trial=1)
