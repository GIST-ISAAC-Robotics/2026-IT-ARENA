"""운행 연결 없는 저장 입력 후보. 무반환 폭의 평가 반경만 실제 제동 외곽으로 대조."""
from pathlib import Path
import types

ROOT=Path(__file__).resolve().parents[4]
PATH=ROOT/'src/arena_autonomy/arena_autonomy/partial_observation.py'
source=PATH.read_text(encoding='utf8')
old='radius=max(.6,.16+speed*(now-source+.10)+speed*speed/4)'
new='''radius=max(
                (math.hypot(length/2+.05,width/2+.05)
                 +math.hypot(history.config.lidar_x_m,history.config.lidar_y_m)
                 +(1+max(abs(math.tan(steering)),abs(math.tan(previous_steering)))/2)
                   *(speed*(now-source+.10)+speed*speed/4+.06))
                    if self.oblique_metric_enabled else .6,
                .16+speed*(now-source+.10)+speed*speed/4)'''
assert source.count(old)==1
module=types.ModuleType('arena_autonomy.partial_observation_candidate')
module.__package__='arena_autonomy'
exec(compile(source.replace(old,new),str(PATH)+'_artifact_candidate','exec'),module.__dict__)
Candidate=module.PartialObservationPolicy
