"""한 모서리 경로의 앵커 오차: 원호 위 차량은 벽 y좌표 대신 생성 경로까지의 거리로 판정한다."""
import dataclasses
import importlib.util
import math
import zipfile
from pathlib import Path

import numpy as np
import pytest

from arena_autonomy.local_follow import FollowConfig, anchor_error
from arena_autonomy.local_path import local_path

ROOT = Path(__file__).resolve().parents[1]
BEFORE = ROOT/'artifacts/validation/2026-11-08/corner_path_anchor_v1/before.zip'
OFFSET, RADIUS = .505, .347
ON = dataclasses.replace(FollowConfig(), piecewise_wall_trial=True, wall_offset_m=OFFSET)
OFF = dataclasses.replace(ON, piecewise_wall_trial=False)


def polyline(*vertices):
    return np.vstack([np.linspace(a, b, max(6, int(np.linalg.norm(np.array(b)-a)/.02)+1))[:-1]
                      for a, b in zip(vertices, vertices[1:])] + [np.array(vertices[-1:])])


def corner_scan(mirror, degrees, lateral=0.):
    """바깥 직각 벽을 원호 경로 중간의 차량 좌표로 옮긴다. lateral은 원호 법선 방향 이탈(+는 바깥)."""
    wall = polyline([-1., -.505], [1.51, -.505], [1.51, 3.])*[1, mirror]
    a = math.radians(degrees)
    center = np.array([.5, .505*mirror])  # 오프셋 0.505 경로의 원호 중심. 반경도 0.505다.
    radial = np.array([math.sin(a), -mirror*math.cos(a)])
    pose = center+(OFFSET+lateral)*radial
    h = mirror*a
    rotation = np.array([[math.cos(h), math.sin(h)], [-math.sin(h), math.cos(h)]])
    return (wall-pose)@rotation.T, pose, center


def old_local_path():
    spec = importlib.util.spec_from_loader('before_local_path', loader=None)
    module = importlib.util.module_from_spec(spec)
    with zipfile.ZipFile(BEFORE) as archive:
        exec(archive.read('src/arena_autonomy/arena_autonomy/local_path.py').decode('utf-8'), module.__dict__)
    return module.local_path


@pytest.mark.parametrize('mirror', [1, -1])
@pytest.mark.parametrize('degrees', [35, 40])
def test_vehicle_on_arc_passes_anchor_although_wall_y_exceeds_offset(mirror, degrees):
    side = 'right' if mirror == 1 else 'left'
    cloud, pose, center = corner_scan(mirror, degrees)
    raw = cloud.copy()
    path, info = local_path(cloud, side, OFFSET, piecewise_corner=True, minimum_radius=RADIUS)
    np.testing.assert_array_equal(cloud, raw)  # 측정 벡터를 바꾸지 않는다.
    assert info['wall_model'] == 'piecewise_corner'
    # 원 검사는 벽 y좌표만 본다. 원호 위에서는 오프셋+0.12를 넘는다.
    assert info['wall_distance_m'] >= OFFSET+ON.boundary_anchor_error_m
    assert anchor_error(info, OFF) == abs(info['wall_distance_m']-OFFSET) > ON.boundary_anchor_error_m
    # 실제 경로(회전된 직선+원호)와 원점의 거리. 세계 좌표 원호와 독립 대조한다.
    assert abs(np.linalg.norm(pose-center)-OFFSET) < 1e-9
    assert info['path_anchor_error_m'] < .01
    assert anchor_error(info, ON) == info['path_anchor_error_m'] <= ON.boundary_anchor_error_m
    assert info['boundary_observed_ahead_m'] >= ON.boundary_min_ahead_m
    # 경로·벽 거리·관측 길이 등 기존 출력은 수정 전 코드와 같고 진단 하나만 추가된다.
    old_path, old_info = old_local_path()(cloud, side, OFFSET, piecewise_corner=True, minimum_radius=RADIUS)
    np.testing.assert_array_equal(old_path, path)
    assert old_info == {k: v for k, v in info.items() if k != 'path_anchor_error_m'}


@pytest.mark.parametrize('mirror', [1, -1])
@pytest.mark.parametrize('lateral', [-.2, .2])
def test_vehicle_off_the_generated_path_is_rejected(mirror, lateral):
    side = 'right' if mirror == 1 else 'left'
    cloud, pose, center = corner_scan(mirror, 35, lateral)
    path, info = local_path(cloud, side, OFFSET, piecewise_corner=True, minimum_radius=RADIUS)
    assert info['wall_model'] == 'piecewise_corner'
    expected = abs(np.linalg.norm(pose-center)-OFFSET)  # 원호 구간 안이므로 원호까지의 거리
    assert abs(info['path_anchor_error_m']-expected) < .01
    assert anchor_error(info, ON) > ON.boundary_anchor_error_m


def test_straight_and_default_off_outputs_have_no_new_field():
    straight = polyline([-.4, -.505], [2., -.505])
    old, old_info = local_path(straight, 'right', OFFSET)
    trial, info = local_path(straight, 'right', OFFSET, piecewise_corner=True, minimum_radius=RADIUS)
    np.testing.assert_array_equal(old, trial)
    assert old_info == info and 'path_anchor_error_m' not in info and 'wall_model' not in info
    cloud, _, _ = corner_scan(1, 35)
    _, off_info = local_path(cloud, 'right', OFFSET)
    assert 'path_anchor_error_m' not in off_info and 'wall_model' not in off_info
    assert FollowConfig().piecewise_wall_trial is False
    assert FollowConfig().boundary_anchor_error_m == .12


@pytest.mark.parametrize('value', [math.nan, math.inf, -.01, None, 'x'])
def test_invalid_path_error_is_rejected_not_passed(value):
    info = {'wall_model': 'piecewise_corner', 'wall_distance_m': OFFSET, 'path_anchor_error_m': value}
    assert anchor_error(info, ON) == math.inf
    assert anchor_error(info, OFF) == 0.  # 기본 OFF 설정은 원 검사


@pytest.mark.parametrize('info', [
    {'wall_model': 'piecewise_corner', 'wall_distance_m': .70},  # 옛 기록/스텁: 새 필드 없음
    {'wall_distance_m': .70, 'path_anchor_error_m': 0.},  # 곡선 fallback에는 wall_model이 없다
    {'wall_model': 'other', 'wall_distance_m': .70, 'path_anchor_error_m': 0.},
])
def test_other_models_and_missing_field_keep_wall_distance_check(info):
    assert anchor_error(info, ON) == pytest.approx(.195)
    assert anchor_error(info, OFF) == pytest.approx(.195)
