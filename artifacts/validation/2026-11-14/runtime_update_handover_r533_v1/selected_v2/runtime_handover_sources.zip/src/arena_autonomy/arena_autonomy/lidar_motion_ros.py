"""벽 추종기와 독립 시험이 공유하는 엔코더/자이로 입력 어댑터.

`motion_feedback_mode`가 구동 피드백 표현을 고른다. `drive_motor_shaft`는 모터축
한 채널(/drive_motor/encoder)을 `motion_gear_ratio`로 나눠 평균 바퀴 속도만 얻는다.
기본값 `rear_wheel_pair_legacy`는 모드 매개변수가 없던 옛 기록·시험 재현용이며
현재 launch는 모드를 명시한다. 회전량은 두 모드 모두 IMU 자이로를 사용한다.
"""
import math
import time
from copy import copy

from rclpy.qos import qos_profile_sensor_data
from sensor_msgs.msg import Imu, JointState

from arena_autonomy.lidar_motion import MODES, MotionConfig, MotionHistory, MotionUnavailable
from arena_vehicle_interface.drive_feedback import (
    MODE_LEGACY, MODE_MOTOR, TOPIC_BY_MODE, parse_legacy_wheels, parse_motor_state, validate_mode,
)


def seconds(stamp):
    return stamp.sec + stamp.nanosec * 1e-9


def drain_ready_motion(subscriptions, *, budget_s=.002, max_messages=64, clock=time.monotonic):
    started=clock()
    counts=[0]*len(subscriptions)
    total=0
    exhausted=False
    while total<max_messages and clock()-started<budget_s:
        progress=False
        for i,sub in enumerate(subscriptions):
            if total>=max_messages or clock()-started>=budget_s:
                exhausted=True
                break
            # Humble Executor._take_subscription와 같은 take 경로. 변환 뒤
            # 기존 wrapper/엄격 검증을 전부 거친다. stamp/공백을 고치지 않는다.
            with sub.handle:
                item=sub.handle.take_message(sub.msg_type,sub.raw)
            if item is not None:
                sub.callback(item[0])
                counts[i]+=1
                total+=1
                progress=True
        if not progress:break
    elapsed=clock()-started
    return dict(counts=counts,total=total,duration_ms=elapsed*1000,
                bounded_stop=exhausted or total>=max_messages or elapsed>=budget_s)


class MotionInput:
    def __init__(self, node, mode=None, timing_verified=None, record=None):
        self.node, self.record = node, record
        declared = str((node.get_parameter("lidar_compensation") if node.has_parameter("lidar_compensation")
                        else node.declare_parameter("lidar_compensation", "none")).value)
        self.mode = declared if mode is None else mode
        if self.mode not in MODES:
            raise ValueError("unknown lidar_compensation")
        verified = bool(node.declare_parameter("motion_scan_timing_verified", False).value)
        self.verified = verified if timing_verified is None else timing_verified
        self.timing_policy = node.declare_parameter('motion_scan_time_policy', 'verified_only').value
        from arena_autonomy.execution_environment import validate_motion_time
        validate_motion_time(node, self.mode, self.verified, self.timing_policy)
        defaults = vars(MotionConfig())
        config = {name: (node.declare_parameter("motion_" + name, value).value if name == 'lidar_frame_id'
                         else float(node.declare_parameter("motion_" + name, value).value))
                  for name, value in defaults.items()}
        self.history = MotionHistory(MotionConfig(**config), scan_time_policy=self.timing_policy)
        # 실물 연결 시 장착 축과 함께 명시할 입력 frame 계약. 빈 문자열은 기존
        # bag/시뮬레이션 호환 경로이며 실제 frame 검증 완료라는 뜻이 아니다.
        self.expected_imu_frame = node.declare_parameter("motion_imu_frame_id", "").value
        if (not isinstance(self.expected_imu_frame, str)
                or len(self.expected_imu_frame) > 256
                or any(c.isspace() or not c.isprintable() for c in self.expected_imu_frame)):
            raise ValueError("motion_imu_frame_id must be an explicit frame name or empty legacy setting")
        # 차체 z축에 투영할 IMU 각속도. R_BI = Rz(yaw) Ry(pitch) Rx(roll).
        roll = float(node.declare_parameter("motion_imu_roll_rad", 0.).value)
        pitch = float(node.declare_parameter("motion_imu_pitch_rad", 0.).value)
        if not math.isfinite(roll) or not math.isfinite(pitch):
            raise ValueError("IMU 장착 각도는 유한해야 합니다.")
        self.axis = (-math.sin(pitch), math.cos(pitch) * math.sin(roll), math.cos(pitch) * math.cos(roll))
        # 현재 LSM6DSOX 구성의 ±500 dps에 맞춘 보수적 입력 경계다. 자동 교정이나
        # 정상 범위 안의 모든 이상치 검출기가 아니다. 원시 각 축을 투영 전에 검사한다.
        self.gyro_abs_limit = float(node.declare_parameter(
            "motion_gyro_abs_limit_rad_s", math.radians(500.)).value)
        if not math.isfinite(self.gyro_abs_limit) or self.gyro_abs_limit <= 0:
            raise ValueError("motion_gyro_abs_limit_rad_s must be finite and positive")
        # 실측 전 임시 이상치 게이트. 정상값을 지연/평활화하지 않으며, 거절한
        # 표본 뒤의 무제한 직전값 유지는 기존 운동 이력의 시간 제한이 막는다.
        self.gyro_slew_limit = float(node.declare_parameter("motion_gyro_slew_limit_rad_s2", 100.).value)
        self.gyro_step_slack = float(node.declare_parameter("motion_gyro_step_slack_rad_s", .05).value)
        if not math.isfinite(self.gyro_slew_limit) or self.gyro_slew_limit <= 0:
            raise ValueError("motion_gyro_slew_limit_rad_s2 must be finite and positive")
        if not math.isfinite(self.gyro_step_slack) or self.gyro_step_slack < 0:
            raise ValueError("motion_gyro_step_slack_rad_s must be finite and nonnegative")
        self.feedback_mode = validate_mode(str(node.declare_parameter("motion_feedback_mode", MODE_LEGACY).value))
        self.gear_ratio = float(node.declare_parameter("motion_gear_ratio", 0.).value)
        if self.feedback_mode == MODE_MOTOR and not (math.isfinite(self.gear_ratio) and self.gear_ratio > 0):
            raise ValueError("drive_motor_shaft 피드백에는 양의 motion_gear_ratio가 필요합니다.")
        # MCU의 기본 비현실 속도 경계와 일치시킨 입력 무결성 검사다. 명령 최고속도나
        # 가속도 제한이 아니며, 거절한 표본을 0으로 대체하거나 시각을 갱신하지 않는다.
        self.max_motor_feedback_mps = float(node.declare_parameter("motion_max_motor_feedback_mps", 5.).value)
        if not math.isfinite(self.max_motor_feedback_mps) or self.max_motor_feedback_mps <= 0:
            raise ValueError("motion_max_motor_feedback_mps must be finite and positive")
        self.left = str(node.declare_parameter("motion_left_joint", "rear_left_wheel_joint").value)
        self.right = str(node.declare_parameter("motion_right_joint", "rear_right_wheel_joint").value)
        self.feedback_topic = TOPIC_BY_MODE[self.feedback_mode]
        self.last_clock = None
        self.counts = {"wheels": 0, "drive_motor": 0, "gyro": 0, "rejected": 0, "resets": 0}
        self.last_meta = {}
        self.gyro_rejections = {}
        self.last_gyro_rejection = None
        self.input_floor_s = -math.inf
        # 독립 비교의 none도 같은 입력 부하를 받는다. 일반 none에서는 생성하지 않아도 된다.
        # 계측 이름 'wheels'는 기존 분석 호환용 구동 피드백 콜백 이름이다.
        wrap = node.timing.wrap if hasattr(node, 'timing') else lambda _, callback: callback
        callback = self.on_drive_motor if self.feedback_mode == MODE_MOTOR else self.on_wheels
        self._ready_motion_subscriptions = [node.create_subscription(
            JointState, self.feedback_topic, wrap('wheels', callback), 100)]
        imu_topic = str(node.declare_parameter("motion_imu_topic", "/camera/imu").value)
        # 각속도는 최신값만 필요한 영상과 달리 적분용 이력이다. 기본5표본은
        # 200Hz에서25ms뿐이라 짧은 계산 지연에도 중간 표본을 잃었다(r134).
        # 약320ms를 보관하되 원 취득시각·세대/만료 검사는 그대로 적용한다.
        imu_qos = copy(qos_profile_sensor_data)
        imu_qos.depth = 64
        self._ready_motion_subscriptions.append(node.create_subscription(
            Imu, imu_topic, wrap('imu', self.on_imu), imu_qos))

    def drain_pending(self, *, budget_s=.002):
        """현재 control callback 안에서 이미 준비된 표본만 기존 callback으로 소비한다.

        control과 운동 subscriptions는 같은 기본 mutually-exclusive callback group을
        사용한다. 호출 뒤 제어 함수가 now를 읽는다. 동시 직접 호출은 지원하지 않는다.
        상한은 메시지 사이에서 검사하며 남은 표본과 원 stamp/만료 기준은 보존한다.
        """
        self.last_drain = drain_ready_motion(self._ready_motion_subscriptions, budget_s=budget_s)
        return self.last_drain

    def clock(self):
        now = self.node.get_clock().now().nanoseconds * 1e-9
        if self.last_clock is not None and now < self.last_clock - 1e-9:
            self.history.reset()
            self.counts["resets"] += 1
            self.input_floor_s = -math.inf
        self.last_clock = now
        return now

    def begin_input_boundary(self, boundary_s):
        """이력을 비우고 경계 전 취득 표본을 막는다. 운반 중 누적 이동을 새 위치에 잇지 않는다."""
        self.history.reset()
        self.counts["resets"] += 1
        self.input_floor_s = boundary_s

    def capture(self, kind, stamp, values, accepted):
        accepted = bool(accepted)  # ROS covariance의 numpy.bool_도 JSON bool로 기록
        self.counts[kind if accepted else "rejected"] += 1
        if self.record:
            self.record({"kind": kind, "stamp_s": stamp, "received_s": self.last_clock,
                         "values": [float(v) if math.isfinite(v) else None for v in values], "accepted": accepted})

    def on_wheels(self, msg):
        now = self.clock()
        stamp = seconds(msg.header.stamp)
        try:
            values = list(parse_legacy_wheels(msg.name, msg.velocity, self.left, self.right, require_finite=False))
        except ValueError:
            # 이름/개수 불일치는 거절한다. 비유한 값은 Series가 거절하고 기록에 남긴다.
            self.counts["rejected"] += 1
            return
        accepted = self.input_floor_s <= stamp <= now + .1 and self.history.add_wheels(stamp, *values)
        self.capture("wheels", stamp, values, accepted)

    def on_drive_motor(self, msg):
        """모터축 한 채널 → 평균 바퀴 속도. 좌우 값을 만들지 않는다."""
        now = self.clock()
        stamp = seconds(msg.header.stamp)
        try:
            position, motor_rad_s = parse_motor_state(msg.name, msg.position, msg.velocity, require_finite=False)
        except ValueError:
            self.counts["rejected"] += 1
            return
        mean_wheel = motor_rad_s / self.gear_ratio
        # 위치(누적 카운트)가 비유한이면 같은 표본의 속도도 믿지 않는다. 첫 표본의 NaN 속도는
        # 아직 속도 기준이 없다는 뜻이며 Series가 거절·기록한다.
        speed_mps = mean_wheel * self.history.config.wheel_radius_m * self.history.config.wheel_scale
        accepted = (math.isfinite(position) and math.isfinite(speed_mps)
                    and abs(speed_mps) <= self.max_motor_feedback_mps and self.input_floor_s <= stamp <= now + .1
                    and self.history.add_mean_wheel(stamp, mean_wheel))
        self.capture("drive_motor", stamp, [motor_rad_s, mean_wheel], accepted)

    def on_imu(self, msg):
        now = self.clock()
        stamp = seconds(msg.header.stamp)
        values = [msg.angular_velocity.x, msg.angular_velocity.y, msg.angular_velocity.z]
        yaw = sum(a * v for a, v in zip(self.axis, values))
        reason = None
        if self.expected_imu_frame and msg.header.frame_id != self.expected_imu_frame:
            reason = "gyro_frame_mismatch"
        elif msg.angular_velocity_covariance[0] == -1:
            reason = "gyro_unavailable"
        elif not all(math.isfinite(v) for v in values):
            reason = "gyro_nonfinite"
        elif any(abs(v) >= self.gyro_abs_limit for v in values):
            reason = "gyro_range_or_saturation"
        elif stamp > now + .1:
            reason = "gyro_future"
        elif stamp < self.input_floor_s:
            reason = "gyro_before_boundary"
        elif (self.history.gyro.times and stamp > self.history.gyro.times[-1]
              and abs((yaw - self.history.config.gyro_bias_rad_s) - self.history.gyro.values[-1]) >
              self.gyro_step_slack + self.gyro_slew_limit * (stamp - self.history.gyro.times[-1])):
            reason = "gyro_slew"
        elif not self.history.add_gyro(stamp, yaw):
            reason = "gyro_timestamp"
        accepted = reason is None
        if reason:
            self.gyro_rejections[reason] = self.gyro_rejections.get(reason, 0) + 1
            self.last_gyro_rejection = reason
        # 거절한 값을 clamp/0으로 대체하거나 취득 시각만 갱신하지 않는다.
        # 짧은 공백은 기존 ZOH 한도, 연속 거절은 motion_stale/gap으로 정지한다.
        self.capture("gyro", stamp, values, accepted)

    def project(self, scan):
        now = self.clock()
        began = time.perf_counter()
        diagnostic = {"gyro_rejections": dict(getattr(self, 'gyro_rejections', {})),
                      "last_gyro_rejection": getattr(self, 'last_gyro_rejection', None)}
        try:
            if scan.header.frame_id != self.history.config.lidar_frame_id:
                raise MotionUnavailable("scan_frame_mismatch")
            from arena_autonomy.scan_input import project_scan
            points, indices, meta = project_scan(scan,self.history,now,self.mode,self.verified,
                timing_policy=self.timing_policy)
            self.last_meta = {**meta, **diagnostic, "reason": "ok", "processing_ms": (time.perf_counter() - began) * 1000}
            return points, len(indices)
        except MotionUnavailable as error:
            self.last_meta = {"mode": self.mode, **diagnostic, "reason": str(error),
                              "processing_ms": (time.perf_counter() - began) * 1000}
            raise
