# 선택한 실측 서보 입력 — 설치 전 단계

영점/운영 count 프로필: `config/hardware/steering_zero.assembled_2026_11_14.json`
시뮬레이션 vehicle 입력: `src/arena_description/config/vehicle.measured_steering_2026_11_14.yaml`
중앙 명령 상한 L: `0.28475436568260193` rad. vehicle YAML의 내륜 joint 상한과 구분한다.
두 파일의 SHA는 `steering_selection.json`에 기록했다. wheel각은 CAD 환산이며 실측값이 아니다.
기존 preview 실행을 선택할 때는 `run_hardware_sensor_preview.py --vehicle-config src/arena_description/config/vehicle.measured_steering_2026_11_14.yaml`를 명시한다.
이 옵션은 기하 입력이며 실제 host/MCU 서보 설정을 대신하지 않는다.

검토한 실제 board 사본의 `servo.command_limit`만 L로 선택하고 나머지 실제 board/PI/encoder 값을 유지한다.
아직 실제 board가 없으면 생성하지 않는다. 임의 motor/PI/포트 값으로 빈칸을 채우지 않는다.

```sh
python scripts/runtime_installed_profile.py prepare --board-profile "$REVIEWED_BOARD" --steering-profile config/hardware/steering_zero.assembled_2026_11_14.json --assembly-id arena-car-v1 --output "$FRESH_INSTALLED"
python handover/prepare_hardware_policy.py prepare --base-params "$REVIEWED_PARAMS" --hardware-inputs "$REAL_INPUTS" --installed-profile "$FRESH_INSTALLED" --output "$FRESH_SELECTION"
python scripts/runtime_installed_limits.py host-arguments --selection "$FRESH_SELECTION/selected" --installed-profile "$FRESH_INSTALLED"
```

planner/guard에는 같은 `$FRESH_SELECTION/selected/runtime_profile.yaml`, host에는 출력된 arguments를 사용한다.
native firmware 빌드에는 같은 `$FRESH_INSTALLED`를 기존 `build_runtime_drive.sh --installed-profile`로 전달한다.
ZIP 교체나 vehicle YAML 선택만으로 MCU/host에 적용되지 않는다. r500 설치본은 rollback 기준으로 보존한다.
이 source 묶음은 전송·설치·flash·실물 출력 완료를 의미하지 않는다.
