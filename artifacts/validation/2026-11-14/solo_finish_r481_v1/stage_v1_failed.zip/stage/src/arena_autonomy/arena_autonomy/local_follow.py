"""G1-a 선택형 지역 경계 확인 + 거리 기반 FOLLOW/HOLD.

새 물체를 차량으로 완벽히 분류하지 않는다. 경로 형상만 짧게 기억하며,
점유 검사에서는 벽 후보를 포함한 모든 현재 반환을 유지한다. 경계 기억을
자유 공간 증거로 사용하지 않는다. 우회/추월·상대 속도 이득은 없다.
"""
from dataclasses import dataclass
import math

import numpy as np
from arena_autonomy.scan_input import scan_first_stamp

from arena_autonomy.lidar_motion import MotionUnavailable
from arena_autonomy.local_path import local_path, braking_speed, swept_limit
from arena_autonomy.scene_motion import transport_points
from arena_autonomy.boundary_evidence import fragment_evidence
from arena_autonomy.corner_evidence import corner_anchor_evidence
from arena_autonomy.corner_distance import corner_distance_evidence
from arena_autonomy.occupancy_timing import per_ray_padding


@dataclass(frozen=True)
class FollowConfig:
    # 옛 판단 기록에 필드가 없으면 당시 대기를 재현. 새 ROS 실행은 forward_drive.
    signed_motion_policy: str = 'legacy_hold'
    solo_route_only: bool = False  # 단독 프리랩 선택. 점유/관측 검사는 유지하고 측방 교통 선택기만 제외.
    corridor_arc_agreement: bool = False  # 단독 선택형 회랑 시간 비교의 공통 호길이 보완.
    ray_wall_continuity: bool = False  # 단독 선택형. 먼 옆 벽의 단절을 연속 광선 직선 근거로 보완.
    piecewise_wall_trial: bool = False  # 연결 관측의 한 모서리를 두 직선+원호로 표현.
    solo_straight_budget_trial: bool = False  # 현재 양쪽 직선 벽을 속도 근거로만 쓴다.
    solo_corner_approach_trial: bool = False  # 단독 직각 접근 감속 후보
    oblique_gap_trial: bool = False  # 기본 OFF. 좁은 공백 저속; 교통은 현재 SOLO에 한정.
    partial_observation_policy: str = 'strict'
    # 센서 프로필의 알려진 구조 가림 선택(v4 필요). off는 기존 부분 관측 그대로.
    known_structure_policy: str = 'off'
    known_structure_sectors_json: str = ''
    parallel_hold_trial: bool = False
    current_lane_preference_trial: bool = False  # 정지 측방 반환 뒤 현재 관측 직선의 차선 선호.
    current_lane_headroom_mps: float = 0.  # 선택 시험에서 실제 설정의 엔코더 1카운트 속도.
    side_departure_trial: bool = False  # 완전 관측 직선의 측방 시차 겹침에서 비접근 저속 진행.
    pass_release_trial: bool = False
    guard_curve_trial: bool = False
    guard_observation_policy: str = 'original_v1'  # 명시 선택 selected_r181. 기본/기존 기록은 불변.
    traffic_recovery_trial: bool = False
    released_rear_sweep_trial: bool = False
    released_body_gap_trial: bool = False  # 통과 뒤 저속 차체 옆 공백 후보. 기본 OFF.
    static_side_release_trial: bool = False
    traffic_path_recovery_trial: bool = False
    rear_lane_keep_trial: bool = False
    rear_lane_keep_policy: str = 'timed'
    corridor_fallback_enabled: bool = False
    short_boundary_prefix_enabled: bool = False
    recent_observation_enabled: bool = False
    boundary_evidence_mode: str = 'connected'
    occupancy_timing_mode: str = 'oldest'
    wheelbase_m: float = .135
    # 옛 trace에 필드가 없으면 당시 측방 기본 기하를 유지한다.
    track_m: float = .135
    wheel_radius_m: float = .0325
    wheel_width_m: float = .012
    length_m: float = .20
    width_m: float = .15
    wall_offset_m: float = .425
    road_half_m: float = .225  # 알려진 본선 단면 사양. 점유/자유 공간 관측을 대신하지 않는다.
    max_steering_rad: float = .37
    max_speed_mps: float = 1.0
    open_route_speed_mps: float = 0.  # 선택형 단독 속도 시험. 0이면 종전 경로/속도 그대로.
    blend_open_speed_by_length: bool = False
    preview_turn_speed: bool = False
    preview_above_base_speed: bool = False  # 단독 선택형. 코너 예측을 통상 상한 위의 양수 목표에도 적용.
    boundary_bridge: bool = False  # 단독 선택형. 점유가 아닌 경로 근거 전환 때문에 생긴 정지만 잇는다.
    traffic_boundary_refresh_trial: bool = False  # 교통 선택형. 가려진 벽 조각 경로 가설 및 이미 승인한 벽의 긴 현재 관측 갱신.
    low_speed_arc_reacquire: bool = False  # 단독 시험 선택. 낮은 측정 속도의 양측 경로 재획득만.
    standing_wall_reacquire: bool = False  # 재개 후보. 기억 없는 낮은 속도에서 선호 벽의 긴 현재 관측으로 재획득.
    # 11/9 신호 양지주 대비(단독 선택형): 벽 앞 좁은 가림체가 벽 연결만 끊어 관측 길이를 줄이지 않게 한다.
    narrow_occluder_bridge: bool = False
    # 11/9 마커 누락 대비(선택형): 선호 벽이 갈림길로 갈라져 확인되지 않으면 직전 승인 경로와
    # 일치하는 반대 벽의 긴 현재 관측으로 본선을 잇는다.
    junction_continuity: bool = False
    expiry_route_reference_trial: bool = False  # 계산 만료 뒤 현재 관측 비교용 선택 벽 참조만 보존.
    lateral_acceleration_mps2: float = 3.5
    memory_ttl_s: float = .30
    memory_motion_limit_m: float = .45
    boundary_min_ahead_m: float = .65
    boundary_anchor_error_m: float = .12
    boundary_agreement_m: float = .08
    measurement_padding_m: float = .03
    # G1-a 저속 표적 시험의 과거 취득 시차 팽창. 미래 cut-in 보증이 아니다.
    object_motion_bound_mps: float = .5
    standstill_gap_m: float = .16
    hold_clearance_m: float = .20
    resume_clearance_m: float = .28
    headway_s: float = .8
    confirmations: int = 2
    crop_edge_component_trial: bool = False  # 명시 verified native 시뮬 경계 성분 후보.

    def __post_init__(self):
        for name in ('track_m', 'wheel_radius_m', 'wheel_width_m'):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
                raise ValueError(name + ' must be finite and positive')
        if (type(self.expiry_route_reference_trial) is not bool or
                (self.expiry_route_reference_trial and not self.junction_continuity)):
            raise ValueError('expiry route reference requires junction continuity')
        if type(self.piecewise_wall_trial) is not bool:
            raise ValueError('piecewise wall trial must be boolean')
        if (type(self.solo_corner_approach_trial) is not bool or
                (self.solo_corner_approach_trial and not self.solo_straight_budget_trial)):
            raise ValueError('corner approach requires explicit solo straight budget')
        if (type(self.solo_straight_budget_trial) is not bool or
                (self.solo_straight_budget_trial and not (
                    self.solo_route_only and self.blend_open_speed_by_length and self.boundary_bridge
                    and self.preview_above_base_speed and not self.ray_wall_continuity
                    and self.occupancy_timing_mode == 'per_ray_candidate'
                    and self.partial_observation_policy == 'bounded_local_v4'))):
            raise ValueError('straight speed budget requires the selected solo observed route configuration')
        if (type(self.side_departure_trial) is not bool or
                (self.side_departure_trial and (not self.pass_release_trial or self.solo_route_only))):
            raise ValueError('side departure requires traffic pass release trial')
        if type(self.solo_route_only) is not bool:
            raise ValueError('solo route mode must be boolean')
        if (type(self.corridor_arc_agreement) is not bool or
                (self.corridor_arc_agreement and not (self.solo_route_only and self.corridor_fallback_enabled))):
            raise ValueError('corridor arc agreement requires solo route and corridor fallback')
        if (type(self.ray_wall_continuity) is not bool or
                (self.ray_wall_continuity and not (self.solo_route_only and self.blend_open_speed_by_length))):
            raise ValueError('ray wall continuity requires the solo observed route speed profile')
        if self.signed_motion_policy not in ('legacy_hold', 'forward_drive'):
            raise ValueError('unknown signed motion policy')
        if (self.guard_observation_policy not in ('original_v1', 'selected_r181') or
                (self.guard_observation_policy == 'selected_r181' and not (
                    self.pass_release_trial and self.guard_curve_trial and self.traffic_recovery_trial))):
            raise ValueError('selected guard observation requires explicit traffic guard profile')
        if (type(self.released_body_gap_trial) is not bool or
                (self.released_body_gap_trial and self.guard_observation_policy != 'selected_r181')):
            raise ValueError('released body gap requires selected guard observation policy')
        if (self.rear_lane_keep_policy not in ('timed', 'observed', 'observed_measured_v1', 'observed_fresh_v2') or
                (self.rear_lane_keep_policy != 'timed' and not self.rear_lane_keep_trial)):
            raise ValueError('observed lane preference requires explicit rear lane keep trial')
        if (type(self.traffic_path_recovery_trial) is not bool or
                (self.traffic_path_recovery_trial and
                 (not self.traffic_recovery_trial or not self.corridor_fallback_enabled))):
            raise ValueError('traffic path recovery requires explicit traffic recovery and corridor fallback')
        if (type(self.rear_lane_keep_trial) is not bool or
                (self.rear_lane_keep_trial and not self.traffic_path_recovery_trial)):
            raise ValueError('rear lane keep trial requires explicit traffic path recovery')
        if (type(self.short_boundary_prefix_enabled) is not bool or
                (self.short_boundary_prefix_enabled and
                 (not self.corridor_fallback_enabled or self.recent_observation_enabled or self.max_speed_mps > 1.))):
            raise ValueError('short boundary prefix requires corridor fallback, <=1 m/s and no recent observation')
        if type(self.pass_release_trial) is not bool or (self.pass_release_trial and not self.parallel_hold_trial):
            raise ValueError('pass release trial requires explicit parallel hold trial')
        if (type(self.released_rear_sweep_trial) is not bool or
                (self.released_rear_sweep_trial and not self.traffic_recovery_trial)):
            raise ValueError('released rear sweep requires traffic recovery')
        if (type(self.current_lane_preference_trial) is not bool or
                (self.current_lane_preference_trial and (not self.traffic_path_recovery_trial
                 or not self.static_side_release_trial or not self.side_departure_trial
                 or self.rear_lane_keep_trial or self.solo_route_only))):
            raise ValueError('current lane preference requires the explicit side departure/path recovery profile')
        if (isinstance(self.current_lane_headroom_mps, bool) or not math.isfinite(self.current_lane_headroom_mps)
                or not 0 <= self.current_lane_headroom_mps < self.max_speed_mps
                or (self.current_lane_preference_trial and self.current_lane_headroom_mps <= 0)):
            raise ValueError('current lane preference requires a positive configured speed quantum')
        if (type(self.static_side_release_trial) is not bool or
                (self.static_side_release_trial and not self.pass_release_trial)):
            raise ValueError('static side release requires pass release trial')
        if (type(self.traffic_recovery_trial) is not bool or
                (self.traffic_recovery_trial and not self.guard_curve_trial)):
            raise ValueError('traffic recovery requires explicit guard curve trial')
        if type(self.guard_curve_trial) is not bool or (self.guard_curve_trial and not self.pass_release_trial):
            raise ValueError('guard curve trial requires explicit pass release trial')
        if (type(self.parallel_hold_trial) is not bool or (self.parallel_hold_trial and
                (self.partial_observation_policy != 'bounded_local_v4' or
                 self.occupancy_timing_mode != 'per_ray_candidate' or
                 self.boundary_evidence_mode != 'corner_distance_candidate'))):
            raise ValueError('parallel hold trial requires v4, corner-distance and per-ray candidates')
        if (type(self.oblique_gap_trial) is not bool or (self.oblique_gap_trial and not (
                self.partial_observation_policy == 'bounded_local_v4' and (self.solo_route_only or
                (self.pass_release_trial and self.guard_curve_trial and self.traffic_recovery_trial))))):
            raise ValueError('oblique gap trial requires solo v4 or explicit guarded traffic v4')
        if self.partial_observation_policy not in ('strict','bounded_local_v2','bounded_local_v3','bounded_local_v4'):
            raise ValueError('unsupported G1 partial observation policy')
        if self.partial_observation_policy != 'strict' and (self.recent_observation_enabled or self.max_speed_mps>1.):
            raise ValueError('G1 partial observation requires <=1 m/s and no recent observation candidate')
        from arena_autonomy.crop_edge_selection import validate_policy_selection
        validate_policy_selection(self.crop_edge_component_trial, self.partial_observation_policy,
                                  self.traffic_recovery_trial)
        from arena_autonomy.known_structure import validate as validate_structure
        validate_structure(self.known_structure_policy, self.known_structure_sectors_json)
        if self.known_structure_policy != 'off' and self.partial_observation_policy != 'bounded_local_v4':
            raise ValueError('known structure policy requires bounded_local_v4')
        if self.boundary_evidence_mode not in ('connected', 'fragmented_candidate', 'corner_anchor_candidate', 'corner_distance_candidate'):
            raise ValueError('invalid boundary evidence mode')
        if self.occupancy_timing_mode not in ('oldest', 'per_ray_candidate'):
            raise ValueError('invalid occupancy timing mode')
        cruise = self.open_route_speed_mps
        if type(cruise) not in (float, int) or not math.isfinite(cruise) or not (cruise == 0 or self.max_speed_mps <= cruise <= 2.78):
            raise ValueError('open route cap must be off or between base speed and 2.78 m/s')
        if type(self.blend_open_speed_by_length) is not bool or (self.blend_open_speed_by_length and not cruise):
            raise ValueError('route length blending requires an open speed profile')
        if type(self.preview_turn_speed) is not bool or (self.preview_turn_speed and
                (not self.blend_open_speed_by_length or self.occupancy_timing_mode != 'per_ray_candidate')):
            raise ValueError('turn preview requires observed route speed and timed beam occupancy')
        if (type(self.preview_above_base_speed) is not bool or
                (self.preview_above_base_speed and not (self.solo_route_only and self.preview_turn_speed))):
            raise ValueError('preview above base speed requires solo route and turn preview')
        if (type(self.boundary_bridge) is not bool or
                (self.boundary_bridge and not (self.solo_route_only and self.corridor_fallback_enabled))):
            raise ValueError('boundary bridge requires solo route and corridor fallback')
        if (type(self.low_speed_arc_reacquire) is not bool or
                (self.low_speed_arc_reacquire and not self.blend_open_speed_by_length)):
            raise ValueError('low speed arc reacquire requires the solo observed route speed profile')
        if (type(self.traffic_boundary_refresh_trial) is not bool or
                (self.traffic_boundary_refresh_trial and (self.solo_route_only or not self.traffic_path_recovery_trial))):
            raise ValueError('traffic boundary refresh requires the traffic path recovery profile')
        if type(self.standing_wall_reacquire) is not bool:
            raise ValueError('standing wall reacquire must be bool')
        if type(self.narrow_occluder_bridge) is not bool or type(self.junction_continuity) is not bool:
            raise ValueError('narrow occluder bridge and junction continuity must be bool')
        if any(isinstance(v, bool) or not math.isfinite(v) or v <= 0 for k, v in vars(self).items()
               if k not in ('crop_edge_component_trial', 'expiry_route_reference_trial', 'released_body_gap_trial', 'guard_observation_policy', 'traffic_boundary_refresh_trial', 'solo_corner_approach_trial', 'oblique_gap_trial', 'piecewise_wall_trial', 'solo_straight_budget_trial', 'known_structure_policy', 'known_structure_sectors_json', 'current_lane_preference_trial', 'current_lane_headroom_mps', 'side_departure_trial', 'standing_wall_reacquire', 'narrow_occluder_bridge', 'junction_continuity', 'static_side_release_trial', 'corridor_arc_agreement', 'ray_wall_continuity', 'solo_route_only', 'signed_motion_policy', 'open_route_speed_mps', 'blend_open_speed_by_length', 'preview_turn_speed', 'preview_above_base_speed', 'boundary_bridge', 'low_speed_arc_reacquire', 'boundary_evidence_mode', 'occupancy_timing_mode', 'corridor_fallback_enabled', 'short_boundary_prefix_enabled', 'recent_observation_enabled', 'partial_observation_policy', 'parallel_hold_trial', 'pass_release_trial', 'guard_curve_trial', 'traffic_recovery_trial', 'released_rear_sweep_trial', 'traffic_path_recovery_trial', 'rear_lane_keep_trial', 'rear_lane_keep_policy')):
            raise ValueError('follow configuration must be finite and positive')
        if (type(self.corridor_fallback_enabled) is not bool or
                (self.corridor_fallback_enabled and (self.boundary_evidence_mode != 'corner_distance_candidate' or
                                                     self.occupancy_timing_mode != 'per_ray_candidate'))):
            raise ValueError('corridor fallback requires explicit corner-distance and per-ray candidates')
        if (type(self.recent_observation_enabled) is not bool or
                (self.recent_observation_enabled and (not self.corridor_fallback_enabled or self.max_speed_mps > 1.))):
            raise ValueError('recent observation requires corridor fallback and <=1 m/s configuration')
        if (self.memory_ttl_s > .3 or self.max_speed_mps > 2.5 or self.confirmations < 2
                or not isinstance(self.confirmations, int)
                or not self.standstill_gap_m < self.hold_clearance_m < self.resume_clearance_m):
            raise ValueError('invalid follow time/speed/hysteresis contract')


def anchor_error(details, config):
    """경계 앵커 오차. 기본 OFF 선택형 경로는 원점에서 생성 경로 선분까지의 거리를 쓴다.

    직각 벽을 원호로 도는 차는 벽 y좌표가 오프셋과 달라도 경로 위에 있다. 같은 코너가
    한 모서리 표현(piecewise_corner)과 일반 곡선(wall_model 없음) 사이를 오가도 같은 지표를 쓴다.
    근접 장애물 여유가 아니므로 앵커 판정에만 쓴다. 값이 없거나 다른 모델이면 기존 벽 거리 대조,
    비유한/음수는 거부한다.
    """
    if (config.piecewise_wall_trial and details.get('wall_model') in (None, 'piecewise_corner')
            and 'path_anchor_error_m' in details):
        try:
            value = float(details['path_anchor_error_m'])
        except (TypeError, ValueError):
            return math.inf
        return value if math.isfinite(value) and value >= 0. else math.inf
    return abs(details['wall_distance_m']-config.wall_offset_m)


def path_agrees(candidate, reference, tolerance):
    """실제로 겹치는 가까운 전방 구간의 대칭 거리.

    가림으로 한쪽 경로가 짧을 때 다른 쪽에만 있는 구간의 끝점 거리를
    형상 오차로 세지 않는다. 공통 구간도 0.25 m/각 5점을 요구하며
    외삽·보간·미관측 채우기를 하지 않는다. 점유 검사는 별도로 유지한다.
    """
    paths = [np.asarray(p)[(np.asarray(p)[:, 0] >= .05) & (np.asarray(p)[:, 0] <= .65)]
             for p in (candidate, reference)]
    if any(len(p) < 5 or np.ptp(p[:, 0]) < .25 for p in paths):
        return False
    lo = max(float(np.min(p[:, 0])) for p in paths)
    hi = min(float(np.max(p[:, 0])) for p in paths)
    if hi-lo < .25:
        return False
    paths = [p[(p[:, 0] >= lo-1e-12) & (p[:, 0] <= hi+1e-12)] for p in paths]
    if any(len(p) < 5 or np.ptp(p[:, 0]) < .25 for p in paths):
        return False
    distances = np.linalg.norm(paths[0][:, None, :]-paths[1][None, :, :], axis=2)
    return max(np.percentile(np.min(distances, axis=0), 80),
               np.percentile(np.min(distances, axis=1), 80)) <= tolerance


def path_agrees_arc(candidate, reference, tolerance, lo=.05, hi=1.):
    """차체 x 창이 비는 급커브에서 두 경로의 같은 호길이 구간을 같은 기준으로 비교한다.

    path_agrees와 마찬가지로 공통 구간 0.25 m·각 5점을 요구하며 외삽하지 않는다.
    벽 정체를 인증하지 않고, 공통 80%를 넘긴 뒤 갈라지는 먼 분기는 구별하지 못한다.
    """
    def ahead(path):
        path = np.asarray(path, dtype=float)
        path = path[int(np.argmin(np.linalg.norm(path, axis=1))):]
        arc = np.r_[0., np.cumsum(np.linalg.norm(np.diff(path, axis=0), axis=1))]
        keep = (arc >= lo) & (arc <= hi)
        return path[keep], arc[keep]
    (first, first_arc), (second, second_arc) = ahead(candidate), ahead(reference)
    if len(first) < 5 or len(second) < 5:
        return False
    start, end = max(first_arc[0], second_arc[0]), min(first_arc[-1], second_arc[-1])
    if end-start < .25:
        return False
    first = first[(first_arc >= start-1e-12) & (first_arc <= end+1e-12)]
    second = second[(second_arc >= start-1e-12) & (second_arc <= end+1e-12)]
    if len(first) < 5 or len(second) < 5:
        return False
    distances = np.linalg.norm(first[:, None, :]-second[None, :, :], axis=2)
    return bool(max(np.percentile(np.min(distances, axis=0), 80),
                    np.percentile(np.min(distances, axis=1), 80)) <= tolerance)


def retained_forward_prefix(candidate, reference, details, config):
    """현재 경로가 전방에서 시작한 경우를 횡방향 이탈과 구별한다.

    현재 긴 직각 벽·유효 이력의 공통 구간은 그대로 요구한다. 시작점은 최소
    추종 목표 거리(0.30m) 안에서 전방을 향하고, 원점의 접선 수직 오차는 기존
    앵커 허용량 이내여야 한다. 경로를 뒤로 연장하거나 그 사이를 자유 공간으로
    기록하지 않는다. 실제 조향/점유/부분 관측 검사는 별도로 유지한다.
    초기 획득이나 TTL 만료 뒤에는 호출자가 유효 이력을 줄 수 없다.
    """
    if (not config.piecewise_wall_trial or candidate is None or reference is None
            or details.get('wall_model') != 'piecewise_corner'
            or details.get('boundary_observed_ahead_m', 0.) < config.boundary_min_ahead_m
            or anchor_error(details, config) <= config.boundary_anchor_error_m):
        return None
    path = np.asarray(candidate, dtype=float)
    if (path.ndim != 2 or path.shape[1] != 2 or len(path) < 5
            or not np.all(np.isfinite(path))):
        return None
    start, tangent = path[0], path[1]-path[0]
    norm = float(np.linalg.norm(tangent))
    if norm <= 1e-9 or not 0. < start[0] or np.linalg.norm(start) > .30:
        return None
    tangent = tangent/norm
    along = float(start @ tangent)
    lateral = abs(float(start[0]*tangent[1]-start[1]*tangent[0]))
    if (tangent[0] <= 0. or not 0. < along <= .30
            or lateral > config.boundary_anchor_error_m
            or int(np.argmin(np.linalg.norm(path, axis=1))) != 0
            or not path_agrees(path, reference, config.boundary_agreement_m)):
        return None
    return dict(start_distance_m=float(np.linalg.norm(start)), along_tangent_m=along,
                lateral_error_m=lateral, maximum_start_distance_m=.30,
                observed_prefix_extended=False, unknown_filled=False)


def retained_boundary_agreement(candidate, reference, details, config):
    """현재 긴 벽의 유지 비교. 직각 경로는 공통 호길이 구간도 대조한다.

    x 창만으로는 같은 x를 가진 코너 출구의 서로 다른 길이를 함께 비교할 수 있다.
    선택형 교통 또는 단독 호길이 옵션의 직각 경로에서 재사용한다. 허용 오차나
    관측 길이를 늘리지 않으며, 실제 점유/통과 검사는 호출자가 별도로 한다.
    """
    if path_agrees(candidate, reference, config.boundary_agreement_m):
        return 'shared_x'
    enabled = config.traffic_boundary_refresh_trial or (config.solo_route_only and config.corridor_arc_agreement)
    if (enabled and config.piecewise_wall_trial
            and details.get('wall_model') == 'piecewise_corner'
            and path_agrees_arc(candidate, reference, config.boundary_agreement_m)):
        return 'shared_arc'
    return None



def traffic_corner_prefix(candidate, reference, details, config):
    """짧은 현재 벽의 지지를 넘기지 않는 코너 경로를 유효 이력과 대조한다.

    벽의 호길이와 오프셋 경로 길이는 다르다. 이 제한 후보는 더 짧은 실제 벽의
    전방 관측 길이까지만 경로를 남긴다. 최초/만료 이력의 확보와 점유 허가는 별도다.
    """
    if (not config.traffic_boundary_refresh_trial or not config.piecewise_wall_trial
            or not config.short_boundary_prefix_enabled or candidate is None or reference is None
            or details.get('wall_model') != 'piecewise_corner'
            or not 0. < details.get('boundary_observed_ahead_m', 0.) < config.boundary_min_ahead_m
            or anchor_error(details, config) > config.boundary_anchor_error_m):
        return None, None
    arc = np.r_[0., np.cumsum(np.linalg.norm(np.diff(candidate, axis=0), axis=1))]
    nearest = int(np.argmin(np.linalg.norm(candidate, axis=1)))
    budget = details['boundary_observed_ahead_m']
    end = int(np.searchsorted(arc, arc[nearest]+budget, side='right'))
    prefix = candidate[:end].copy()
    match = retained_boundary_agreement(prefix, reference, details, config)
    return (prefix, match) if match is not None else (None, None)


def boundary_support(points, path, side, config):
    """유효한 경계 이력 안에서 일치하는 실제 반환만 경로 후보로 사용한다.

    경로 법선에서 예상 벽을 계산하되 관측점을 만들어 추가하지 않는다.
    이력의 양 끝 너머는 새 경계를 관측할 수 있도록 그대로 둔다. 결과에도
    기존 연결 간격·적합·길이·형상 검사를 적용하며 모든 원래 점유는 별도 유지한다.
    """
    tangent = np.gradient(path, axis=0)
    tangent /= np.maximum(1e-9, np.linalg.norm(tangent, axis=1))[:, None]
    sign = 1 if side == 'left' else -1
    wall = path + sign*config.wall_offset_m*np.column_stack((-tangent[:, 1], tangent[:, 0]))
    delta = points[:, None, :]-wall[None, :, :]
    distances = np.linalg.norm(delta, axis=2)
    nearest = np.argmin(distances, axis=1)
    index = np.arange(len(points))
    longitudinal = np.sum(delta[index, nearest]*tangent[nearest], axis=1)
    outside = ((nearest == 0) & (longitudinal < 0)) | ((nearest == len(wall)-1) & (longitudinal > 0))
    return points[outside | (distances[index, nearest] <= config.boundary_agreement_m)]


def drop_protrusions(points, path, side, config):
    """경계 지원점에서 기대 벽보다 측정 여유 이상 벗어난 다른 물체의 가장자리를 뺀다.

    boundary_agreement_m는 기억/반대 벽 형상 오차의 허용치라 벽 바로 앞의 얇은
    기둥 모서리도 통과시킬 수 있고, 그 한 점이 방위 순서의 벽 연결을 끊는다.
    기대 벽 선분까지의 부호 있는 수직 거리에서 기준 경로의 일정한 치우침(중앙값)을
    빼고 measurement_padding_m을 넘는 점을 제외한다. 점을 만들거나 옮기지 않으며
    양 끝 밖 점은 boundary_support와 같이 둔다. 제외한 점도 점유 검사에는 남는다.
    """
    tangent = np.gradient(path, axis=0)
    tangent /= np.maximum(1e-9, np.linalg.norm(tangent, axis=1))[:, None]
    sign = 1 if side == 'left' else -1
    wall = path + sign*config.wall_offset_m*np.column_stack((-tangent[:, 1], tangent[:, 0]))
    start, step = wall[:-1], np.diff(wall, axis=0)
    length2 = np.maximum(1e-12, np.sum(step*step, axis=1))
    delta = points[:, None, :]-start[None, :, :]
    raw = np.sum(delta*step[None], axis=2)/length2
    fraction = np.clip(raw, 0., 1.)
    residual = delta-fraction[:, :, None]*step[None]
    nearest = np.argmin(np.linalg.norm(residual, axis=2), axis=1)
    index = np.arange(len(points))
    outside = (((nearest == 0) & (raw[index, nearest] < 0)) |
               ((nearest == len(step)-1) & (raw[index, nearest] > 1)))
    # 도로 쪽(경로 방향)이 양수인 선분 법선 성분.
    inward = -sign*np.column_stack((-step[:, 1], step[:, 0]))/np.sqrt(length2)[:, None]
    offset = np.sum(residual[index, nearest]*inward[nearest], axis=1)
    if not np.any(~outside):
        return points
    return points[outside | (np.abs(offset-np.median(offset[~outside])) <= config.measurement_padding_m)]


def pursue_path(path, speed, config, age, *, speed_cap=None, shape_diagnostic=None):
    """기존 후륜축 Pure Pursuit와 같은 계산. 보호층 공통 함수를 변경하지 않는다."""
    rear = np.asarray(path, dtype=float).copy()
    rear[:, 0] += config.wheelbase_m/2
    distances = np.linalg.norm(rear, axis=1)
    nearest = int(np.argmin(distances))
    ahead = np.flatnonzero((rear[:, 0] > .10) & (np.arange(len(rear)) >= nearest))
    if len(ahead) < 3 or np.max(distances[ahead]) < .25:
        raise MotionUnavailable('path_too_short')
    lookahead = min(.60, max(.30, .30+.12*abs(speed)))
    target = rear[ahead[np.argmin(np.abs(distances[ahead]-lookahead))]]
    curvature = float(2*target[1]/max(.01, target@target))
    steering = float(np.clip(math.atan(config.wheelbase_m*curvature),
                             -config.max_steering_rad, config.max_steering_rad))
    arc = np.r_[0., np.cumsum(np.linalg.norm(np.diff(rear, axis=0), axis=1))]
    remaining = float(arc[-1]-arc[nearest])
    dx = np.gradient(rear, axis=0)
    ddx = np.gradient(dx, axis=0)
    curves = np.abs(dx[:, 0]*ddx[:, 1]-dx[:, 1]*ddx[:, 0])/np.maximum(1e-8, np.linalg.norm(dx, axis=1)**3)
    preview = np.sqrt(config.lateral_acceleration_mps2/np.maximum(.15, curves[nearest:]) +
                      4*np.maximum(0., arc[nearest:]-arc[nearest]-.2))
    shape_cap = min(float(np.min(preview)), math.sqrt(config.lateral_acceleration_mps2/max(.15, abs(curvature))))
    if shape_diagnostic is not None:
        shape_diagnostic['original_curve_speed_cap_mps'] = shape_cap
    cap = min(config.max_speed_mps if speed_cap is None else speed_cap, braking_speed(remaining, age), shape_cap)
    return cap, steering, remaining


def forward_planning_speed(config, measured):
    """전진 계획의 속력 상계. 원래 센서값·signed 이력/이송을 수정하지 않는다."""
    if (config.signed_motion_policy == 'forward_drive' and
            isinstance(measured, (int, float)) and not isinstance(measured, bool) and
            math.isfinite(measured) and measured < 0.):
        return abs(measured)
    return measured


def signed_feedback_detail(output, measured, planning):
    """전진 기하의 속력과 원래 음수 측정을 구별한다. 후방 밀림 안전의 증명은 아니다."""
    if not (isinstance(measured, (int, float)) and math.isfinite(measured)
            and measured < 0. and planning >= 0.):
        return output
    speed, steering, detail = output
    detail = dict(detail)
    for key in ('normal', 'bypass'):
        if isinstance(detail.get(key), dict) and 'measured_speed_mps' in detail[key]:
            detail[key] = {**detail[key], 'measured_speed_mps': measured,
                           'forward_planning_speed_mps': planning}
    return speed, steering, {**detail, 'measured_speed_mps': measured, 'reverse_motion': True,
        'forward_planning_speed_mps': planning, 'signed_motion_policy': 'forward_drive',
        'signed_history_preserved': True, 'rear_rollback_safety_verified': False}


class LocalFollow:
    def __init__(self, config=None):
        self.config = config or FollowConfig()
        self.partial_policy = None
        if self.config.partial_observation_policy != 'strict':
            from arena_autonomy.partial_observation import PartialObservationPolicy
            if self.config.traffic_recovery_trial:
                from arena_autonomy.traffic_recovery_trial import RecoveryPolicy
                PartialObservationPolicy = RecoveryPolicy
            if self.config.known_structure_policy != 'off':
                # 독립 보호층과 같은 구조 각도·같은 정책 클래스를 각자 입력으로 계산한다.
                from arena_autonomy.known_structure import structure_policy
                PartialObservationPolicy = structure_policy(PartialObservationPolicy,
                                                            self.config.known_structure_sectors_json)
            self.partial_policy = PartialObservationPolicy(allow_narrow_forward=True,
                surface_translation_enabled=self.config.partial_observation_policy in ('bounded_local_v3','bounded_local_v4'),
                lateral_metric_enabled=self.config.partial_observation_policy=='bounded_local_v4',
                oblique_metric_enabled=self.config.oblique_gap_trial and self.config.solo_route_only,
                crop_edge_component_trial=self.config.crop_edge_component_trial)
        self.observation_cache = None
        if self.config.recent_observation_enabled:
            from arena_autonomy.observation_support import RecentScenes
            self.observation_cache = RecentScenes()
        self.corridor_observer = None
        if self.config.corridor_fallback_enabled:
            # 관측기는 이 모듈의 순수 추종 함수를 사용한다. 생성 시 import하여 순환 초기화를 피한다.
            from arena_autonomy.corridor_observer import CorridorObserver
            self.corridor_observer = CorridorObserver(self.config)
        self.parallel_trial = None
        if self.config.parallel_hold_trial and not self.config.solo_route_only:
            from arena_autonomy.parallel_lane_trial import ParallelLaneTrial
            if self.config.rear_lane_keep_policy == 'observed_measured_v1':
                # 10/29 오프라인 v4와 같이 평행 후보도 측정속도를 자르지 않는 별도 시험본을 쓴다.
                from arena_autonomy.measured_parallel_trial import MeasuredParallelTrial as ParallelLaneTrial
            if self.config.rear_lane_keep_policy == 'observed_fresh_v2':
                from arena_autonomy.fresh_parallel_trial import FreshMemoryParallelTrial as ParallelLaneTrial
            self.parallel_trial = ParallelLaneTrial(self.config)
        self.pass_selector = None
        if self.config.pass_release_trial and not self.config.solo_route_only:
            from arena_autonomy.pass_release_trial import PassReleaseSelector
            if self.config.traffic_path_recovery_trial:
                from arena_autonomy.traffic_path_recovery_trial import SuspendedPassageSelector
                PassReleaseSelector = SuspendedPassageSelector
                if self.config.rear_lane_keep_trial:
                    from arena_autonomy.rear_lane_keep_trial import RearLaneKeepSelector
                    PassReleaseSelector = RearLaneKeepSelector
                    if self.config.rear_lane_keep_policy == 'observed':
                        from arena_autonomy.observed_lane_preference_trial import StraightLanePreferenceSelector
                        PassReleaseSelector = StraightLanePreferenceSelector
                    elif self.config.rear_lane_keep_policy in ('observed_measured_v1', 'observed_fresh_v2'):
                        from arena_autonomy.measured_lane_preference_trial import StraightLanePreferenceSelector
                        PassReleaseSelector = StraightLanePreferenceSelector
            if self.config.current_lane_preference_trial:
                from arena_autonomy.current_lane_preference import CurrentLaneSelector
                PassReleaseSelector = CurrentLaneSelector
            self.pass_selector = PassReleaseSelector(self.config)
        self.reset()

    def reset(self):
        if self.pass_selector is not None:
            # 센서/운영 중단을 '옆차가 없던 새 장면'으로 만들지 않는다.
            self.pass_selector.invalidate('controller_reset')
        if self.partial_policy is not None:
            self.partial_policy.reset()
        self.partial_epoch = None
        self._reset_path()

    def _reset_path(self):
        if self.parallel_trial is not None:
            self.parallel_trial.reset()
        if self.observation_cache is not None:
            self.observation_cache.reset()
        if self.corridor_observer is not None:
            self.corridor_observer.reset()
        self.path = self.pending = None
        self.path_ref = self.path_source = self.pending_ref = None
        self.recent_path = None  # junction_continuity 전용: 막 만료된 승인 경로(경로, 기준 시각, 원천 시각)
        self.pending_count = self.release_count = 0
        self.last_source = self.last_ref = None
        self.epoch = self.side = None
        self.path_wall = None
        self.held = True
        self.hold_reason = None

    def _discard_path(self):
        # 기존 파생 제어기의 reset() 동작은 보존한다. 새 관측 후보만 기억을 분리한다.
        if self.partial_policy is None:
            self.reset()
        else:
            self._reset_path()

    def _hold(self, reason, detail):
        self.held = True
        self.hold_reason = reason
        self.release_count = 0
        return 0., 0., {**detail, 'reason': reason, 'behavior': 'HOLD'}

    def command(self, scene, history, speed, side, previous_steering=0., control_dt=.02, *, raw_scan=None):
        planning = forward_planning_speed(self.config, speed)
        output = self._forward_command(scene, history, planning, side, previous_steering, control_dt,
                                        raw_scan=raw_scan)
        if self.config.solo_straight_budget_trial:
            from arena_autonomy.solo_straight_budget import evaluate
            new_speed, reason = evaluate(output, scene, previous_steering, speed, self.config)
            output = new_speed, output[1], {**output[2], 'solo_straight_budget': reason,
                                             'original_speed_mps': output[0]}
        if self.config.solo_corner_approach_trial:
            from arena_autonomy.solo_corner_approach import approach_speed
            new_speed, evidence = approach_speed(output, scene, self.config)
            output = new_speed, output[1], {**output[2], 'corner_approach': evidence}
        return signed_feedback_detail(output, speed, planning)

    def _forward_command(self, scene, history, speed, side, previous_steering=0., control_dt=.02, *, raw_scan=None):
        output = self._observed_command(scene, history, speed, side, previous_steering, control_dt,
                                        raw_scan=raw_scan)
        if self.parallel_trial is not None:
            parallel = self.parallel_trial.apply(scene, output, speed, previous_steering, control_dt)
            if self.pass_selector is not None:
                selected = self.pass_selector.select(scene, output, parallel, speed, previous_steering, control_dt,
                    **({'raw_scan': raw_scan} if self.config.guard_curve_trial else {}))
                if selected[2].get('selector_choice') == 'hold_fault':
                    return selected[0], selected[1], {**output[2], **selected[2]}
                return selected
            return parallel
        return output

    def _observed_command(self, scene, history, speed, side, previous_steering=0., control_dt=.02, *, raw_scan=None):
        if self.partial_policy is not None:
            return self._partial_command(scene,history,speed,side,previous_steering,control_dt,raw_scan)
        output = self._path_command(scene, history, speed, side, previous_steering, control_dt)
        if self.observation_cache is None:
            return output
        from arena_autonomy.observation_support import needs_recent_support, sweep_support
        required = needs_recent_support(scene)
        sources, reason = self.observation_cache.observe(scene, history, transport=required and output[0]>0)
        detail = {**output[2], 'recent_observation_selected':False,
                  'recent_observation':{'required':required, 'cache_reason':reason,
                                        'rear_dynamic_risk_unresolved':True}}
        if not required or output[0]<=0:
            return output[0], output[1], detail
        # 원래 속도를 올리지 않는다. 낮춘 목표를 현재 운동 속도 대신 쓰지도 않는다.
        target = min(.2, output[0])
        motion = history.config
        support = sweep_support(sources, speed, target, output[1], previous_steering, self.config,
            protected_sensor_pose=(motion.lidar_x_m,motion.lidar_y_m,motion.lidar_yaw_rad))
        detail['recent_observation'] = {**support, 'required':True, 'cache_reason':reason}
        if not support['supported']:
            if self.corridor_observer is not None:
                self.corridor_observer.clear_evidence()
            return self._hold('follow_observation_unconfirmed', detail)
        detail.update(recent_observation_selected=True, observation_speed_cap_mps=.2)
        return target, output[1], detail

    def _partial_command(self,scene,history,speed,side,previous_steering,control_dt,raw_scan):
        detail={'mode':'g1_follow','partial_observation_policy':self.config.partial_observation_policy,
                'passing_enabled':False,'relative_velocity_credit':False}
        if raw_scan is None:
            return self._hold('follow_partial_scan_missing',detail)
        source=scan_first_stamp(raw_scan)
        values=np.asarray(raw_scan.ranges,dtype=float)
        valid=np.isfinite(values)&(values>=raw_scan.range_min)&(values<=raw_scan.range_max)
        # 미관측/마스크를 유효점으로 바꾸지 않고 같은 입력의 scene만 받는다.
        if (scene.source_first_s!=source or scene.source_frame_id!=raw_scan.header.frame_id or
                len(scene.rays)!=len(values) or
                [r.source_index for r in scene.rays if r.status=='return']!=np.flatnonzero(valid).tolist()):
            return self._hold('follow_partial_scan_scene_mismatch',detail)
        if self.partial_epoch!=scene.source_epoch:
            self.partial_policy.reset()
            self.partial_epoch=scene.source_epoch
        # 여기서는 경로 후보만 만든다. 아래 관측 판정 전에 속도를 외부로 반환하지 않는다.
        # 구조 정책: 이번 스캔에서 양옆이 반환인 구조 광선(evaluate와 같은 순수 classify).
        # 증속 후보 전제에서만 이 광선을 빼며, 정책 상태는 바꾸지 않는다.
        explained_now=None
        if self.config.known_structure_policy!='off':
            from arena_autonomy.known_structure import classify
            explained_now=frozenset(np.flatnonzero(classify(raw_scan,self.partial_policy.structure_sectors)[1]).tolist())
        self.structure_explained_now=explained_now
        try:
            output=self._path_command(scene,history,speed,side,previous_steering,control_dt,allow_partial=True)
        finally:
            self.structure_explained_now=None
        cfg=self.config
        # 명시 r474 운용은 현재 경로/원시 점유/제동 계산을 먼저 결정한다.
        # 양수 후보를 다시 lateral 결측 폭이나 저속시험 범위 때문에 정지시키지
        # 않는다. 원시 ray/free·경로가 없을 때의 정지·기존 partial 상태는 바꾸지 않는다.
        from arena_autonomy.race_runtime_policy.current_route_priority import observed_command
        current_route=observed_command(cfg,scene,output,raw_scan,history.config.lidar_yaw_rad)
        if current_route is not None:
            return current_route
        # 경로의 큰 요청을 관측 관문에서 거절한 뒤 대기/재출발을 반복하지 않도록
        # 먼저 기존 저속 후보를 선택한다. 측정속도·기억·독립 보호 판정은 그대로다.
        original_oblique = self.partial_policy.oblique_metric_enabled
        if cfg.oblique_gap_trial and not cfg.solo_route_only:
            from arena_autonomy.traffic_solo_gap import eligible
            self.partial_policy.oblique_metric_enabled = eligible(
                self.pass_selector, scene, output, raw_scan, history.config.lidar_yaw_rad, explained_now)
        try:
            requested=self.partial_policy.requested_speed(raw_scan,history.config.lidar_yaw_rad,
                                                         output[0],explained_now)
            if requested!=output[0]:
                output=(requested,output[1],{**output[2],
                    'partial_original_requested_speed_mps':output[0],
                    'partial_requested_speed_mps':requested})
            observation=self.partial_policy.evaluate(raw_scan,scene.occupied_endpoints_xy_m,history,
                scene.t_ref_s,max(output[0],abs(speed)),output[1],previous_steering,
                cfg.wheelbase_m,cfg.length_m,cfg.width_m)
        finally:
            self.partial_policy.oblique_metric_enabled = original_oblique
        detail={**output[2],**detail,'partial_observation':observation}
        # raw 기준 밖 결측이 운동 변환 뒤 전방으로 들어온 경우를 몰래 허용하지 않는다.
        from arena_autonomy.scan_input import scan_angles
        angles=(scan_angles(raw_scan)+
                history.config.lidar_yaw_rad+math.pi)%math.tau-math.pi
        covered=set(np.flatnonzero((~valid)&(np.abs(angles)<=math.radians(100)+1e-6)))
        # 설명된 구조 광선은 구조 정책이 운동 보정 방향으로 따로 판정했다. 기본은 빈 집합.
        explained=getattr(self.partial_policy,'structure_excused_indices',frozenset())
        missing=[r for r in scene.rays if r.status!='return' and r.source_index not in explained and
                 abs(math.atan2(r.direction_xy[1],r.direction_xy[0]))<=math.radians(100)]
        if any(r.source_index not in covered for r in missing):
            return self._hold('follow_partial_transformed_gap_uncovered',detail)
        if not observation['allowed'] or speed<0:
            return self._hold('follow_'+('reverse_motion' if speed<0 else observation['reason']),detail)
        cap=observation['speed_cap_mps']
        if cap is not None and cap<=.001<output[0] and 'known_structure' in observation:
            # 구조 그림자/숨은 기억의 제동 제한으로 0이 된 명령. 경로 기억·대기 상태는 바꾸지 않는다.
            return 0.,output[1],{**detail,'reason':'follow_structure_shadow_stop','underlying_reason':detail.get('reason')}
        return (output[0] if cap is None else min(output[0],cap)),output[1],detail

    def _path_command(self, scene, history, speed, side, previous_steering=0., control_dt=.02, *, allow_partial=False):
        baseline = self._baseline_command(scene, history, speed, side, previous_steering, control_dt,
                                          **({'allow_partial':True} if allow_partial else {}))
        if self.corridor_observer is None:
            return baseline
        proposal = self.corridor_observer.evaluate(scene, history, speed, side, previous_steering, control_dt,
                                                  **({'partial_candidate':True} if allow_partial else {}))
        metadata = {k: proposal.get(k) for k in ('positive', 'reason', 'fresh', 'confirmations', 'release_count',
                                                'source_first_s', 'reference_s', 'swept_clearance_m')}
        cfg_short = self.config.short_boundary_prefix_enabled
        if cfg_short:
            metadata.update(short_prefix=proposal.get('short_prefix',False),
                            path_budget_m=proposal.get('path_budget_m'),stop_budget_m=proposal.get('stop_budget_m'))
        if self.config.traffic_path_recovery_trial:
            metadata.update({key: proposal.get(key) for key in
                             ('role_selection','preferred_side','inner_side','outer_side',
                              'preferred_observed_path_agrees')})
        if self.config.corridor_arc_agreement:
            metadata['path_agreement_method'] = proposal.get('path_agreement_method')
        detail = {**baseline[2], 'corridor_candidate': metadata,
                  'corridor_selected': False, 'boundary_memory_from_corridor': False}
        # 경로 근거 전환으로 걸린 재개 대기는 같은 스캔의 확인된 회랑이 잇는다. 점유·관측 정지는 잇지 않는다.
        waiting = (self.config.boundary_bridge and baseline[2]['reason'] == 'follow_release_wait'
                   and self.hold_reason == 'follow_boundary_unconfirmed')
        if not (baseline[0] == 0 and proposal['positive'] and
                (baseline[2]['reason'] == 'follow_boundary_unconfirmed' or waiting)):
            return baseline[0], baseline[1], detail
        # 기본 경계 기억에는 쓰지 않는다. 신호/고장 허가와 /drive 독립 보호는 상위에서 그대로 적용한다.
        points = scene.occupied_endpoints_xy_m
        padding = per_ray_padding(scene, .025+self.config.measurement_padding_m, self.config.object_motion_bound_mps)
        detail.update(reason='local_follow_corridor_candidate', behavior='FOLLOW', corridor_selected=True,
                      underlying_reason=baseline[2]['reason'], wall_identity_certified=False,
                      path_points=proposal['path'], path_source_s=scene.source_first_s,
                      boundary_age_s=scene.t_ref_s-scene.source_first_s, boundary_from_memory=False,
                      boundary_selection='current_paired_corridor_candidate', path_wall=None,
                      swept_clearance_m=proposal['swept_clearance_m'], unfiltered_occupancy=True,
                      occupied_points=len(points), occupancy_timing_mode=self.config.occupancy_timing_mode,
                      occupancy_padding_points=len(padding), occupancy_padding_m=float(np.max(padding)),
                      occupancy_padding_min_m=float(np.min(padding)), occupancy_padding_max_m=float(np.max(padding)),
                      target_speed_before_hold_mps=proposal['proposed_speed_mps'])
        if cfg_short and proposal.get('short_prefix'):
            detail['boundary_selection'] = 'current_short_observed_prefix_candidate'
        return proposal['proposed_speed_mps'], proposal['steering_rad'], detail

    def _recent_route_reference(self):
        reference = (self.path, self.path_ref, self.path_source)
        return reference+(self.path_wall,) if self.config.expiry_route_reference_trial else reference

    def _baseline_command(self, scene, history, speed, side, previous_steering=0., control_dt=.02, *, allow_partial=False):
        cfg, now = self.config, scene.t_ref_s
        detail = {'mode': 'g1_follow', 'source_first_s': scene.source_first_s,
                  'source_last_s': scene.source_last_s, 'source_epoch': scene.source_epoch,
                  'reference_stamp_s': now, 'preferred_wall': side,
                  'relative_velocity_credit': False, 'passing_enabled': False,
                  'measured_speed_mps': speed, 'reverse_motion': math.isfinite(speed) and speed < 0.}
        if (side not in ('left', 'right') or not all(math.isfinite(v) for v in (speed, previous_steering, control_dt))
                or not 0 < control_dt <= .2):
            self._discard_path()
            return self._hold('follow_invalid_state', detail)
        # 마커의 추종 벽 전환은 관측 경로의 무효가 아니다. 새 벽 후보를 다음 스캔에서 같은 기준으로 고른다.
        side_changed = self.side != side and not (cfg.boundary_bridge and self.path is not None)
        if (self.epoch != scene.source_epoch or side_changed or
                (self.last_ref is not None and now < self.last_ref) or
                (self.last_source is not None and scene.source_first_s is not None and
                 scene.source_first_s < self.last_source)):
            self._discard_path()
        self.epoch, self.side, self.last_ref = scene.source_epoch, side, now
        if scene.source_first_s is None or now-scene.source_first_s >= .3:
            self._discard_path()
            return self._hold('follow_scene_stale', detail)
        # 후방 사각은 직진 전체를 금지하지 않지만 전방 미관측은 현 보호와 같이 정지.
        front = [ray for ray in scene.rays if abs(math.atan2(ray.direction_xy[1], ray.direction_xy[0])) <= math.radians(100)]
        if not front or any(ray.status != 'return' for ray in front):
            from arena_autonomy.observation_support import side_missing_candidate
            if not (allow_partial or (cfg.recent_observation_enabled and side_missing_candidate(scene))):
                self._discard_path()
                return self._hold('follow_front_unobserved', detail)
            # 경로 계산만 허용한다. command()의 실제 관측 지지 없이는 양수 출력을 반환하지 않는다.
        points = np.asarray(scene.occupied_endpoints_xy_m, dtype=float).reshape(-1, 2)
        if len(points) < 30:
            self._discard_path()
            return self._hold('follow_scan_invalid', detail)
        fresh = self.last_source is None or scene.source_first_s > self.last_source
        self.last_source = scene.source_first_s
        age = now-scene.source_first_s
        # 고속용도 관측 벽에서만 더 멀리 본다. 값은 탐색 길이이며 자유 공간이 아니다.
        cruise = cfg.open_route_speed_mps
        horizon = max(1.8, .06 + cfg.standstill_gap_m + cruise*(age+.10) + cruise**2/4)
        ray_index = None
        if cfg.ray_wall_continuity and fresh:
            # 경계 선택이 넘기는 부분집합도 같은 실제 점이므로 좌표로 원시 광선 번호를 찾는다.
            ray_index = dict(zip(map(tuple, points.tolist()),
                                 (r.source_index for r in scene.rays if r.status == 'return')))
        bridge = {'narrow_occluder_bridge': True} if cfg.narrow_occluder_bridge else {}
        def observed_path(cloud, wall_side):
            if cfg.piecewise_wall_trial:
                path, info = local_path(cloud, wall_side, cfg.wall_offset_m, horizon=horizon,
                                  rays=None if ray_index is None else [ray_index[tuple(p)] for p in cloud.tolist()],
                                  piecewise_corner=True, minimum_radius=cfg.wheelbase_m/math.tan(cfg.max_steering_rad),
                                  **bridge)
                if cfg.traffic_boundary_refresh_trial and info.get('wall_model') != 'piecewise_corner':
                    from arena_autonomy.fragmented_wall_hypothesis import propose
                    candidate, evidence = propose(cloud, wall_side, cfg.wall_offset_m,
                                                  cfg.wheelbase_m/math.tan(cfg.max_steering_rad))
                    if candidate is not None and (path is None or path_agrees(candidate,path,cfg.boundary_agreement_m)):
                        from arena_autonomy.local_path import _path_ahead, _origin_error
                        sign = 1 if wall_side == 'left' else -1
                        index = int(np.argmin(np.linalg.norm(cloud-[0.,sign*cfg.wall_offset_m],axis=1)))
                        return candidate, dict(reason='local_path',wall_model='observed_fragment_corner',
                            boundary_samples=evidence['points_used'],boundary_observed_ahead_m=_path_ahead(candidate),
                            wall_distance_m=abs(float(cloud[index,1])),path_anchor_error_m=_origin_error(candidate),
                            path_points=candidate.tolist(),fragment_hypothesis={k:v for k,v in evidence.items()
                            if k not in ('source_indices','occluder_indices')})
                return path,info
            if ray_index is not None:
                return local_path(cloud, wall_side, cfg.wall_offset_m, horizon=horizon,
                                  rays=[ray_index[tuple(p)] for p in cloud.tolist()], **bridge)
            if horizon == 1.8:
                return local_path(cloud, wall_side, cfg.wall_offset_m, **bridge)
            return local_path(cloud, wall_side, cfg.wall_offset_m, horizon=horizon, **bridge)
        carried = None
        try:
            if self.path is not None and now-self.path_source < cfg.memory_ttl_s:
                carried = transport_points(self.path, history, self.path_ref, now)
                moved = np.linalg.norm(carried-self.path, axis=1)
                if cfg.boundary_bridge:
                    # 기본 탐색 길이 밖 점의 회전 지렛대로 같은 운동을 큰 이동으로 세지 않는다.
                    moved = moved[np.linalg.norm(self.path, axis=1) <= 1.8]
                if len(moved) and np.max(moved) > cfg.memory_motion_limit_m:
                    carried = None
            if fresh:
                candidate, info = observed_path(points, side)
                preferred, preferred_info = candidate, info
                candidate_wall, corroborated = side, False
                def sufficient(path, details):
                    return (path is not None and details['boundary_observed_ahead_m'] >= cfg.boundary_min_ahead_m
                            and anchor_error(details, cfg) <= cfg.boundary_anchor_error_m)

                def supported(reference, wall_side):
                    # 기준 경로와 일치하는 실제 반환만으로 wall_side 벽 후보를 다시 만든다.
                    # 그 후보 자체가 긴 경계·anchor 조건과 형상 일치를 모두 만족해야 한다.
                    selected = boundary_support(points, reference, wall_side, cfg)
                    path, details = observed_path(selected, wall_side)
                    ok = sufficient(path, details) and path_agrees(path, reference, cfg.boundary_agreement_m)
                    dropped = 0
                    if not ok:
                        refined = drop_protrusions(selected, reference, wall_side, cfg)
                        if len(refined) < len(selected):
                            path, details = observed_path(refined, wall_side)
                            ok = sufficient(path, details) and path_agrees(path, reference, cfg.boundary_agreement_m)
                            dropped = len(selected)-len(refined)
                    return path, details, ok, {'boundary_support_points': len(selected),
                                               'boundary_protrusions_removed': dropped}
                eligible = sufficient(candidate, info)
                detail['boundary_selection'] = 'unfiltered'
                if carried is not None:
                    if eligible and cfg.solo_route_only and cfg.corridor_arc_agreement:
                        # 현재 충분히 관측된 긴 벽만 비교한다. 코너 출구의 같은 x좌표 때문에
                        # 이력이 거절되는 경우 기존 공통 호길이 비교를 재사용한다.
                        match = retained_boundary_agreement(candidate, carried, info, cfg)
                        eligible = match is not None
                        if match == 'shared_arc':
                            detail['boundary_history_agreement'] = 'current_corner_arc'
                    elif (eligible and cfg.junction_continuity and cfg.expiry_route_reference_trial
                            and cfg.piecewise_wall_trial and self.path_wall == side
                            and info.get('wall_model') == 'piecewise_corner'):
                        # 동일 벽의 충분한 현재 관측과 유효 이력만 비교한다. 코너 출구의
                        # x 창 길이 차이로 갱신을 놓치지 않게 기존 호길이 비교를 재사용한다.
                        # 초기/만료 경로 획득, 벽 전환, TTL과 이후 점유 검사는 그대로다.
                        eligible = path_agrees(candidate, carried, cfg.boundary_agreement_m)
                        if not eligible and path_agrees_arc(candidate, carried, cfg.boundary_agreement_m):
                            eligible = True
                            detail['boundary_history_agreement'] = 'current_same_wall_corner_arc'
                    else:
                        eligible = eligible and path_agrees(candidate, carried, cfg.boundary_agreement_m)
                    if not eligible:
                        candidate, info, eligible, support = supported(carried, side)
                        detail.update(boundary_selection='observed_history_support', **support)
                other_side = 'right' if side == 'left' else 'left'
                opposite_observed = []

                def opposite_wall():
                    if not opposite_observed:
                        opposite_observed.append(observed_path(points, other_side))
                    return opposite_observed[0]
                if (cfg.junction_continuity and carried is not None
                        and self.path_wall == other_side):
                    # 본선의 반대 벽을 이미 선택했다면 현재도 보이는 그 벽을 먼저 갱신한다.
                    # 갈림길로 열린 선호 벽으로 매 스캔 되돌아가며 경로를 조금씩 꺾지 않는다.
                    opposite, other = opposite_wall()
                    if (sufficient(opposite, other) and path_agrees(opposite, carried, cfg.boundary_agreement_m)
                            and (not sufficient(preferred, preferred_info)
                                 or not path_agrees_arc(preferred, opposite, cfg.boundary_agreement_m))):
                        candidate, info, candidate_wall, eligible = opposite, other, other_side, True
                        detail['boundary_selection'] = 'junction_retained_wall_refresh'
                # 단독 호길이 비교도 이미 선택한 반대 벽 갱신에 연결한다. 현재 긴 벽과
                # 유효한 같은 벽의 이력만 비교하며, 신규 벽 선택이나 관측 만료는 허용하지 않는다.
                if (not eligible and (cfg.traffic_boundary_refresh_trial
                                      or (cfg.solo_route_only and cfg.corridor_arc_agreement)) and carried is not None
                        and self.path_wall == other_side):
                    opposite, other = opposite_wall()
                    retained_match = (retained_boundary_agreement(opposite, carried, other, cfg)
                                      if sufficient(opposite, other) else None)
                    if retained_match is not None:
                        candidate,info,candidate_wall,eligible = opposite,other,other_side,True
                        detail['boundary_selection']='current_retained_wall_refresh'
                        detail['retained_boundary_agreement']=retained_match
                if (not eligible and cfg.traffic_boundary_refresh_trial and carried is not None
                        and sufficient(preferred, preferred_info)
                        and retained_boundary_agreement(preferred, carried, preferred_info, cfg) == 'shared_arc'):
                    # 기존 경계의 현재 관측 갱신을 먼저 시도한다. 실패한 경우에만 선호 벽의
                    # 충분한 현재 직각 경로를 같은 유효 이력과 대조한다. 점유 검사는 이후 유지한다.
                    candidate, info, candidate_wall, eligible = preferred, preferred_info, side, True
                    detail['boundary_selection'] = 'current_corner_alternative_agreement'
                    detail['current_corner_agreement'] = 'shared_arc'
                if not eligible and preferred is not None and anchor_error(preferred_info, cfg) <= cfg.boundary_anchor_error_m:
                    # 급커브 안쪽 벽은 짧아질 수 있다. 반대 벽만 보고 전환하지 않고,
                    # 같은 스캔의 실제 선호 벽 경로와 중심 형상이 일치할 때만 사용한다.
                    # 채택할 반대 벽에는 원래의 긴 경계 조건을 그대로 요구한다.
                    opposite, other = opposite_wall()
                    if (sufficient(opposite, other) and path_agrees(opposite, preferred, cfg.boundary_agreement_m)
                            and (carried is None or path_agrees(opposite, carried, cfg.boundary_agreement_m))):
                        candidate, info, candidate_wall = opposite, other, other_side
                        eligible, corroborated = True, True
                        detail['boundary_selection'] = 'bilateral_confirmed_alternative'
                bilateral = corroborated
                if not eligible:
                    # 선호 벽 앞의 얇은 물체가 연결을 끊었거나 그 물체가 기억 경로 범위 밖이면
                    # 같은 스캔의 긴 반대 벽을 기준으로 선호 벽의 실제 반환을 다시 고른다.
                    # 선호 벽 후보 자체가 긴 경계·앵커·형상 일치를 모두 만족해야 하는 양측
                    # 확인이며, 기억이 있으면 그 기억과도 일치해야 한다.
                    opposite, other = opposite_wall()
                    if sufficient(opposite, other):
                        reselected, reselected_info, bilateral, support = supported(opposite, side)
                        bilateral = bilateral and (carried is None or
                                                   path_agrees(reselected, carried, cfg.boundary_agreement_m))
                        if bilateral:
                            candidate, info, eligible = reselected, reselected_info, True
                            detail.update(boundary_selection='bilateral_reference_support', **support)
                detail['boundary_candidate_reason'] = info['reason']
                detail['boundary_candidate_ahead_m'] = info.get('boundary_observed_ahead_m')
                if info.get('narrow_occluders_bridged'):
                    detail['narrow_occluders_bridged'] = info['narrow_occluders_bridged']
                detail['bilateral_alternative_confirmed'] = corroborated
                if eligible and carried is None and not bilateral:
                    # 초기/만료 뒤 재획득에는 반대쪽의 독립된 긴 관측도 일치해야 한다.
                    opposite, other = opposite_wall()
                    eligible = sufficient(opposite, other) and path_agrees(candidate, opposite, cfg.boundary_agreement_m)
                    if (not eligible and cfg.low_speed_arc_reacquire and abs(speed) <= .10
                            and sufficient(opposite, other)
                            and path_agrees_arc(candidate, opposite, cfg.boundary_agreement_m)):
                        # 측정 평균 속도가 낮을 때만 쓴다. 단일 축이라 실제 정지를 증명하지 않으며
                        # 이후 확인 횟수·점유·재개 여유·독립 보호는 기존 판정을 그대로 따른다.
                        eligible = True
                        detail['bilateral_reference'] = 'low_speed_arc'
                    if not eligible:
                        # 반대 벽 앞의 얇은 물체도 같은 실제 반환 선택으로만 제외한다.
                        _, _, eligible, support = supported(candidate, other_side)
                        if eligible:
                            detail.update(bilateral_reference='opposite_support',
                                          opposite_support_points=support['boundary_support_points'],
                                          opposite_protrusions_removed=support['boundary_protrusions_removed'])
                    if not eligible and cfg.standing_wall_reacquire and abs(speed) <= .10 and sufficient(candidate, info):
                        # 재개 직후 합류부처럼 반대쪽이 열리면 양측 일치가 영영 풀리지 않는다. 선호 벽의 긴 현재
                        # 관측만 쓰며 확인 횟수·점유·재개 여유·독립 보호는 그대로 둔다. 빈 공간을 경로로 만들지 않는다.
                        eligible = True
                        detail['bilateral_reference'] = 'standing_preferred_wall'
                if not eligible and cfg.boundary_evidence_mode in ('fragmented_candidate', 'corner_anchor_candidate', 'corner_distance_candidate'):
                    # 긴 반대 벽은 그대로 관측되어야 한다. 선호 벽의 각 실제 조각이
                    # 그 형상을 지지해야 하며 가림 간격은 길이/자유 공간 증거가 아니다.
                    opposite, other = opposite_wall()
                    if sufficient(opposite, other):
                        evidence = fragment_evidence(points, opposite, side, cfg)
                        agrees_memory = carried is None or path_agrees(opposite, carried, cfg.boundary_agreement_m)
                        detail['fragmented_boundary_evidence'] = {**evidence,
                            'fragments': [{k: v for k, v in part.items() if k != 'source_indices'}
                                          for part in evidence['fragments']]}
                        detail['fragmented_agrees_memory'] = bool(agrees_memory)
                        if evidence['supported'] and agrees_memory:
                            candidate, info, candidate_wall = opposite, other, other_side
                            eligible, bilateral = True, True
                            detail['boundary_selection'] = 'bilateral_observed_fragments'
                            detail['boundary_candidate_reason'] = info['reason']
                            detail['boundary_candidate_ahead_m'] = info.get('boundary_observed_ahead_m')
                if not eligible and cfg.boundary_evidence_mode == 'corner_anchor_candidate':
                    # 직선/분리 경계 계약은 유지한다. 급커브에서만 현재 차체를
                    # 가로지르는 실제 안쪽 벽과 긴 바깥 경로를 직접 대조한다.
                    opposite, other = opposite_wall()
                    if sufficient(opposite, other):
                        evidence = corner_anchor_evidence(points, opposite, side, cfg)
                        agrees_memory = carried is None or path_agrees(opposite, carried, cfg.boundary_agreement_m)
                        detail['corner_boundary_evidence'] = {k: v for k, v in evidence.items()
                                                              if k != 'source_indices'}
                        detail['corner_agrees_memory'] = bool(agrees_memory)
                        if evidence['supported'] and agrees_memory:
                            candidate, info, candidate_wall = opposite, other, other_side
                            eligible, bilateral = True, True
                            detail.update(boundary_selection='bilateral_observed_corner_anchor',
                                          boundary_candidate_reason=info['reason'],
                                          boundary_candidate_ahead_m=info.get('boundary_observed_ahead_m'))
                if not eligible and cfg.boundary_evidence_mode == 'corner_distance_candidate':
                    opposite, other = opposite_wall()
                    if sufficient(opposite, other):
                        evidence = corner_distance_evidence(points, opposite, side, cfg)
                        detail['corner_distance_evidence'] = {k: v for k, v in evidence.items()
                                                              if k != 'source_indices'}
                        retained = (opposite[:evidence['path_end_exclusive']]
                                    if evidence['supported'] else None)
                        agrees_memory = (retained is not None and (carried is None or
                            path_agrees(retained, carried, cfg.boundary_agreement_m)))
                        detail['corner_distance_agrees_memory'] = bool(agrees_memory)
                        if evidence['supported'] and agrees_memory:
                            candidate, info, candidate_wall = retained, other, other_side
                            eligible, bilateral = True, True
                            detail.update(boundary_selection='bilateral_observed_corner_distance',
                                          boundary_candidate_reason=info['reason'],
                                          boundary_candidate_ahead_m=info.get('boundary_observed_ahead_m'))
                if not eligible and carried is not None:
                    prefix, prefix_match = traffic_corner_prefix(preferred, carried, preferred_info, cfg)
                    if prefix_match is not None:
                        # 미관측 연장 없이 현재 보이는 짧은 경로로 교체한다. 긴 벽의 초기
                        # 확보 기준은 유지하고, 현재 길이의 제동/조향/원시 점유를 다시 검사한다.
                        candidate, info, candidate_wall, eligible = prefix, preferred_info, side, True
                        detail['current_corner_observed_wall_ahead_m'] = preferred_info['boundary_observed_ahead_m']
                        detail['boundary_selection'] = 'current_corner_prefix_agreement'
                        detail['current_corner_prefix_agreement'] = prefix_match
                if not eligible and cfg.junction_continuity and carried is not None:
                    # 짧은 선호 벽으로 경로 길이를 줄이기 전에, 승인 경로와 일치하는
                    # 긴 현재 반대 벽을 쓴다. 점유·제동·독립 보호 입력은 그대로 둔다.
                    opposite, other = opposite_wall()
                    prefix_anchor = (retained_forward_prefix(opposite, carried, other, cfg)
                                     if self.path_wall == other_side else None)
                    if ((sufficient(opposite, other) and path_agrees(opposite, carried, cfg.boundary_agreement_m))
                            or prefix_anchor is not None):
                        candidate, info, candidate_wall, eligible = opposite, other, other_side, True
                        detail.update(boundary_selection='junction_opposite_continuity',
                                      boundary_candidate_reason=info['reason'],
                                      boundary_candidate_ahead_m=info.get('boundary_observed_ahead_m'))
                        if prefix_anchor is not None:
                            detail['retained_forward_prefix'] = prefix_anchor
                if (not eligible and cfg.boundary_bridge
                        and carried is not None and preferred is not None
                        and anchor_error(preferred_info, cfg) <= cfg.boundary_anchor_error_m
                        and path_agrees(preferred, carried, cfg.boundary_agreement_m)):
                    # 긴 경계 조건만 못 채운 현재 관측이 직전 경로와 겹친다. 더 짧은 현재 경로로 줄여 쓴다.
                    candidate, info, eligible = preferred, preferred_info, True
                    detail['boundary_selection'] = 'short_current_history_agreement'
                if (not eligible and cfg.traffic_boundary_refresh_trial and cfg.piecewise_wall_trial
                        and carried is not None and self.path_wall in ('left', 'right')):
                    from arena_autonomy.corner_boundary_support import propose
                    supported_corner, support_evidence = propose(points, carried, self.path_wall,
                                                                  cfg, now-self.path_source, scene=scene)
                    detail['current_corner_support'] = {k: v for k, v in support_evidence.items()
                        if not k.endswith('_indices')}
                    far_support = support_evidence.get('far_occlusion_support')
                    if far_support is not None:
                        detail['current_corner_support']['far_occlusion_support'] = {
                            k: v for k, v in far_support.items() if not k.endswith('_indices')}
                    if supported_corner is not None:
                        candidate, candidate_wall, eligible = supported_corner, self.path_wall, True
                        # 두 관측 면 사이 교차점은 경로 가설이다. 미관측 길이를 관측 길이로 기록하지 않는다.
                        info = dict(reason='local_path', wall_model='current_two_face_corner',
                            boundary_observed_ahead_m=None,
                            path_anchor_error_m=support_evidence['path_anchor_error_m'])
                        detail.update(boundary_selection='current_two_face_corner_support',
                            boundary_candidate_reason=info['reason'], boundary_candidate_ahead_m=None,
                            corner_supported_path_ahead_m=support_evidence['path_ahead_m'])
                recent_confirmed = False
                if cfg.junction_continuity and carried is None:
                    # 갈림길 열림으로 한 스캔의 선호 벽이 짧아져 기억이 막 만료된 경우, 그 승인 경로를
                    # 운동 보정한 것과 가까운 전방에서 일치하는 현재 긴 관측(선호 벽 먼저)만 다시 받는다.
                    # 기억으로 주행하지 않고 미관측을 채우지 않는다. 양측 확인 없는 첫 재획득을 줄이는 대체다.
                    recent = None
                    reference = getattr(self, 'recent_path', None)
                    if (self.path is not None and self.path_source is not None
                            and cfg.memory_ttl_s <= now-self.path_source <= 2*cfg.memory_ttl_s
                            and (reference is None or self.path_source > reference[2])):
                        # 막 만료된 승인 경로는 아래 HOLD 이후에야 recent_path로 옮겨졌다.
                        # 주행 기억으로 되살리지 않고 이번의 충분한 현재 관측을 비교하는 데만
                        # 즉시 쓴다. 계산 간격이 200ms일 때 반복되는 한 주기 정지를 막는다.
                        reference = self._recent_route_reference()
                    if reference is not None and 0 <= now-reference[2] <= 2*cfg.memory_ttl_s:
                        recent = transport_points(reference[0], history, reference[1], now)
                        # 창을 TTL의 두 배로 둔 만큼 운동 보정 이동 한도도 같은 비율로만 늘린다.
                        if np.max(np.linalg.norm(recent-reference[0], axis=1)) > 2*cfg.memory_motion_limit_m:
                            recent = None
                    reference_wall = (reference[3] if cfg.expiry_route_reference_trial
                                      and reference is not None and len(reference) == 4 else None)
                    if (candidate is not None and recent is not None and reference_wall is not None
                            and candidate_wall != reference_wall
                            and not path_agrees_arc(candidate, recent, cfg.boundary_agreement_m)):
                        eligible = False
                        detail['expiry_route_switch_rejected'] = 'forward_path_diverges'
                    if (recent is not None and eligible and sufficient(candidate, info)
                            and path_agrees(candidate, recent, cfg.boundary_agreement_m)):
                        recent_confirmed = True
                        detail['recent_boundary_confirmation'] = 'current_observation_after_memory_expiry'
                    elif recent is not None and not eligible:
                        for path, details, wall_side in ((preferred, preferred_info, side), (*opposite_wall(), other_side)):
                            if (sufficient(path, details) and path_agrees(path, recent, cfg.boundary_agreement_m)
                                    and (reference_wall is None or wall_side == reference_wall
                                         or path_agrees_arc(path, recent, cfg.boundary_agreement_m))):
                                candidate, info, candidate_wall = path, details, wall_side
                                eligible = recent_confirmed = True
                                detail.update(boundary_selection='junction_recent_path_agreement',
                                              boundary_candidate_reason=info['reason'],
                                              boundary_candidate_ahead_m=info.get('boundary_observed_ahead_m'))
                                break
                if (eligible and cfg.junction_continuity and carried is not None
                        and candidate_wall != self.path_wall
                        and not path_agrees_arc(candidate, carried, cfg.boundary_agreement_m)):
                    # 가까운 접선은 같아도 약 1 m 안에서 갈라지는 다른 벽 경로는
                    # 본선 갱신으로 받지 않는다. 한 스캔 누락이면 기존 TTL 경로만 남긴다.
                    # 경로 끝 밖 외삽이나 TTL 연장은 하지 않는다.
                    eligible = False
                    detail['junction_wall_switch_rejected'] = 'forward_path_diverges'
                if eligible:
                    confirmed = carried is not None or recent_confirmed
                    if not confirmed:
                        old = (transport_points(self.pending, history, self.pending_ref, now)
                               if self.pending is not None and now-self.pending_ref <= cfg.memory_ttl_s else None)
                        self.pending_count = self.pending_count+1 if old is not None and path_agrees(candidate, old, cfg.boundary_agreement_m) else 1
                        self.pending, self.pending_ref = candidate.copy(), now
                        confirmed = self.pending_count >= cfg.confirmations
                    if confirmed:
                        self.path, self.path_ref, self.path_source = candidate.copy(), now, scene.source_first_s
                        self.path_wall = candidate_wall
                        self.recent_path = None
                        carried = candidate
                else:
                    self.pending = None
                    self.pending_count = 0
                detail['fresh_boundary_accepted'] = bool(eligible and self.path_source == scene.source_first_s)
            if carried is None:
                if cfg.junction_continuity and self.path is not None:
                    self.recent_path = self._recent_route_reference()
                self.path = None
                return self._hold('follow_boundary_unconfirmed', detail)
            memory_age = now-self.path_source
            # 단독 선택에서는 양측 근거로 이미 승인한 현재 반대 벽 경로도 쓴다.
            # 관측이 없는 경로/기억만 남은 경로/교통 모드의 속도 범위는 넓히지 않는다.
            # 구조 적응 경로에서는 이번 스캔의 설명된 구조 광선만 증속 전제에서 뺀다.
            # 그 밖의 결측이 있으면 기본 목표만 내어 v4 예산·감속 판단을 받는다(1.2 m/s
            # 초과 후보가 결측 판정을 정지로 바꾸지 않게). 아직 후보일 뿐이며 _partial_command가
            # 그림자/기억/예상 밖 결측을 검사한 후에만 발행한다. 독립 보호층도 같은 검사를 수행한다.
            explained = getattr(self, 'structure_explained_now', None)
            structure_candidate = bool(allow_partial and cfg.known_structure_policy == 'structure_aware_v1' and
                                       explained is not None and front and
                                       all(r.status == 'return' or r.source_index in explained for r in front))
            front_ready = bool(front and all(r.status == 'return' for r in front))
            open_route = bool(cruise and self.path_source == scene.source_first_s and
                              (self.path_wall == side or cfg.solo_route_only) and
                              (front_ready or structure_candidate))
            cap, desired, remaining = pursue_path(carried, speed, cfg, max(age, memory_age),
                                                  speed_cap=cruise if open_route else None,
                                                  **({'shape_diagnostic': detail} if cfg.solo_straight_budget_trial and open_route else {}))
            if cruise:
                detail.update(open_route_speed_enabled=open_route, open_route_cap_mps=cruise,
                              observed_search_horizon_m=horizon,
                              open_route_requires_structure_check=bool(open_route and not front_ready))
            if open_route and cfg.blend_open_speed_by_length:
                # 받은 경로의 길이가 줄면 통상 속도 위에 더한 부분만 걷는다.
                # 현재 경로/제동/곡률 한도보다 빠르게 하거나 빈 공간을 가정하지 않는다.
                share = float(np.clip((remaining - 1.10) / (1.70 - 1.10), 0., 1.))
                length_cap = cfg.max_speed_mps + share * (cruise - cfg.max_speed_mps)
                cap = min(cap, length_cap)
                detail['observed_length_speed_cap_mps'] = length_cap
            # WallFollow의 3 rad/s 명령 변화율을 반영한 실제 이번 발행각도 평가한다.
            steering = float(np.clip(desired, previous_steering-3*control_dt, previous_steering+3*control_dt))
            margin = .025 + cfg.measurement_padding_m + cfg.object_motion_bound_mps*age
            if cfg.occupancy_timing_mode == 'per_ray_candidate':
                margin = per_ray_padding(scene, .025+cfg.measurement_padding_m, cfg.object_motion_bound_mps)
                detail.update(occupancy_timing_mode=cfg.occupancy_timing_mode,
                    occupancy_padding_min_m=float(np.min(margin)),
                    occupancy_padding_max_m=float(np.max(margin)),
                    occupancy_padding_points=len(margin))
            clearance = min(swept_limit(points, angle, cfg.wheelbase_m, horizon=max(2.5,horizon) if open_route else 2.5, margin=margin,
                                         length=cfg.length_m, width=cfg.width_m)
                            for angle in (steering, previous_steering))
            from arena_autonomy.vehicle_marker_occupancy import additional_clearance
            clearance = additional_clearance(clearance, steering, previous_steering, cfg,
                horizon=max(2.5,horizon) if open_route else 2.5)
            available = max(0., clearance-cfg.standstill_gap_m)
            target = min(cap, braking_speed(available, age), available/cfg.headway_s)
            detail.update(path_source_s=self.path_source, boundary_age_s=memory_age,
                boundary_from_memory=self.path_source != scene.source_first_s, path_wall=self.path_wall,
                wall_fallback=self.path_wall != side, path_points=carried.tolist(), observed_path_ahead_m=remaining,
                swept_clearance_m=clearance, occupancy_padding_m=float(np.max(margin)), occupied_points=len(points),
                unfiltered_occupancy=True, target_speed_before_hold_mps=target)
            if speed < 0.:
                # 유한한 signed 피드백은 입력 무효/시간 세대 변경이 아니다. 현재
                # 관측·signed 운동 보정·경계/점유 검사는 유지하되 전진은 금지한다.
                # 매 역방향 표본마다 재개 확인을 지워 지속 역행 중 주행하지 않으며,
                # 정상 측정 복귀 뒤에도 기존 서로 다른 두 fresh 관측을 요구한다.
                return self._hold('follow_reverse_motion', detail)
            if clearance <= cfg.hold_clearance_m:
                if (cfg.low_speed_arc_reacquire or
                    (cfg.standing_wall_reacquire and self.path_source == scene.source_first_s)) and abs(speed) <= .10:
                    # 속도 0을 유지한 채 조향만 경로 쪽으로 돌린다. 전진은 재개 여유와 독립 보호가 정한다.
                    # 스캔 말미의 시간 여유 증가로 생긴 낮은 값이 새 스캔의 재개 계수를 지우지 않게 한다.
                    self.held = True
                    return 0., steering, {**detail, 'reason': 'follow_steer_in_place', 'behavior': 'HOLD'}
                return self._hold('follow_gap_hold', detail)
            if self.held:
                if clearance < cfg.resume_clearance_m:
                    self.release_count = 0
                elif fresh:
                    self.release_count += 1
                if self.release_count < cfg.confirmations:
                    return 0., steering, {**detail, 'reason': 'follow_release_wait', 'behavior': 'HOLD'}
                self.held = False
            if (cfg.preview_turn_speed and open_route and 0. < target
                    and (target <= cfg.max_speed_mps or cfg.preview_above_base_speed)
                    and target < cap and clearance >= cfg.resume_clearance_m):
                from arena_autonomy.turn_preview import preview_speed
                before = target
                target, reason = preview_speed(scene, carried, cfg, speed, steering, previous_steering,
                                              age, cap, target, clearance, remaining)
                detail.update(turn_preview=reason, constant_arc_target_mps=before,
                              target_speed_before_hold_mps=target)
            behavior = 'FOLLOW' if target < cap-1e-6 else 'CRUISE'
            return float(target), steering, {**detail, 'reason': 'local_follow', 'behavior': behavior}
        except MotionUnavailable as error:
            self._discard_path()
            return self._hold('follow_'+str(error), detail)
