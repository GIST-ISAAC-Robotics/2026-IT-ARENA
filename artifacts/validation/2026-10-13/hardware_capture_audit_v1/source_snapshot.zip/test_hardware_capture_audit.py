from copy import deepcopy
import math

import pytest

from audit_hardware_capture import audit, read_capture, main


def header():
    return dict(kind='header', schema='arena_hardware_capture_v1', origin='synthetic',
                device_clock='mcu_monotonic_us', receive_clock='host_monotonic_ns',
                encoder_unit='extended_signed_motor_counts', gyro_unit='rad/s', gyro_frame='imu_link',
                mounting_note='synthetic x forward y left z up; not a mounting decision',
                motor_spec=dict(counts_per_motor_revolution=28, gear_ratio=15., wheel_radius_m=.0325))


def records(count_step=0):
    result = []
    for i in range(5):
        common = dict(boot='first', seq=i, capture_us=100000+i*10000, receive_ns=8_000_000_000+i*10_000_000)
        result += [dict(kind='encoder', motor_counts=count_step*i, **common),
                   dict(kind='imu', gyro_rad_s=[.01, -.02, .03], **common)]
    return result


def test_valid_capture_is_not_drive_authorization_or_absolute_delay():
    result = audit(header(), records(10))
    assert result['record_integrity_valid']
    assert not result['ready_to_drive'] and not result['absolute_transport_delay_measured']
    assert result['counts_per_mean_wheel_revolution'] == 420
    assert result['mean_wheel_travel_mm_per_count'] == pytest.approx(math.pi*65/420)
    encoder = result['streams'][0]
    assert encoder['mean_wheel_speed_mps']['median'] == pytest.approx(math.pi*.065/420*1000)


@pytest.mark.parametrize('key,value', [('gyro_unit', 'deg/s'), ('encoder_unit', 'wheel_counts'),
                                     ('receive_clock', 'ros_clock'), ('origin', 'unknown')])
def test_units_are_not_silently_converted(key, value):
    config = header()
    config[key] = value
    with pytest.raises(ValueError):
        audit(config, records())


@pytest.mark.parametrize('field,value,reason', [('seq', 0, 'sequence_not_increasing'),
                                              ('capture_us', 999, 'device_capture_not_increasing'),
                                              ('receive_ns', 1, 'host_receive_clock_regressed')])
def test_regressions_are_reported_not_retimed(field, value, reason):
    rows = records()
    rows[2][field] = value
    result = audit(header(), rows)
    assert not result['record_integrity_valid']
    assert reason in [issue['reason'] for issue in result['issues']]


def test_sequence_gap_is_counted_without_claiming_sensor_loss():
    rows = records()
    for row in rows[2:]:
        if row['kind'] == 'encoder':
            row['seq'] += 3
    result = audit(header(), rows)
    assert result['record_integrity_valid']
    assert result['streams'][0]['missing_sequence_numbers'] == 3


def test_new_boot_splits_counter_and_time_without_false_speed():
    rows = records(10)
    for row in records(2):
        rows.append({**row, 'boot': 'second', 'receive_ns': row['receive_ns']+1_000_000_000})
    result = audit(header(), rows)
    assert result['record_integrity_valid'] and result['boot_changes_require_explicit_rearm']
    assert len(result['streams']) == 4
    assert all(s['capture_interval_s']['maximum'] == .01 for s in result['streams'])


def test_old_boot_reappearance_rejected():
    rows = records()
    rows[4]['boot'] = 'second'
    result = audit(header(), rows)
    assert any(issue['reason'] == 'old_boot_reappeared' for issue in result['issues'])


def test_no_stationary_inference_from_zero_counts():
    result = audit(header(), records())
    assert result['stationary_windows'] == []


def test_external_stationary_window_only_proposes_unapplied_bias():
    config = header()
    config['externally_stationary_windows'] = [dict(boot='first', first_us=100000, last_us=140000,
                                                  basis='synthetic externally immobilized fixture')]
    result = audit(config, records())
    candidate = result['stationary_windows'][0]
    assert candidate['candidate_bias_rad_s'] == pytest.approx([.01, -.02, .03])
    assert not candidate['applied'] and not candidate['chassis_stationarity_verified']
    moving = audit(config, records(1))['stationary_windows'][0]
    assert moving['candidate_bias_rad_s'] is None


@pytest.mark.parametrize('value', [True, 1.2, 2**63, -(2**63)-1])
def test_counter_requires_extended_signed_integer(value):
    rows = records()
    rows[0]['motor_counts'] = value
    with pytest.raises(ValueError):
        audit(header(), rows)


def test_input_objects_are_not_mutated():
    config, rows = header(), records()
    before = deepcopy((config, rows))
    audit(config, rows)
    assert (config, rows) == before


def test_missing_stream_and_empty_capture_are_not_valid():
    assert not audit(header(), [])['record_integrity_valid']
    assert not audit(header(), records()[::2])['record_integrity_valid']


def test_file_reader_rejects_nonfinite_json_and_nonobjects(tmp_path):
    path = tmp_path/'bad.jsonl'
    path.write_text('{"value":NaN}\n')
    with pytest.raises(ValueError):
        read_capture(path)
    path.write_text('[]\n')
    with pytest.raises(ValueError, match='objects'):
        read_capture(path)


def test_cli_refuses_existing_output_or_input_replacement(tmp_path, monkeypatch):
    path = tmp_path/'record.jsonl'
    path.write_text('original')
    monkeypatch.setattr('sys.argv', ['audit', str(path), '--output', str(path)])
    with pytest.raises(SystemExit):
        main()
    assert path.read_text() == 'original'


def test_example_remains_explicitly_synthetic():
    from pathlib import Path
    path = Path(__file__).resolve().parents[1]/'config/tests/hardware_capture_nominal_v1.jsonl'
    result = read_capture(path)
    assert result['origin'] == 'synthetic' and result['record_integrity_valid']
    assert not result['ready_to_drive']
