"""마지막 정지 구간의 부분 자료를 전 구간 증거로 오인하지 않아야 한다."""
from test_g1_traffic_coverage_audit import stationary_fixture
import audit_g1_traffic_coverage as audit


def test_stop_pose_tail_truncation_is_not_a_complete_half_second():
    report, trace, raw, ego, stop = stationary_fixture()
    ego = [p for p in ego if p[0] <= 2.55]
    result = audit.audit_rows(report, trace, raw, ego, stop)
    assert not result['checks']['stop_matches_dense_pose']


def test_stop_pose_internal_gap_is_not_zero_motion_proof():
    report, trace, raw, ego, stop = stationary_fixture()
    ego = [p for p in ego if not 2.60 < p[0] < 2.91]
    result = audit.audit_rows(report, trace, raw, ego, stop)
    assert not result['checks']['stop_matches_dense_pose']


def test_late_tiny_stop_segment_does_not_cover_missing_start():
    report, trace, raw, ego, stop = stationary_fixture()
    ego = [p for p in ego if p[0] <= 2.40 or p[0] >= 2.96]
    result = audit.audit_rows(report, trace, raw, ego, stop)
    assert not result['checks']['stop_matches_dense_pose']
