#!/usr/bin/env python3
"""평가 전용: 긴 반대 벽 경로를 실제로 분리 관측된 선호 벽 조각으로 대조한다.

조각 사이의 구간을 연결하거나 자유 공간으로 채우지 않는다. 경계 증거일 뿐
주행 허가가 아니며 LocalFollow·독립 보호·경계 기억을 변경하지 않는다.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import zipfile

import numpy as np

from arena_autonomy.follow_trace import replay_events, restore_call
from arena_autonomy.lidar_motion import MotionConfig, MotionUnavailable
from arena_autonomy.local_follow import FollowConfig
from arena_autonomy.local_path import local_path
from arena_autonomy.scene_motion import motion_scene

ROOT = Path(__file__).resolve().parents[1]


def fragment_evidence(points, reference, side, config):
    """관측 조각 길이 합계는 세되 미관측 간격 길이는 증거에서 제외한다.

    0.65 m/anchor/0.08 m는 기존 경계 계약 값이다. 조각당 5점·0.10 m,
    평균 방향 cosine >=0.8은 이 오프라인 후보에 추가한 제한이며 실측값이 아니다.
    기대 벽은 점 선택/잔차 계산에만 쓰며 반환점이나 점유를 새로 만들지 않는다.
    """
    p, path = np.asarray(points, float), np.asarray(reference, float)
    result = dict(supported=False, reason='invalid_input', fragments=[],
                  observed_ahead_sum_m=0., unknown_gaps_m=[], anchor_observed=False,
                  added_sensor_points=0, occupied_points=len(p), control_connected=False)
    if (side not in ('left', 'right') or p.ndim != 2 or p.shape[1] != 2 or
            path.ndim != 2 or path.shape[1] != 2 or len(path) < 3 or
            not np.all(np.isfinite(p)) or not np.all(np.isfinite(path))):
        return result
    tangent = np.gradient(path, axis=0)
    norm = np.linalg.norm(tangent, axis=1)
    if np.any(norm < 1e-7):
        return {**result, 'reason': 'reference_tangent_invalid'}
    tangent /= norm[:, None]
    sign = 1 if side == 'left' else -1
    wall = path+sign*config.wall_offset_m*np.column_stack((-tangent[:, 1], tangent[:, 0]))
    steps = np.diff(wall, axis=0)
    lengths = np.linalg.norm(steps, axis=1)
    if (np.any(lengths < 1e-7) or
            np.any(np.sum(steps*(tangent[1:]+tangent[:-1]), axis=1) <= 0)):
        return {**result, 'reason': 'expected_wall_folded'}
    arc = np.r_[0., np.cumsum(lengths)]
    origin_index = int(np.argmin(np.linalg.norm(path, axis=1)))
    anchor_s = arc[origin_index]
    if len(p) == 0:
        return {**result, 'reason': 'no_observed_fragments'}
    delta = p[:, None]-wall[None, :-1]
    raw = np.sum(delta*steps[None], axis=2)/(lengths*lengths)
    fraction = np.clip(raw, 0., 1.)
    residual = np.linalg.norm(delta-fraction[:, :, None]*steps[None], axis=2)
    segment = np.argmin(residual, axis=1)
    row = np.arange(len(p))
    distance = residual[row, segment]
    position = arc[segment]+fraction[row, segment]*lengths[segment]
    outside = ((segment == 0) & (raw[row, segment] < 0)) | ((segment == len(steps)-1) & (raw[row, segment] > 1))
    selected = np.flatnonzero((distance <= config.boundary_agreement_m) & ~outside &
                              (sign*p[:, 1] > .10))
    selected = selected[np.argsort(position[selected], kind='stable')]
    if len(selected) < 5:
        return {**result, 'reason': 'no_observed_fragments', 'selected_count': len(selected)}
    # 같은 기존 거리-의존 연결 한도. 큰 조각 사이 간격을 길이 증거로 합치지 않는다.
    limits = .10+.035*np.minimum(np.linalg.norm(p[selected[:-1]], axis=1),
                                np.linalg.norm(p[selected[1:]], axis=1))
    gap = np.linalg.norm(np.diff(p[selected], axis=0), axis=1)
    breaks = np.flatnonzero((gap > limits) | (np.diff(position[selected]) > limits))
    fragments = []
    for indices in np.split(selected, breaks+1):
        if len(indices) < 5:
            continue
        first, last = float(position[indices[0]]), float(position[indices[-1]])
        chord = p[indices[-1]]-p[indices[0]]
        ref_chord = wall[segment[indices[-1]]+1]-wall[segment[indices[0]]]
        denom = np.linalg.norm(chord)*np.linalg.norm(ref_chord)
        aligned = bool(denom > 1e-9 and chord@ref_chord/denom >= .8)
        if last-first < .10 or not aligned:
            continue
        near = np.abs(p[indices, 0]) < .35
        anchor = bool(np.count_nonzero(near) >= 5 and
                      np.percentile(np.abs(np.abs(p[indices[near], 1])-config.wall_offset_m), 80)
                      <= config.boundary_anchor_error_m)
        fragments.append(dict(source_indices=indices.tolist(), count=len(indices),
                              first_s=first-anchor_s, last_s=last-anchor_s,
                              observed_ahead_m=max(0., last-max(first, anchor_s)),
                              anchor=anchor, p80_residual_m=float(np.percentile(distance[indices], 80))))
    observed = sum(f['observed_ahead_m'] for f in fragments)
    anchor = any(f['anchor'] for f in fragments)
    far = max((f['last_s'] for f in fragments), default=0.)
    supported = bool(anchor and observed >= config.boundary_min_ahead_m and far >= config.boundary_min_ahead_m)
    gaps = [max(0., b['first_s']-a['last_s']) for a, b in zip(fragments, fragments[1:])]
    return {**result, 'supported': supported,
            'reason': 'observed_fragments_support_reference' if supported else
                      ('anchor_not_observed' if not anchor else 'observed_length_insufficient'),
            'fragments': fragments, 'observed_ahead_sum_m': observed, 'unknown_gaps_m': gaps,
            'anchor_observed': anchor, 'selected_count': len(selected)}


def probe(events):
    baseline = replay_events(events)
    if not baseline['passed']:
        raise ValueError('current baseline replay mismatch')
    header = events[0]['data']
    config, motion = FollowConfig(**header['follow_config']), MotionConfig(**header['motion_config'])
    last_source, rows = None, []
    for event in events:
        if event['kind'] == 'reset':
            last_source = None
        if event['kind'] != 'call':
            continue
        data, scan, history = restore_call(event['data']['input'], motion)
        source = (data['epoch'], scan.header.stamp.sec, scan.header.stamp.nanosec)
        if source == last_source:
            continue
        last_source = source
        base = dict(seq=event['seq'], reference_s=data['reference_s'],
                    original_reason=event['data']['output'][2]['reason'],
                    original_speed=event['data']['output'][0])
        try:
            scene = motion_scene(scan, history, data['reference_s'], timing_verified=data['timing_verified'],
                                 epoch=data['epoch'], rear_half_angle_deg=data['rear_half_angle_deg'])
            points = np.asarray(scene.occupied_endpoints_xy_m).reshape(-1, 2)
            other_side = 'right' if data['side'] == 'left' else 'left'
            reference, info = local_path(points, other_side, config.wall_offset_m)
            eligible = (reference is not None and info['boundary_observed_ahead_m'] >= config.boundary_min_ahead_m
                        and abs(info['wall_distance_m']-config.wall_offset_m) <= config.boundary_anchor_error_m)
            evidence = fragment_evidence(points, reference, data['side'], config) if eligible else dict(
                supported=False, reason='opposite_reference_insufficient')
            rows.append({**base, 'reference_details': info, 'evidence': evidence})
        except MotionUnavailable as error:
            rows.append({**base, 'evidence': dict(supported=False, reason=str(error))})
    return dict(scope='fixed_input_boundary_evidence_only_not_free_space_or_driving',
                baseline_matched=baseline['matched'], calls=baseline['calls'], fresh_scenes=len(rows),
                reasons=dict(Counter(r['evidence']['reason'] for r in rows)),
                boundary_hold_supported=[r['reference_s'] for r in rows if r['evidence']['supported'] and
                                         r['original_reason'] == 'follow_boundary_unconfirmed'], rows=rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    target = args.output.resolve()
    if not target.is_relative_to(ROOT/'artifacts') or target == ROOT/'artifacts':
        parser.error('fresh artifact subdirectory required')
    target.mkdir(parents=True, exist_ok=False)
    paths = [ROOT/'scripts/probe_gapped_boundary.py', ROOT/'tests/test_gapped_boundary_evidence.py',
             *(ROOT/'src/arena_autonomy/arena_autonomy'/name for name in
               ('follow_trace.py', 'local_follow.py', 'local_path.py', 'scene_motion.py', 'local_scene.py', 'lidar_motion.py'))]
    hashes = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    with zipfile.ZipFile(target/'source_snapshot.zip', 'x', zipfile.ZIP_DEFLATED) as bundle:
        for path in paths:
            bundle.write(path, path.relative_to(ROOT))
    before = hashlib.sha256(args.input.read_bytes()).hexdigest()
    with args.input.open(encoding='utf-8') as stream:
        result = probe([json.loads(line) for line in stream])
    result.update(input_sha256=before, input_unchanged=before == hashlib.sha256(args.input.read_bytes()).hexdigest(),
                  source_hashes=hashes, source_unchanged=all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest() == h
                                                         for p, h in hashes.items()))
    (target/'report.json').write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    print(json.dumps({k: v for k, v in result.items() if k not in ('rows', 'source_hashes')}, ensure_ascii=False))
    return 0 if result['input_unchanged'] and result['source_unchanged'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
