"""고정r67 파일을 수정하지 않는 CPU 후보 전체 판단/비용 대조."""
import argparse
import hashlib
import json
from pathlib import Path
import platform
import numpy as np
import native_scene_fast
from profile_follow_trace import profile_source,read_events

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('trace',type=Path);p.add_argument('--manifest',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=False)
    manifest=json.loads(a.manifest.read_text(encoding='utf-8'))
    base_files={str(Path(name).resolve()):row['sha256'] for name,row in manifest['files'].items()}
    for name,value in base_files.items():
        if digest(Path(name))!=value:raise ValueError('fixed bundle mismatch: '+name)
    candidates=[Path(__file__).resolve(),Path(native_scene_fast.__file__).resolve()]
    candidate_hashes={str(f):digest(f) for f in candidates}
    input_hash=digest(a.trace)
    original=native_scene_fast.install()
    try:result=profile_source(lambda:read_events(a.trace),repeats=1,warmups=0)
    finally:
        import arena_autonomy.scene_motion as sm
        sm.measurement_motion_scene=original
    result.update(input_sha256=input_hash,input_unchanged=digest(a.trace)==input_hash,
        base_bundle_archive_sha256=manifest['archive_sha256'],
        fixed_bundle_unchanged=all(digest(Path(f))==v for f,v in base_files.items()),
        candidate_sha256=candidate_hashes,
        candidate_unchanged=all(digest(Path(f))==v for f,v in candidate_hashes.items()),
        python=platform.python_version(),numpy=np.__version__,
        scope='isolated_validated_native_scene_candidate_on_fixed_r67_no_runtime_file_changes')
    result['passed']=result['passed'] and result['input_unchanged'] and result['fixed_bundle_unchanged'] and result['candidate_unchanged']
    (a.output/'report.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ['passed','baseline_matched','timed_calls','input_unchanged','fixed_bundle_unchanged','candidate_unchanged','groups']}))
    return int(not result['passed'])

if __name__=='__main__':raise SystemExit(main())
