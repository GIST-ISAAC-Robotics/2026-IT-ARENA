"""격리 후보: 검증된 불변 MeasurementScan의 장면 생성. 운영 연결 전이다."""
import math
import numpy as np
from arena_autonomy.measurement_scan import MeasurementScan
from arena_autonomy.local_scene import (SensorRay,LocalScene,_finite,_xy,_source,
    _blind_limits,_masked_by,_reusable_blind_spec,scene_from_measurements)

def build(scan,transforms,now,config,epoch,rear_half_angle_deg):
    if type(scan) is not MeasurementScan:
        raise ValueError('validated immutable MeasurementScan required')
    if (not isinstance(transforms,np.ndarray) or transforms.dtype.kind!='f'
            or transforms.shape!=(len(scan.ranges_m),3) or not np.isfinite(transforms).all()):
        raise ValueError('finite floating Nx3 transforms required')
    sx,sy=_xy((config.lidar_x_m,config.lidar_y_m),'sensor_xy_m')
    yaw=_finite(config.lidar_yaw_rad,'sensor_yaw_rad');now=_finite(now,'t_ref_s')
    _source(scan.source_frame_id,epoch)
    if not _reusable_blind_spec(rear_half_angle_deg):
        return scene_from_measurements(scan.ranges_m,angles_rad=scan.angles_rad,
            acquired_at_s=scan.acquired_at_s,t_ref_s=now,range_min=scan.range_min_m,
            range_max=scan.range_max_m,source_frame_id=scan.source_frame_id,source_epoch=epoch,
            sensor_xy_m=(sx,sy),sensor_yaw_rad=yaw,acquisition_to_ref_se2=transforms.tolist(),
            rear_half_angle_deg=rear_half_angle_deg,preserve_sampling=True)
    limits=_blind_limits(rear_half_angle_deg)
    rays=[];assign=object.__setattr__
    for index,(distance,stamp,pose,source_angle) in enumerate(zip(scan.ranges_m,
            scan.acquired_at_s,transforms.tolist(),scan.angles_rad)):
        dx,dy,turn=pose;c,s=math.cos(turn),math.sin(turn)
        origin=(dx+c*sx-s*sy,dy+s*sx+c*sy)
        angle=math.remainder(source_angle,math.tau)
        masked=_masked_by(math.remainder(angle,math.tau),limits)
        valid=math.isfinite(distance) and scan.range_min_m<=distance<=scan.range_max_m
        status='masked' if masked else ('return' if valid else 'unknown')
        bearing=angle+yaw+turn;direction=(math.cos(bearing),math.sin(bearing))
        hit=(origin[0]+distance*direction[0],origin[1]+distance*direction[1]) if status=='return' else None
        # 유한 입력에서도 연산 overflow가 생길 수 있다. 출력 기하 검사는 유지한다.
        if not all(math.isfinite(v) for v in origin):raise ValueError('origin must be finite numeric')
        if hit is not None and not all(math.isfinite(v) for v in hit):raise ValueError('hit must be finite numeric')
        if abs(math.hypot(*direction)-1.)>1e-10:raise ValueError('direction_xy must be unit length')
        # 범위/시각/출처/인덱스/상태는 불변 입력과 생성 루프에서 검증된다.
        # 공개 SensorRay 생성자의 검사는 유지하고 이 내부 생성에서만 중복을 피한다.
        ray=object.__new__(SensorRay)
        assign(ray,'ray_origin_xy_m',origin);assign(ray,'hit_xy_m',hit)
        assign(ray,'acquired_at_s',stamp);assign(ray,'status',status)
        assign(ray,'source_frame_id',scan.source_frame_id);assign(ray,'source_epoch',epoch)
        assign(ray,'source_index',index);assign(ray,'direction_xy',direction)
        rays.append(ray)
    return LocalScene(now,scan.acquired_at_s[0],scan.acquired_at_s[-1],scan.source_frame_id,
                      epoch,tuple(rays),source_angles_rad=scan.angles_rad)

def install():
    """격리 프로파일 프로세스에서만 함수를 교체하며 파일은 덮어쓰지 않는다."""
    import inspect,textwrap
    import arena_autonomy.scene_motion as sm
    original=sm.measurement_motion_scene
    source=inspect.getsource(original)
    start=source.index('    return scene_from_measurements(')
    replacement=source[:start]+'    return fast_build(scan,transforms,now,config,epoch,rear_half_angle_deg)\n'
    ns=dict(original.__globals__,fast_build=build)
    exec(compile(textwrap.dedent(replacement),'<native-scene-fast-candidate>','exec'),ns)
    sm.measurement_motion_scene=ns['measurement_motion_scene']
    return original
