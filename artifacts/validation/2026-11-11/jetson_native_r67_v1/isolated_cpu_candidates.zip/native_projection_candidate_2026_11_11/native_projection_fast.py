"""격리 후보: 점군만 필요한 호출에서 SensorRay/LocalScene 생성을 생략한다."""
import inspect
import math
import numpy as np
from arena_autonomy.measurement_scan import MeasurementScan
from arena_autonomy.local_scene import _finite, _xy, _source


def project(scan, transforms, now, config, epoch):
    if type(scan) is not MeasurementScan:
        raise ValueError('validated immutable MeasurementScan required')
    if (not isinstance(transforms, np.ndarray) or transforms.dtype.kind != 'f'
            or transforms.shape != (len(scan.ranges_m), 3) or not np.isfinite(transforms).all()):
        raise ValueError('finite floating Nx3 transforms required')
    sx, sy = _xy((config.lidar_x_m, config.lidar_y_m), 'sensor_xy_m')
    yaw = _finite(config.lidar_yaw_rad, 'sensor_yaw_rad')
    now = _finite(now, 't_ref_s')
    _source(scan.source_frame_id, epoch)
    if scan.acquired_at_s[-1] > now:
        raise ValueError('source interval/reference time mismatch')
    points, indices = [], []
    for index, (distance, pose, angle) in enumerate(zip(scan.ranges_m, transforms.tolist(), scan.angles_rad)):
        dx, dy, turn = pose
        c, s = math.cos(turn), math.sin(turn)
        ox, oy = dx + c*sx - s*sy, dy + s*sx + c*sy
        bearing = math.remainder(angle, math.tau) + yaw + turn
        ux, uy = math.cos(bearing), math.sin(bearing)
        if not (math.isfinite(ox) and math.isfinite(oy)):
            raise ValueError('origin must be finite numeric')
        if abs(math.hypot(ux, uy)-1.) > 1e-10:
            raise ValueError('direction_xy must be unit length')
        if math.isfinite(distance) and scan.range_min_m <= distance <= scan.range_max_m:
            point = (ox + distance*ux, oy + distance*uy)
            if not all(math.isfinite(v) for v in point):
                raise ValueError('hit must be finite numeric')
            points.append(point)
            indices.append(index)
    return np.asarray(points, dtype=float).reshape(-1, 2), np.asarray(indices, dtype=int)


def install():
    """고정 소스 파일은 유지하고 이 프로파일 프로세스의 함수 코드만 바꾼다."""
    import arena_autonomy.scene_motion as sm
    import arena_autonomy.scan_input as si
    checked_source = inspect.getsource(sm.measurement_motion_scene)
    checked_source = checked_source[:checked_source.index('    return scene_from_measurements(')]
    checked_source += '    return fast_project(scan,transforms,now,config,epoch)\n'
    checked_ns = dict(sm.measurement_motion_scene.__globals__, fast_project=project)
    exec(compile(checked_source, '<checked-native-projection>', 'exec'), checked_ns)
    original = si.project_scan
    source = inspect.getsource(original)
    start = source.index('    from arena_autonomy.scene_motion import measurement_motion_scene')
    end = source.index('    first,last=', start)
    source = (source[:start] + '    points,ids=_checked_native_projection(scan,history,now,timing_verified=timing_verified)\n'
              + source[end:])
    ns = dict(original.__globals__)
    exec(compile(source, '<native-projection-candidate>', 'exec'), ns)
    original_code = original.__code__
    assert '_checked_native_projection' not in original.__globals__
    original.__globals__['_checked_native_projection'] = checked_ns['measurement_motion_scene']
    original.__code__ = ns['project_scan'].__code__
    def restore():
        original.__code__ = original_code
        del original.__globals__['_checked_native_projection']
    return restore
