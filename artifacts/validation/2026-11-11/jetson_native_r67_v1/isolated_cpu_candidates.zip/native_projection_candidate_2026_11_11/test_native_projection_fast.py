import math
from dataclasses import replace
import numpy as np
import pytest
from native_projection_fast import project, install
from test_native_scene_fast import inputs, original
from test_native_scan_pipeline import native
from test_local_follow import history
from arena_autonomy.scan_input import project_scan


@pytest.mark.parametrize('n', [424, 508, 524])
@pytest.mark.parametrize('clockwise', [False, True])
@pytest.mark.parametrize('empty', [False, True])
def test_exact_projection_and_order(n, clockwise, empty):
    scan, poses, config = inputs(n, clockwise)
    if empty:
        scan = replace(scan, ranges_m=(math.inf,)*n)
    expected = original(scan, poses, config)
    points, ids = project(scan, poses, .62, config, 3)
    assert np.array_equal(points, np.asarray(expected.occupied_endpoints_xy_m).reshape(-1, 2))
    assert np.array_equal(ids, [r.source_index for r in expected.rays if r.status == 'return'])


@pytest.mark.parametrize('fault', ['nan', 'inf', 'bool', 'shape', 'old_reference', 'negative_epoch', 'overflow'])
def test_invalid_inputs_and_outputs_rejected(fault):
    scan, poses, config = inputs(508, True)
    now, epoch = .62, 3
    if fault == 'nan': poses[0, 0] = math.nan
    if fault == 'inf': poses[0, 0] = math.inf
    if fault == 'bool': poses = poses.astype(bool)
    if fault == 'shape': poses = poses[:-1]
    if fault == 'old_reference': now = .51
    if fault == 'negative_epoch': epoch = -1
    if fault == 'overflow': poses[0] = [1e308, 0., 0.]; config.lidar_x_m = 1e308
    with pytest.raises(ValueError): original(scan, poses, config, now, epoch)
    with pytest.raises(ValueError): project(scan, poses, now, config, epoch)


def test_process_patch_preserves_outputs_and_restores_function():
    scan, h = native(), history(.5, .4)
    before = project_scan(scan, h, .62, timing_verified=True)
    restore = install()
    try:
        after = project_scan(scan, h, .62, timing_verified=True)
    finally:
        restore()
    assert np.array_equal(before[0], after[0]) and np.array_equal(before[1], after[1])
    assert before[2] == after[2]
