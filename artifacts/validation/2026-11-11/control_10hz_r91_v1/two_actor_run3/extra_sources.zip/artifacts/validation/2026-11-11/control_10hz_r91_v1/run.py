"""r89 계산 코드에서 r87 시설 교통 장면의 제어 주기만10Hz로 바꾸는 제한1회."""
from datetime import datetime, timezone
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

A=Path(__file__).resolve().parent
ROOT=A.parents[3]
BASE=A.parent/'native_traffic_baseline_r87_v1'
F=ROOT/'artifacts/validation/2026-11-09/signal_posts_markers_v1'
sys.path[:0]=[str(F), str(ROOT/'scripts'), str(ROOT/'tests')]
import validate_g1_traffic as target
from traffic_posts_setup import configure


def main():
    sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    contract=json.loads((ROOT/'config/tests/occluder_cpu_r89_sha256.json').read_bytes())
    for name,change in contract['approved_changes'].items():
        assert sha(ROOT/name)==change['after']
    comparison=json.loads((A.parent/'occluder_cpu_r89_v1/implementation_comparison.json').read_bytes())
    assert comparison['calls']==3060 and comparison['full_mismatch_count']==0
    d=A/'two_actor_run3'; d.mkdir(exist_ok=False)
    parent=BASE/'two_actor_run1/registered.json'
    record=json.loads(parent.read_bytes())
    args=list(record['args']); args[args.index('--output')+1]=str(d/'run1')
    args.extend(['--handoff-control-rate-hz','10'])
    original=json.loads((BASE/'two_actor_run1/recessed_config.json').read_bytes())
    config=copy.deepcopy(original)
    assert config['launch']['control_rate_hz']==50.
    config['launch']['control_rate_hz']=10.
    restored=copy.deepcopy(config); restored['launch']['control_rate_hz']=50.
    assert restored==original
    (d/'recessed_config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf8')
    args[args.index('--config')+1]=str(d/'recessed_config.json')
    (d/'additional_actors.json').write_bytes((BASE/'two_actor_run1/additional_actors.json').read_bytes())
    args[args.index('--actor-overlay')+1]=str(d/'additional_actors.json')
    assert '--lidar-test-profile' not in args
    assert args.count('--lidar-native-sampling-profile')==1
    files=set(subprocess.check_output(['git','ls-files','-co','--exclude-standard','src','scripts','config'],cwd=ROOT,text=True).splitlines())
    files.update(p.relative_to(ROOT).as_posix() for p in A.glob('*') if p.is_file() and p.suffix in ('.py','.sh'))
    files.update(p.relative_to(ROOT).as_posix() for p in (
        F/'traffic_posts_setup.py',F/'traffic_facility_fixture.py',F/'traffic_posts_assess.py',
        F/'marker_posts_provisional.sdf',F/'marker_posts_provisional.json',
        ROOT/'artifacts/validation/2026-11-10/combined_recessed_facility_v1/audit_shapes.py',
        ROOT/'artifacts/validation/2026-11-08/masked_motion_speed_v1/assess.py',
        ROOT/'artifacts/validation/2026-11-08/medium_recessed_pass_v1/outline_moving.py',
        ROOT/'artifacts/validation/2026-11-10/facility_traffic_stability_v1/analyze_continuity.py',
        d/'recessed_config.json',d/'additional_actors.json'))
    hashes={name:sha(ROOT/name) for name in sorted(files) if (ROOT/name).is_file()}
    with zipfile.ZipFile(d/'extra_sources.zip','x',zipfile.ZIP_DEFLATED) as z:
        for name in hashes:z.write(ROOT/name,name)
    registration=dict(registered_at_utc=datetime.now(timezone.utc).isoformat(),
        parent=parent.relative_to(ROOT).as_posix(),parent_sha256=sha(parent),args=args,extra_sources=hashes,
        snapshot_sha256=sha(d/'extra_sources.zip'),gates=copy.deepcopy(record['gates']),
        comparison=dict(control_rate_hz_before=50.,control_rate_hz_after=10.,
                        expected_planning_dt_s=.1,independent_guard_rate_unchanged=True),
        scope='one r89-code closed-loop nominal native facility traffic trial; only control_rate_hz 50 to10 vs r87; no CPU delay emulation, no asynchronous worker, no real-time/Jetson proof')
    (d/'registered.json').write_text(json.dumps(registration,indent=2)+'\n',encoding='utf8')
    configure(target,d/'stage');sys.argv=args
    try:return target.main()
    finally:
        result=dict(changed=[p for p,h in hashes.items() if not (ROOT/p).is_file() or sha(ROOT/p)!=h],
            snapshot_unchanged=sha(d/'extra_sources.zip')==registration['snapshot_sha256'])
        (d/'extra_integrity.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')


if __name__=='__main__':raise SystemExit(main())
