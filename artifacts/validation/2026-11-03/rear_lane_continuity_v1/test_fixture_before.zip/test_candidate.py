"""Policy counterexamples; injected parent output is not sensor recognition proof."""
from types import SimpleNamespace
import numpy as np
import pytest
import candidate as mod
from arena_autonomy.local_follow import FollowConfig


@pytest.fixture
def setup(monkeypatch):
    cfg = FollowConfig(parallel_hold_trial=True, pass_release_trial=True, guard_curve_trial=True,
        traffic_recovery_trial=True, traffic_path_recovery_trial=True, static_side_release_trial=True,
        corridor_fallback_enabled=True)
    state = dict(side='right', seen=True, forward=False)
    def parent(self, scene, baseline, parallel, speed, previous, dt, **kwargs):
        evidence = {state['side']:dict(present=state['seen'], world_fixed_return=state['seen'] and not state['forward'],
            rearmost_ds_m=.3 if state['forward'] else -.2)}
        return baseline[0], baseline[1], {**baseline[2], 'selector_mode':'SOLO',
            'selector_choice':'baseline', 'selector_evidence':evidence}
    monkeypatch.setattr(mod.SuspendedPassageSelector, '_select', parent)
    monkeypatch.setattr(mod, 'faster_proposal', lambda *a, **k:dict(eligible=False,reason='test_unchanged'))
    ctl = mod.CurrentLaneSelector(cfg)
    path = np.array([[x, 0.] for x in np.linspace(0.,1.,11)])
    def call(angle=-.2, target=.8, parallel_speed=.35, reason='local_follow', context='parallel_current_position',
             wall='left', verified=True, points=()):
        scene = SimpleNamespace(t_ref_s=1., source_first_s=.9, occupied_endpoints_xy_m=points,
                                rays=[SimpleNamespace(acquired_at_s=.999)])
        base = target, angle, dict(reason=reason,path_points=path.tolist(),preferred_wall=wall)
        par = parallel_speed, 0., dict(reason='parallel_hold_follow',parallel_hold_selected=verified,
            parallel_hold_trial=dict(reason=context,path_points=path.tolist(),maximum_padding_m=.1,clearance_m=2.))
        return ctl._select(scene,base,par,.3,0.,.02)
    return ctl,state,call


@pytest.mark.parametrize('side,angle',[('right',-.2),('left',.2)])
def test_current_parallel_lane_before_return_toward_previous_side(setup,side,angle):
    ctl,state,call=setup; state['side']=side
    out=call(angle=angle)
    assert out[:2] == (.35,0.)
    assert out[2]['current_lane_preference']['applied']
    assert not out[2]['current_lane_preference']['unknown_filled']


def test_zero_center_wait_can_continue_on_verified_parallel(setup):
    ctl,state,call=setup
    assert call(target=0.,reason='follow_release_wait')[:2] == (.35,0.)


@pytest.mark.parametrize('angle',[0.,.2])
def test_no_return_toward_right_keeps_original_speed(setup,angle):
    ctl,state,call=setup
    assert call(angle=angle)[:2] == (.8,angle)


@pytest.mark.parametrize('kwargs',[
    dict(parallel_speed=0.),dict(parallel_speed=.1),dict(verified=False),
    dict(reason='follow_boundary_unconfirmed'),dict(context='reference_not_straight'),
    dict(context='partial_observation_outside_trial'),dict(points=[[.2,.16]])])
def test_unusable_parallel_or_current_obstacle_does_not_invent_new_stop(setup,kwargs):
    ctl,state,call=setup
    out=call(**kwargs)
    assert out[:2] == (.8,-.2)
    assert not out[2]['current_lane_preference']['applied']


def test_forward_pass_ends_side_preference(setup):
    ctl,state,call=setup
    call(); state['forward']=True
    assert call()[:2] == (.8,-.2)
    assert not ctl.lane_sides


def test_wall_switch_and_reset_end_context(setup):
    ctl,state,call=setup
    call(); state['seen']=False
    assert call(wall='right')[:2] == (.8,-.2)
    assert not ctl.lane_sides
    state['seen']=True; call(wall='right')
    ctl.invalidate('input_discontinuity'); state['seen']=False
    assert call(wall='right')[:2] == (.8,-.2)


def test_current_motor_gear_ratio_for_speed_quantum(setup):
    ctl,_,_=setup
    assert ctl.speed_quantum == pytest.approx(np.pi*.065/(28*(2.5*61/17))/.02)
