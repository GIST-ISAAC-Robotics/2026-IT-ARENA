"""선택형 콜백 계측. 기본 비활성이며 콜백 벽시계 소요시간과 센서 나이를 구분한다."""
import json
import time

from std_msgs.msg import String


class TimingProbe:
    def __init__(self, node):
        self.node = node
        enabled = bool(node.declare_parameter('timing_probe', False).value)
        self.publisher = node.create_publisher(String, '/diagnostics/timing', 100) if enabled else None
        self.previous = {}

    def wrap(self, name, callback):
        if self.publisher is None:
            return callback
        def measured(*args):
            began = time.perf_counter_ns()
            ros_ns = self.node.get_clock().now().nanoseconds
            source = None
            if args and hasattr(args[0], 'header'):
                stamp = args[0].header.stamp
                source = stamp.sec * 1_000_000_000 + stamp.nanosec
            previous = self.previous.get(name)
            self.previous[name] = began
            try:
                return callback(*args)
            finally:
                end = time.perf_counter_ns()
                self.publisher.publish(String(data=json.dumps({
                    'node': self.node.get_name(), 'callback': name, 'receive_ros_ns': ros_ns,
                    'source_ns': source, 'source_age_ms': None if source is None else (ros_ns-source)/1e6,
                    'begin_monotonic_ns': began, 'end_monotonic_ns': end, 'duration_ms': (end-began)/1e6,
                    'wall_interval_ms': None if previous is None else (began-previous)/1e6,
                }, allow_nan=False)))
        return measured
