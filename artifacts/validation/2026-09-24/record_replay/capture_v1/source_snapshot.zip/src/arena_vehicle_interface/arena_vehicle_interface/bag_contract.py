"""A2 기록/재생 허용 목록과 ROS 독립 무결성 검사. 명령은 재생하지 않는다."""
import hashlib
import json
from pathlib import Path
import struct

INPUTS = {
    '/camera/color/image_raw': 'sensor_msgs/msg/Image',
    '/camera/color/camera_info': 'sensor_msgs/msg/CameraInfo',
    '/scan': 'sensor_msgs/msg/LaserScan',
    '/imu/data': 'sensor_msgs/msg/Imu',
    '/wheel_states': 'sensor_msgs/msg/JointState',
}
OBSERVATIONS = {
    '/drive': 'ackermann_msgs/msg/AckermannDriveStamped',
    '/drive/safe': 'ackermann_msgs/msg/AckermannDriveStamped',
    '/autonomy/status': 'std_msgs/msg/String',
    '/safety/status': 'std_msgs/msg/String',
    '/actuation/status': 'std_msgs/msg/String',
    '/actuation/output_status': 'std_msgs/msg/String',
    '/diagnostics/timing': 'std_msgs/msg/String',
}
TOPICS = {**INPUTS, **OBSERVATIONS}
REQUIRED = set(INPUTS) | {'/drive', '/drive/safe', '/autonomy/status', '/safety/status', '/diagnostics/timing'}


def replay_topic(topic):
    if topic not in INPUTS:
        raise ValueError('Only allowlisted sensors may be replayed: ' + topic)
    return '/replay' + topic


def update_digest(digest, payload, timestamp):
    digest.update(struct.pack('<QQ', timestamp, len(payload)))
    digest.update(payload)


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def quantiles(values):
    values = sorted(values)
    if not values:
        return {'count': 0, 'p50': None, 'p95': None, 'p99': None, 'max': None}
    return dict(count=len(values), **{key: values[min(len(values)-1, int((len(values)-1)*q))]
                                    for key, q in [('p50', .5), ('p95', .95), ('p99', .99), ('max', 1.)]})


def load_manifest(root):
    root = Path(root).resolve()
    manifest = json.loads((root / 'manifest.json').read_text(encoding='utf-8'))
    if manifest.get('schema') != 1 or manifest.get('complete') is not True:
        raise ValueError('Incomplete or unsupported recording')
    if manifest.get('queue_drops') or manifest.get('error') or manifest.get('clock_regressions'):
        raise ValueError('Recording contains known loss/error/clock regression')
    if manifest.get('topics') != TOPICS:
        raise ValueError('Topic contract mismatch')
    if not REQUIRED.issubset({t for t, s in manifest['stats'].items() if s['count'] > 0}):
        raise ValueError('Required topics missing')
    for relative, digest in manifest['files_sha256'].items():
        path = (root / relative).resolve()
        if not path.is_relative_to(root) or not path.is_file() or sha256_file(path) != digest:
            raise ValueError('Recording integrity failure: ' + relative)
    # 파일 목록에서 원시 데이터/수신 시각/매개변수 누락도 거부한다.
    required_files = {'receipt.jsonl', 'parameters.json', 'bag/metadata.yaml'}
    if not required_files.issubset(manifest['files_sha256']) or not any(k.endswith('.mcap') for k in manifest['files_sha256']):
        raise ValueError('Incomplete file inventory')
    return manifest
