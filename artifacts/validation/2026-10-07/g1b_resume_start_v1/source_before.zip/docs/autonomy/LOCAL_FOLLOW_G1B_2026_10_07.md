# G1-b: Gazebo 앞차와 저속 추종·대기

작성: 2026-10-07. **정지 앞차 seed 0 통과·등속 앞차 seed 0 행동 실패 후 사용자 요청으로 잠시 중단.** 수정·회귀와 실행 유효성 검증은 완료했지만 등속 추종의 진행성이 미해결이다. 재출발 seed 0, seed 1/2 여섯 실행, R0 비교 세 실행은 미실행이며 **G1-b 행렬 완료가 아니다.** 기본 G1 활성화·G1 전체 단계·전체 랩·실차 안전의 완료 보고서가 아니다.

## 목표와 유지한 범위

[G1-a](LOCAL_FOLLOW_G1_2026_10_05.md)의 선택형 `g1_follow`를 실제 Gazebo 앞차·렌더링된 순차 C1·독립 LiDAR 보호층·가상 MCU와 연결한다. 공식 코스 출발 직선에서 정지 앞차 10초, 0.35 m/s 앞차 12초, 이동→정지→재출발 15초를 사전 등록한 [시험 설정](../../config/tests/g1_traffic_v1.json)으로 검사한다. G1 seed 0/1/2는 잡음 주입이 아닌 앞차 시작 위치 0/−0.10/+0.10 m의 결정론적 배치다. R0는 같은 명령 상한 1.0 m/s·seed 0의 비교이며 G1 행동 판정선 통과를 강제하지 않는다.

도로 폭 0.45 m, 차체 0.20×0.15 m, 모터축 28카운트·15:1·65 mm 바퀴·임시 축거 0.135 m, 센서 구성·높이·배치·독립 `/drive` → 보호층 → `/drive/safe`를 유지한다. 순차 10 Hz·both 운동 보정·제어 50 Hz와 기존 보호/MCU 마감도 유지한다. 우회·추월·코너/옆차 반례·전체 랩·Jetson·실차·센서 추가는 이번 범위 밖이다. 기본 단독 모드는 유지하며 G1은 선택형이다.

출발은 기존 임시 RGB 빨강→초록 시험 트리거다. [10/6 공식 소등 출발과의 불일치](../reports/OFFICIAL_UPDATE_2026_10_06.md)는 별도 미해결로 유지한다. 공식 원본 ZIP·`world.sdf`·`scene.json`을 바꾸지 않았고, 보수적 차체 노면 이탈 기준에 잔디 완화 메모를 적용하지 않았다.

초기 구현·두 파일럿은 Claude Opus 5.5와 Claude Sonnet 5.5가 맡았다. Claude 사용량 한도 도달 후 사용자의 명시 지시로 GPT 주 에이전트가 설계·검토, GPT-6.1 Sol이 수정·회귀·문서, GPT-6 Luna가 실행·대기·결과 회수를 맡았다. 한도 도달을 완료로 기록하지 않았다. 시작 HEAD `25dea6045098105a1289ac8ffdb9b2b366c16edb`와 기존 G1-a·10/6 미커밋 변경은 [최초 상태](../../artifacts/validation/2026-10-07/g1b_start_state/)에 보존했으며, GPT 수정 시작 소스는 [별도 보관](../../artifacts/validation/2026-10-07/g1b_sol_start_v1/)했다. 커밋·푸시·외부 게시·Jetson 실행은 하지 않았다.

Claude의 초기 미완성 문서는 [인수 보존본](../../artifacts/validation/2026-10-07/g1b_start_state/LOCAL_FOLLOW_G1B_TRAFFIC_2026_10_07.claude_draft.md)으로 이동했다. 이동 전후 SHA-256 `4fba91a538be674b4bccc96a27320037bfbfa1a7cfc7ab460fc92e4cf5740247`이 같으며 기존 문서의 링크 참조는 없었다. 활성 기술 보고서는 이 파일 한 곳으로 유지한다.

## 시험기와 판정

`validate_g1_traffic.py`는 실행 사본에만 정적 상자 `eval_g1b_actor`(0.20×0.15×0.12 m, 바닥 0 m)를 넣고 평가 전용 `set_pose`로 옮긴다. C1의 0.095 m 측정면이 상자를 가로지른다. 모델 자세·중심선·일정·신호 상태·노면/벽/접촉 정답은 평가기만 사용한다. 제어기와 보호층, 가상 MCU의 구독·`/drive`/`/drive/safe` 발행자·actor 자세 구독자를 실행 그래프로 감사한다.

정적 모델은 무한 질량의 순간이동 장애물이며 저속 앞차의 차량 동역학이 아니다. [known-contact 확인](../../artifacts/validation/2026-10-07/g1b_contact_probe_v1/report.json)에서 새 위치의 접촉 메시지 33개와 옛 위치 잔상 없음은 확인했지만, 완전 중첩 순간이동으로 상대 상자를 밀어내지는 않았다. 접촉은 사건 기록이다. 이번 실행의 topic publisher/reader·파싱 오류 검사와 known-contact 소스 해시를 `contact_evidence`에 별도 기록하며, 수신 0개를 연속 무접촉 증명으로 해석하지 않는다.

기존 행동 판정선은 그대로다. 최소 차체 간격은 표본과 보수적 swept 하한 모두 0.15 m, 정지 앞차는 연속 HOLD 3초·끝 간격 0.70 m 이하, 등속 앞차는 진행 2.5 m 이상·연속 정체 2.5초 이하·끝 간격 1.2 m 이하, 재출발은 정지 구간 HOLD 1초·재출발 지연 2.5초 이하·재출발 뒤 진행 1 m 이상·끝 간격 1.2 m 이하다. 명시 STOP·출력 0·모델 안정 정지·MCU 고정 고장/마감·프로세스 정상 종료는 각각 검사한다. 정확한 수치·근거는 사전 설정이 기준이다.

평가판 `g1b_eval_v2_coverage`는 누락을 통과로 해석하던 경우를 거절한다. 비유한·시간 역전/중복 자세·빈 ego/actor/trace, 끝까지 도달하지 않은 창, 오래된 actor 자세의 재사용, 움직이는 actor의 빈 명령/오차 표본, 누락된 정지 요청, reader 파싱/handler 오류를 별도 검사한다. 기존 actor 수신 공백 0.05초를 ego/짝맞춤에도 적용하며, 10 Hz 상태 trace의 0.20초 넘는 공백은 연속 HOLD로 연결하지 않는다. 이는 새 계측 완전성 조건이고 기존 간격·대기·센서/MCU 한도의 완화가 아니다. 각 실행은 평가판과 소스 ZIP·SHA-256을 보존한다.

`harness_valid`는 actor 일정·관측·coverage, `integrity`는 소스·구독·계측, `stop_checks`는 모델/MCU 정지, `shutdown_clean`은 정상 종료/잔존, `behavior_gates_passed`는 행동 수치다. G1 최종 `passed`는 실행 유효성과 행동 판정을 모두 요구한다. R0 `passed`는 비교 실행의 유효성이며 `r0_meets_g1_gates`를 따로 기록한다.

고정 런타임 밖 [사후 상태/자세 감사](../../scripts/audit_g1_traffic_coverage.py)는 원시 autonomy 상태와 trace의 시각·내용, 경계 원천/참조 시각 진행·원천/경로 TTL, HOLD·STOP과 밀집 실제 자세 이동을 대조한다. 원시 autonomy는 정상 상태에서 0.2초마다 또는 상태 전환 때 발행하므로 trace보다 낮은 발행률 자체를 오류로 세지 않는다. 정지 앞차는 감사 v1을 통과했고, 이후 v2는 등속 사례에 HOLD가 없으면 그 교차 검사만 `not_applicable`로 명시한다(정지/재출발 사례는 HOLD 자료 필수). stale 관측을 거절하며 0명령을 내린 것은 진단으로, 오래된 근거를 사용한 양수 명령은 오류로 구분한다. v1 소스·결과는 보존하고 v2 반례 5개를 통과했다. 현재 기록에는 dynamics 진단·`/drive/safe`의 개별 원천 시각이 없어 **그 두 스트림의 신선성은 미확인**이다. 제어기/MCU 자체 입력 검사·평가기 graph/시각·밀집 자세 검사와 구분하며, 사후 감사가 원본 실행 판정이나 행동 수치를 바꾸지는 않는다.

## 최초 파일럿과 수정 근거

| 보존 실행 | 당시 판정 | 확인 범위와 실패 |
|---|---|---|
| [pilot v1 stopped seed 0](../../artifacts/validation/2026-10-07/g1b_pilot_v1/stopped_center_s0_g1/report.json) | `run_valid=false`, 행동 수치 통과, `passed=false` | 최소 표본/swept 간격 약 0.38565 m·HOLD 6.27초·명시 STOP/모델 정지는 확인. `GZ_PARTITION`과 종료 도구의 시험 소유 이름 규칙이 달라 정상 종료 실패. 후속 새 실행의 성공으로 소급하지 않음 |
| [pilot v2 stopped seed 0](../../artifacts/validation/2026-10-07/g1b_pilot_v2/stopped_center_s0_g1/report.json) | 당시 평가판 `run_valid=true`, 행동 실패, `passed=false` | 종료·명시 STOP은 확인했지만 최소 간격 1.21038 m, HOLD 0초로 접근·대기 실패. 실행 중 Windows Silent 전환과 매우 낮은 RTF·영상 벽시계 watchdog에 의한 `SENSOR_STOP`이 기록되어 정상 추종 입력 조건의 검증으로 사용하지 않음 |

v2의 환경 원인과 기계 판정을 구분한다. 기존 보고서의 `run_valid=true`를 바꾸지 않으며, 해당 실행은 실제 저속 추종의 행동 검증 근거로 채택하지 않는다. [전원/RTF 기록](../../artifacts/validation/2026-10-07/g1b_analysis_v1/host_power_mode.md)에 Silent 전환과 약 0.011 RTF를 남겼다. 사용자가 직접 Turbo로 복구했으며 실행 담당의 후속 조회에서 Turbo와 관련 잔존 프로세스 0개를 확인했다. 영상 watchdog·MCU 마감은 늘리지 않았다.

v1 저장 trace에서는 sim 7.171초에 `follow_release_wait`·원천 7.002초·참조 7.12초·경계 나이 0.118초·새 관측 수락을 기록했다. 7.273초 표본의 `follow_invalid_state`는 원천 7.102초·참조 7.260000000000001초다. 같은 MCU 시간 7.260초에는 유효 피드백 `mean_wheel_mps=-0.0486198863`, capture 7.253초·count 2170을 기록했고, 7.330초에는 count 2169·같은 signed 속도를 기록했다. 당시 모델의 종방향 속도도 7.273초에 −0.0083962 m/s였다. **한 카운트 잡음이라고 단정하지 않는다.**

기존 `LocalFollow.command`는 `speed < -0.02`를 invalid state로 취급해 `reset()`으로 경계 기억을 지웠다. 직전 확인 원천 7.002초는 7.26초 기준으로 0.258초여서 설정 TTL 0.30초 안에 있었지만, v1에는 원시 scan·연속 운동 이력을 남기지 않아 전체 이동 입력을 정확히 재생할 수 없다. 저장 trace/MCU와 이 코드 경로는 결합 실패의 근거이며, 이후 영구 정체의 유일 원인을 입증한 자료는 아니다. [정지 위치 합성 분석](../../artifacts/validation/2026-10-07/g1b_analysis_v1/v1_hold_pose_synthetic.json)은 양 경계가 앞차로 짧아진 상태에서 기억 없는 초기 재획득이 실패함을 보인다. 이상적 정지 기하 근사이며 actual moving replay가 아니다.

수정은 유효한 signed 역방향 측정과 비유한/시각·세대/센서 만료를 분리했다. 유한 음수는 실제 signed 운동 보정과 현재 관측·경계·점유 갱신을 수행한 뒤 `follow_reverse_motion` HOLD로 전진 명령을 금지한다. 음수를 0으로 치환하거나 역속도 무효 임계값을 올리지 않았다. 계속 역방향이면 매번 0명령·release 확인 0이며, 정상 측정 복귀 뒤에도 유효 경계/점유와 서로 다른 두 새 관측 확인 후만 재개한다. 원천 시각·TTL 0.30초·만료·미관측·NaN/inf·시간 역전/epoch reset은 유지한다. R0 shared math·LiDAR 보호·센서/물성은 수정하지 않았다.

## 회귀와 채택 검사

| 검사 | 근거/결과 |
|---|---|
| 첫 전체 회귀 | [v2 원본 로그](../../artifacts/validation/2026-10-07/g1b_unit_v2/pytest.log): 407 통과·2 실패. 기존 pre-G0 byte 해시가 새 `simulation.launch.py`와 다른 것을 탐지. 행동/안전 기준 실패로 숨기거나 원본 manifest를 덮어쓰지 않음 |
| 후속 source contract 수립 전 | [v3 로그](../../artifacts/validation/2026-10-07/g1b_unit_v3/pytest.log): 408 통과·같은 2 해시 실패. 새 contact publisher 연결 반례 포함 |
| 승인된 버전별 기준 | [G1-b R0 manifest](../../config/tests/g1b_r0_sha256.json): original manifest·source manifest SHA 보존, 변경 허용은 선택형 actor/비교 프로필이 추가된 launch 단 1파일. 나머지 공통 math·보호·운동·센서·차량 6파일 SHA 동일 |
| 원본/현재 구분 회귀 | 원본 G0 manifest·보존 source ZIP SHA 불변, `g0.baseline_comparison()` 기본은 예전 기준에 대한 불일치 유지. 현재 기능 검사는 새 G1-b manifest를 명시하며 허용된 단 1파일 외 변경을 거절 |
| 최종 회귀 | [v4 로그](../../artifacts/validation/2026-10-07/g1b_unit_v4/pytest.log): **412 통과**, 36.03초. 단일 −1count·연속 음수·2 fresh 재개·signed history 적분·NaN/inf·epoch/시각 역전·stale+reverse·가림/만료·점유 보존 및 시험기 coverage/비유한/미수신 반례 포함 |
| 소스 고정 | [source freeze](../../artifacts/validation/2026-10-07/g1b_unit_v4/source_freeze.json): 런타임/설정·검사 11파일 SHA. actual Gazebo 파일럿 앞에 고정. 최초 부정확한 `PYTHONPATH` 전체 치환으로 xacro 수집 오류가 있어 ROS 경로 뒤에 소스 prefix를 유지한 명령으로 수정했으며 기능 코드 오류로 세지 않음 |

## 새 실행 결과

| 실행 | 실제 결과 | 사후 감사·한계 |
|---|---|---|
| [v3 정지 앞차 seed 0](../../artifacts/validation/2026-10-07/g1b_pilot_v3_stopped_s0/report.json) | 실행·행동·명시 STOP·정상 종료 통과. 최소 표본 0.384268 m·swept 하한 0.384267 m·연속 HOLD 6.17초. 주행/STOP 벽 충돌·노면 이탈 표본 0, MCU STOP 전 고정 고장/마감 진단 0. STOP 0.5초 안정·출력 0·잔존 없음 | [상태/자세 감사 v1](../../artifacts/validation/2026-10-07/g1b_pilot_v3_stopped_s0/postcoverage.json) 통과: raw 상태 182개·최대 trace 상태 나이 0.207초, HOLD 실제 자세 3,197구간 최고 0.00196 m/s·STOP 마지막 0.5초 273구간 최고 0.00104 m/s. 접촉 이벤트 0건은 연속 무접촉 보증이 아님 |
| [v3 등속 앞차 seed 0](../../artifacts/validation/2026-10-07/g1b_pilot_v3_slow_s0/report.json) | **`run_valid=true`, `behavior_gates_passed=false`, `passed=false`.** 진행 2.29977 m < 2.5 m·앞차 이동 중 최장 정체 7.282초 > 2.5초·끝 간격 3.28137 m > 1.2 m로 세 행동 항목 실패. 최소 표본 0.671212 m·swept 하한 0.670826 m, 충돌/이탈·앞차 뒤 유지·명시 STOP·정상 종료는 통과 | [사후 감사 v2](../../artifacts/validation/2026-10-07/g1b_pilot_v3_slow_s0/postcoverage_v2.json) 통과: raw 상태 80개·최대 trace 상태 나이 0.219초, 실제 HOLD 자세 3,780구간 최고 0.009477 m/s·STOP 마지막 0.5초 256구간 속도 0. source 11파일 불변·잔존 없음. 사후 감사 통과는 행동 실패를 성공으로 바꾸지 않음 |

[독립 소스/산출물 감사](../../artifacts/validation/2026-10-07/g1b_source_audit_v2/stopped_s0.json)는 이 실행의 ZIP 등록 소스 43파일·현재 소스·고정 11파일·actor SDF·수신 해시·사후 감사 입력·구독/발행자 목록 일치를 확인했다. `report.json` SHA-256은 `a42ec00da6c674e0881d63b1aa59c713d01aca053bc14a77abcac8793eec426b`, 소스 ZIP은 `69c3b30bc5cfa42c549e1b62572b6d7765a2daa6236e4053e4451c925bc38487`이다. 세부 source SHA는 보고서와 freeze가 기준이다.

[등속 실행의 같은 독립 감사](../../artifacts/validation/2026-10-07/g1b_source_audit_v2/slow_s0.json)도 소스 43파일·freeze 11파일·raw 해시·사후 감사 입력·구독 경계가 일치했다. 보고서 SHA는 `04013c99599f8e224e5d851daac2e721aae19fe873d8cbf527bb6839fbfec4aa`, 소스 ZIP은 `f00e8a229130746779041bc3c9967702d6978ceaba9c6f63bce583a2367f3da8`이다. 실행 벽시계 376.91초와 정상 STOP/종료는 행동 실패와 별도 결과다.

등속 실행의 재개 실마리는 **sim 8.020초의 `follow_boundary_unconfirmed` 전환**이다. 저장 원시 상태는 측정 속도 +0.388959 m/s·`reverse_motion=false`, 원천 7.902초·참조 8.020초·epoch 0, motion `ok`·유효 반환 417개·경계 후보 앞 길이 0.50403 m를 기록했다. trace의 첫 전환 표본은 8.079초이고 보호층은 `clear`·`/drive/safe`는 0이었다. 자차는 8.281초부터 0.05 m/s 미만으로 감속해 끝까지 정체했으며, 앞차는 계속 이동했다(명령 566개·최대 간격 0.022초·최대 관측 위치 오차 0.008055 m). 이후 원천/참조 시각은 진행했고 raw 상태 마지막 참조는 16.040초·원천 15.902초·epoch 0이었다. 따라서 이 실패를 음수 입력 reset의 재발이나 보호층의 간격 정지라고 단정할 근거는 없다. **경계 기억/지원 관측/후보 적합이 왜 이어지지 않았는지는 원인 미확정**이며 현재는 보존 scan·상태와 전환 전후를 재개 시 확인할 실마리만 남겼다.

사용자의 “하던 것까지 하고 잠시 중단” 지시에 따라 등속 파일럿 종료와 기록까지 완료하고 새 수정·시뮬레이션을 중단했다. 등속 핵심 실패가 있어 `stop_restart` seed 0은 실행하지 않았다. **미실행 10개**(재출발 seed 0 1개 + G1 seed 1/2 6개 + R0 seed 0 3개)를 남기며, 다음 순서는 등속 정체 원인과 최소 수정·동일 조건 재시험을 먼저 확인한 뒤 재출발·나머지 비교다. 자동 재개·예약·Claude 초기화 대기·추가 job·커밋/푸시는 없다.

## 재현과 남은 범위

WSL Ubuntu 24.04에서 `/opt/ros/jazzy/setup.bash`·`install/local_setup.bash`를 불러오고, 기존 ROS `PYTHONPATH`를 보존하며 `src/arena_autonomy`와 `src/arena_vehicle_interface`를 앞에 둔다. 회귀는 [보존 run.sh](../../artifacts/validation/2026-10-07/g1b_unit_v4/run.sh)와 같은 목록으로 실행한다. 선택형 launch 설치가 필요하면 `colcon build --packages-select arena_autonomy arena_bringup --symlink-install`을 수행한다.

```bash
/usr/bin/python3 -B scripts/validate_g1_traffic.py --case stopped_center --seed 0 --mode g1 --output artifacts/validation/<새 출력 경로>
```

다른 등록 사례는 `--case slow_lead`/`stop_restart`, 배치는 `--seed 1`/`2`, 비교는 `--mode r0`를 사용한다. 출력 디렉터리는 새로 만들며 각 실행의 `report.json`·`source_snapshot.zip`·자세/상태/명령/STOP/MCU 진단·원시 수신 해시를 보존한다. 큰 원시 수신 자료의 기존 Git 제외 정책을 유지한다.

원시 `scans_received`·autonomy 상태·ego/actor 자세·접촉·trace/trajectory·actuation trace·취득 상세는 로컬 보존/Git 제외이며 summary·SHA·snapshot·보고서는 추적 가능하다. 10/7 실제 산출물에 `git check-ignore`를 대조했고 원시 필수 파일의 tracked 상태는 0개였다. 파일을 삭제하지 않았으며 새 소스 감사에 상세 raw 9파일의 해시를 남긴다.

현재 결과는 시작 직선의 관측 가능한 상자 앞차에 한정한다. 초기 양쪽 가림·낮은 차량/후방 사각·코너/옆차/분기·전체 랩·Jetson 처리 마감·실물 센서·구동·제동·정지·공식 출발/재출발은 남는다. 가상 MCU와 임시 물리 모델의 정지 결과를 MD20A 실차 안전으로 확대하지 않는다.
