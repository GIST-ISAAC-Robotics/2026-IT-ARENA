"""G1-a의 순수 계약/판정 회귀. 합성 관측을 차량 물리 검증으로 부르지 않는다."""
from dataclasses import replace
from types import SimpleNamespace
import math

import numpy as np
import pytest

from arena_autonomy.lidar_motion import MotionConfig, MotionHistory, MotionUnavailable
from arena_autonomy.local_scene import SensorRay, LocalScene, scene_from_scan
from arena_autonomy.scene_motion import motion_scene, transport_points
from arena_autonomy.local_follow import FollowConfig, LocalFollow, pursue_path, boundary_support
from arena_autonomy.local_path import pursuit_command, local_path


def history(v=0., w=0., end=3.):
    result = MotionHistory(MotionConfig(wheel_radius_m=.0325, rear_axle_x_m=-.0675,
                                       lidar_x_m=.06, history_s=5.))
    for time in np.arange(0., end+.0001, .01):
        result.add_mean_wheel(float(time), v/.0325)
        result.add_gyro(float(time), w)
    return result


def scan(first=.5, ranges=None):
    return SimpleNamespace(header=SimpleNamespace(frame_id='laser_frame', stamp=SimpleNamespace(
        sec=int(first), nanosec=round((first-int(first))*1e9))),
        ranges=[1.]*500 if ranges is None else ranges, angle_min=-math.pi,
        angle_increment=math.tau/500, time_increment=.0002, range_min=.05, range_max=12.)


def scene(now, obstacle_x=None, *, epoch=0, side_car=False, missing_wall=False, source=None):
    # 임의 점을 사용하는 계약 단위 시험이며 실제 센서 분해능 시험이 아니다.
    xs = np.linspace(-.25, 2.0, 140)
    left = np.column_stack((xs, xs*0+.425)) if not missing_wall else np.empty((0, 2))
    right = np.column_stack((xs, xs*0-.425))
    points = [left, right]
    if obstacle_x is not None:
        points.append(np.column_stack((np.full(20, obstacle_x), np.linspace(-.075, .075, 20))))
    if side_car:
        points.append(np.column_stack((np.linspace(-.1, .1, 30), np.full(30, .18))))
    points = np.vstack(points)
    first = now-.1 if source is None else source
    rays = []
    for i, point in enumerate(points):
        d = point-np.array([.06, 0.])
        d /= np.linalg.norm(d)
        rays.append(SensorRay((.06, 0.), tuple(point), first, 'return', 'laser_frame', epoch, i, tuple(d)))
    return LocalScene(now, first, first, 'laser_frame', epoch, tuple(rays))


def settle(controller, h, **kwargs):
    result = None
    for now in (.4, .5, .6, .7):
        result = controller.command(scene(now, **kwargs), h, 0., 'left')
    return result


@pytest.mark.parametrize('v,w', [(0., 0.), (1., 0.), (1., .8), (.2, -1.)])
def test_scene_endpoints_match_existing_both_projection(v, w):
    h = history(v, w)
    raw = scan()
    new = motion_scene(raw, h, .7, timing_verified=True, rear_half_angle_deg=0.)
    old, indices, _ = h.project(raw.ranges, raw.angle_min, raw.angle_increment, .05, 12.,
                               .5, .0002, .7, 'both', True)
    np.testing.assert_allclose(new.occupied_endpoints_xy_m, old, atol=1e-12)
    assert new.source_first_s == .5 and new.source_last_s == pytest.approx(.5998)
    assert new.t_ref_s == .7 and len(indices) == 500


def test_unknown_ray_origin_and_direction_are_transported_without_return():
    raw = scan(ranges=[float('inf')]*500)
    new = motion_scene(raw, history(1., 1.), .7, timing_verified=True, rear_half_angle_deg=0.)
    assert all(ray.hit_xy_m is None and ray.status == 'unknown' for ray in new.rays)
    assert new.rays[0].ray_origin_xy_m != new.rays[-1].ray_origin_xy_m
    assert new.rays[0].acquired_at_s == .5


@pytest.mark.parametrize('kind', ['unverified', 'frame', 'zero_step', 'future', 'stale', 'gap'])
def test_scene_refuses_unverified_or_missing_motion(kind):
    raw, h, now, verified = scan(), history(), .7, True
    if kind == 'unverified': verified = False
    if kind == 'frame': raw.header.frame_id = 'world'
    if kind == 'zero_step': raw.time_increment = 0.
    if kind == 'future': now = .55
    if kind == 'stale': now = .81
    if kind == 'gap': h = MotionHistory()
    with pytest.raises(MotionUnavailable):
        motion_scene(raw, h, now, timing_verified=verified)


def test_transport_translation_and_yaw_not_commanded_motion():
    np.testing.assert_allclose(transport_points([[1., 0.]], history(1.), .4, .5), [[.9, 0.]], atol=1e-12)
    h = history(1., .8)
    point = np.array([[.5, .4]])
    moved = transport_points(point, h, .4, .6)
    back = transport_points(moved, h, .6, .6)
    np.testing.assert_allclose(back, moved)
    assert not np.allclose(moved, point)


def test_same_scan_cannot_confirm_or_refresh_boundary():
    ctl, h = LocalFollow(), history()
    for now in (.4, .42, .44, .46):
        speed, _, meta = ctl.command(scene(now, source=.3), h, 0., 'left')
        assert speed == 0 and meta['behavior'] == 'HOLD'
    assert ctl.pending_count == 1


def test_clean_corridor_cruises_and_all_occupied_points_remain():
    speed, steering, meta = settle(LocalFollow(), history())
    assert speed == 1. and abs(steering) < 1e-8 and meta['behavior'] == 'CRUISE'
    assert meta['occupied_points'] == 280 and meta['unfiltered_occupancy']


def test_short_nearby_side_vehicle_cannot_become_wall():
    ctl, h = LocalFollow(), history()
    settle(ctl, h)
    _, steering, meta = ctl.command(scene(.8, side_car=True, missing_wall=True), h, .5, 'left')
    assert abs(steering) < 1e-6
    assert meta['boundary_from_memory'] and meta['occupied_points'] == 170
    assert meta['path_source_s'] == pytest.approx(.6)
    speed, _, meta = ctl.command(scene(1.0, side_car=True, missing_wall=True), h, 0., 'left')
    assert speed == 0 and meta['reason'] == 'follow_boundary_unconfirmed'


def test_one_wall_only_cannot_initialize_new_path():
    speed, _, meta = settle(LocalFollow(), history(), missing_wall=True)
    assert speed == 0 and meta['behavior'] == 'HOLD'


def test_stopped_front_object_hold_and_two_fresh_observations_to_resume():
    ctl, h = LocalFollow(), history()
    settle(ctl, h)
    speed, _, meta = ctl.command(scene(.8, obstacle_x=.40), h, .5, 'left')
    assert speed == 0 and meta['reason'] == 'follow_gap_hold'
    speed, _, meta = ctl.command(scene(.9, obstacle_x=1.), h, 0., 'left')
    assert speed == 0 and meta['reason'] == 'follow_release_wait'
    speed, _, _ = ctl.command(scene(.92, obstacle_x=1., source=.8), h, 0., 'left')
    assert speed == 0
    speed, steering, meta = ctl.command(scene(1., obstacle_x=1.), h, 0., 'left')
    assert 0 < speed < 1 and abs(steering) < 1e-6 and meta['behavior'] == 'FOLLOW'


def test_occupancy_never_comes_from_boundary_memory():
    ctl, h = LocalFollow(), history()
    settle(ctl, h)
    speed, _, meta = ctl.command(scene(.8, obstacle_x=.35, missing_wall=True), h, .5, 'left')
    assert speed == 0 and meta['boundary_from_memory']
    assert meta['occupied_points'] == 160


def test_unknown_front_holds_but_rear_unknown_does_not_cancel_cruise():
    ctl, h = LocalFollow(), history()
    settle(ctl, h)
    base = scene(.8)
    unknown = SensorRay((.06, 0.), None, base.source_first_s, 'unknown', 'laser_frame', 0, 999, (1., 0.))
    speed, _, meta = ctl.command(replace(base, rays=base.rays+(unknown,)), h, .5, 'left')
    assert speed == 0 and meta['reason'] == 'follow_front_unobserved'
    ctl = LocalFollow()
    settle(ctl, h)
    unknown = replace(unknown, status='masked', direction_xy=(-1., 0.))
    speed, _, meta = ctl.command(replace(base, rays=base.rays+(unknown,)), h, .5, 'left')
    assert speed > 0


@pytest.mark.parametrize('change', ['epoch', 'side', 'time_rewind'])
def test_new_epoch_side_or_time_rewind_drops_previous_path(change):
    ctl, h = LocalFollow(), history()
    settle(ctl, h)
    raw = scene(.8, epoch=1 if change == 'epoch' else 0)
    if change == 'time_rewind': raw = scene(.3)
    speed, _, meta = ctl.command(raw, h, 0., 'right' if change == 'side' else 'left')
    assert speed == 0 and meta['behavior'] == 'HOLD'


def test_path_follower_matches_existing_pure_pursuit_on_straight_and_curve():
    t = np.linspace(-.2, 1.5, 180)
    for wall in (np.column_stack((np.linspace(-.1, 2., 200), np.full(200, .425))),
                 np.column_stack((.575*np.sin(t), 1.-.575*np.cos(t)))):
        path, _ = local_path(wall, 'left')
        cfg = FollowConfig(max_speed_mps=2.)
        old_speed, old_steer, _ = pursuit_command(wall, 'left', .5, wheelbase=.135, max_steering=.37, max_speed=2.)
        new_speed, new_steer, _ = pursue_path(path, .5, cfg, .2)
        assert new_speed == pytest.approx(old_speed)
        assert new_steer == pytest.approx(old_steer)


@pytest.mark.parametrize('key,value', [('memory_ttl_s', .31), ('max_speed_mps', 3.),
    ('headway_s', 0.), ('measurement_padding_m', float('nan')), ('confirmations', 1)])
def test_bad_configuration_rejected(key, value):
    with pytest.raises(ValueError): FollowConfig(**{key: value})


def test_partial_scan_geometry_cannot_claim_a_complete_scene():
    raw = scan()
    raw.angle_increment = math.pi/500
    with pytest.raises(MotionUnavailable, match='scan_invalid'):
        motion_scene(raw, history(), .7, timing_verified=True)


def test_out_of_range_point_remains_unknown_not_free_space():
    raw = scan()
    raw.ranges[250] = 50.
    new = motion_scene(raw, history(), .7, timing_verified=True)
    assert new.rays[250].status == 'unknown' and new.rays[250].hit_xy_m is None


def test_existing_node_command_is_unchanged_when_opt_in_is_off():
    from arena_autonomy.local_pursuit import LocalPursuit
    h = history()
    node = SimpleNamespace(follow=None, motion=SimpleNamespace(history=h, last_meta={}), side='left',
        settings={'wheelbase_m': .135, 'max_steering_angle_rad': .37, 'max_speed_mps': 2.5,
                  'lateral_acceleration_limit_mps2': 3.5, 'target_wall_distance_m': .425})
    points = np.asarray(scene(.5).occupied_endpoints_xy_m)
    actual = LocalPursuit.command(node, points)
    expected = pursuit_command(points, 'left', 0., .135, .37, 2.5, 3.5, .425, .2)
    assert actual == expected


def test_node_g1_input_failure_cannot_fall_back_to_r0():
    from arena_autonomy.local_pursuit import LocalPursuit
    h = history()
    node = SimpleNamespace(follow=LocalFollow(), scan=scan(), last_steering=0., side='left',
        motion=SimpleNamespace(history=h, last_meta={'reference_stamp_s': .7}, counts={'resets': 0}, verified=False),
        settings={'control_rate_hz': 50.}, rear_blind_half_angle=30.)
    speed, _, info = LocalPursuit.command(node, np.asarray(scene(.7).occupied_endpoints_xy_m))
    assert speed == 0 and info['reason'] == 'follow_input_stop'


def test_boundary_memory_does_not_turn_same_source_into_fresh_observation():
    ctl, h = LocalFollow(), history()
    settle(ctl, h)
    _, _, first = ctl.command(scene(.8), h, .5, 'left')
    _, _, repeated = ctl.command(scene(.82, source=first['source_first_s']), h, .5, 'left')
    assert first['path_source_s'] == pytest.approx(.7)
    assert repeated['path_source_s'] == pytest.approx(.7)
    assert repeated['boundary_age_s'] > first['boundary_age_s']


def test_missing_motion_for_memory_is_hold_not_static_assumption():
    ctl, h = LocalFollow(), history()
    settle(ctl, h)
    speed, _, meta = ctl.command(scene(.8, missing_wall=True), MotionHistory(), .5, 'left')
    assert speed == 0 and meta['reason'] == 'follow_motion_waiting'


def test_saved_gazebo_short_occluders_use_current_wall_support_not_false_free_space():
    import json
    from pathlib import Path
    sample = Path(__file__).resolve().parents[1]/'artifacts/validation/2026-10-05/g1_gazebo_solo_v1/last_scan.json'
    raw = json.loads(sample.read_text())
    observed = scene_from_scan(raw['ranges'], angle_min=raw['angle_min'],
        angle_increment=raw['angle_increment'], range_min=raw['range_min'], range_max=raw['range_max'],
        acquired_at_s=[.7]*len(raw['ranges']), t_ref_s=.8)
    points = np.asarray(observed.occupied_endpoints_xy_m)
    _, old_info = local_path(points, 'left')
    assert old_info['boundary_observed_ahead_m'] < .3
    ctl, h = LocalFollow(), history()
    settle(ctl, h)
    speed, _, detail = ctl.command(observed, h, 0., 'left')
    assert speed > 0 and detail['fresh_boundary_accepted']
    assert detail['boundary_selection'] == 'observed_history_support'
    assert detail['occupied_points'] == len(points)  # 기둥도 보호 검사에는 전부 남는다.
    assert detail['path_source_s'] == .7
    assert detail['boundary_candidate_ahead_m'] >= .65


def test_boundary_support_cannot_fill_large_missing_wall_segment():
    ctl, h = LocalFollow(), history()
    settle(ctl, h)
    for now in (.8, 1.):
        observed = scene(now)
        rays = tuple(ray for ray in observed.rays if not (ray.hit_xy_m[1] > 0 and .19 < ray.hit_xy_m[0] < .65))
        speed, _, detail = ctl.command(replace(observed, rays=rays), h, .5, 'left')
    assert speed == 0 and detail['reason'] == 'follow_boundary_unconfirmed'


def test_boundary_support_retains_observed_points_beyond_previous_path_end():
    path = np.column_stack((np.linspace(-.25, 1., 36), np.zeros(36)))
    points = np.array([[.3, .425], [.3, .2], [1.5, .5]])
    kept = boundary_support(points, path, 'left', FollowConfig())
    np.testing.assert_allclose(kept, points[[0, 2]])


def test_saved_corner_requires_bilateral_agreement_before_using_long_outer_wall():
    import json
    from pathlib import Path
    raw = json.loads((Path(__file__).resolve().parents[1]/
        'artifacts/validation/2026-10-05/g1_gazebo_solo_v2/last_scan.json').read_text())
    ctl, h = LocalFollow(), history()
    for now in (.4, .5, .6, .7):
        observed = scene_from_scan(raw['ranges'], angle_min=raw['angle_min'], angle_increment=raw['angle_increment'],
            range_min=raw['range_min'], range_max=raw['range_max'],
            acquired_at_s=[now-.1]*len(raw['ranges']), t_ref_s=now)
        speed, _, detail = ctl.command(observed, h, 0., 'left')
    assert speed > 0 and detail['path_wall'] == 'right'
    assert detail['bilateral_alternative_confirmed']
    assert detail['boundary_candidate_ahead_m'] >= .65
    assert detail['occupied_points'] == len(observed.occupied_endpoints_xy_m)


def test_long_opposite_wall_with_inconsistent_short_preferred_boundary_is_not_a_fallback():
    ctl, h = LocalFollow(), history()
    for now in (.4, .5, .6, .7):
        raw = scene(now)
        # 양쪽 벽에서 만든 중심 경로가 서로 다른 회랑이다. 왼쪽 짧은 반환이
        # 허용 앵커 오차 안에 있더라도 형상 일치 없이는 오른쪽만 따르지 않는다.
        rays = tuple(replace(ray, hit_xy_m=(ray.hit_xy_m[0], .315))
            if ray.hit_xy_m[1] > 0 else ray for ray in raw.rays
            if ray.hit_xy_m[1] < 0 or ray.hit_xy_m[0] < .38)
        speed, _, detail = ctl.command(replace(raw, rays=rays), h, 0., 'left')
    assert speed == 0 and detail['behavior'] == 'HOLD'
