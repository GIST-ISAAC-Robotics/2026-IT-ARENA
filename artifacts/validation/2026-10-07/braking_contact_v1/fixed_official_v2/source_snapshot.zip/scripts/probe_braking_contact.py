#!/usr/bin/env python3
"""고정 /drive 명령의 평가 전용 제동 대조. 보호층과 가상 MCU는 유지한다.

official은 현행 파생본, flat은 충돌 노면만 높이 3 mm 단일 판으로 바꾼
분리 시험이다. 원본 파일/차량/센서/모터 물성은 바꾸지 않는다.
차체 정답은 결과 평가·시험 중단에만 사용하고 목표 속도에는 쓰지 않는다.
"""
import argparse
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import time
import xml.etree.ElementTree as ET
import zipfile

from validate_g1_traffic import REPO, SOURCE_FILES, json_reader, sha256, stop_owned
from lidar_shutdown import audit_shutdown, group_processes, stop_gazebo_service, stop_launch


def request_speed(elapsed):
    """0→1 m/s 1초, 유지 1초, 0까지 0.5초, 이후 정지. 시간만 입력."""
    if elapsed < 0:
        return 0.
    if elapsed < 1:
        return elapsed
    if elapsed < 2:
        return 1.
    return max(0., 1.-2.*(elapsed-2.))


def flat_world(source, destination):
    root = ET.parse(source)
    world = root.getroot().find('world')
    count = 0
    for link in world.findall('model/link'):
        for collision in list(link.findall('collision')):
            # 바닥/도로/잔디만 제거한다. 벽·마커·차량 충돌체는 유지.
            name = collision.get('name', '')
            if name == 'ground_plane_link__ground_collision' or name.startswith(('surface_', 'grass_')):
                link.remove(collision)
                count += 1
    if count < 2:
        raise ValueError('시험 노면 충돌체 이름이 변경됐습니다.')
    model = ET.SubElement(world, 'model', name='eval_flat_support')
    ET.SubElement(model, 'static').text = 'true'
    link = ET.SubElement(model, 'link', name='floor')
    collision = ET.SubElement(link, 'collision', name='collision')
    ET.SubElement(collision, 'pose').text = '0 0 -0.047 0 0 0'
    ET.SubElement(ET.SubElement(ET.SubElement(collision, 'geometry'), 'box'), 'size').text = '40 40 0.1'
    # 공식 도로와 같이 surface/friction을 지정하지 않는다.
    for tag in ('uri', 'albedo_map', 'normal_map', 'roughness_map', 'metalness_map'):
        for node in world.findall(f'.//{tag}'):
            if node.text and '://' not in node.text and not Path(node.text).is_absolute():
                node.text = str((source.parent/node.text).resolve())
    root.write(destination, encoding='utf-8', xml_declaration=True)
    return count


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--surface', choices=('official', 'flat'), required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    if not output.is_relative_to(REPO/'artifacts'):
        raise ValueError('시험 자료는 artifacts 안에 보존합니다.')
    output.mkdir(parents=True, exist_ok=False)
    source_paths = [*SOURCE_FILES, str(Path(__file__).relative_to(REPO))]
    sources = {rel: sha256(REPO/rel) for rel in source_paths}
    with zipfile.ZipFile(output/'source_snapshot.zip', 'w', zipfile.ZIP_DEFLATED) as bundle:
        for rel in sources:
            bundle.write(REPO/rel, rel)
    world_dir = REPO/'src/arena_gazebo/worlds/it_arena_official'
    slot = next(s for s in json.loads((world_dir/'scene.json').read_text())['starting_grid']['slots'] if s['index'] == 3)
    extra = []
    report = {'started_at_utc': datetime.now(timezone.utc).isoformat(), 'surface': args.surface,
              'source_sha256': sources, 'scope': 'fixed request, same LiDAR safety and virtual MCU; not autonomous driving',
              'input_valid': False, 'stopped': False, 'shutdown_clean': False}
    if args.surface == 'flat':
        world = output/'flat_world.sdf'
        report['replaced_ground_collisions'] = flat_world(world_dir/'world.sdf', world)
        extra = [f'world_override:={world}', f"test_spawn_x:={slot['x']}",
                 f"test_spawn_y:={slot['y']}", f"test_spawn_yaw:={slot['yaw_rad']}"]
    partition = f'arena_autonomy_test_{os.getpid()}'
    os.environ.update(ROS_DOMAIN_ID=str(150+os.getpid()%30), ROS_AUTOMATIC_DISCOVERY_RANGE='LOCALHOST',
                      ROS_STATIC_PEERS='', GZ_PARTITION=partition)
    os.environ.setdefault('FASTDDS_BUILTIN_TRANSPORTS', 'LARGE_DATA')
    import rclpy
    from rclpy.signals import SignalHandlerOptions
    from rclpy.parameter import Parameter
    from rclpy.qos import qos_profile_sensor_data
    from ackermann_msgs.msg import AckermannDriveStamped
    from sensor_msgs.msg import JointState
    from std_msgs.msg import String
    from std_srvs.srv import Trigger
    rclpy.init(signal_handler_options=SignalHandlerOptions.NO)
    node = rclpy.create_node('fixed_braking_evaluator',
                            parameter_overrides=[Parameter('use_sim_time', value=True)])
    publisher = node.create_publisher(AckermannDriveStamped, '/drive', 10)
    state, trace, contacts, feedback = {}, [], [], []
    audit = dict(json_messages=0, handled_messages=0, parse_errors=0, handler_errors=0, last_error=None)
    interrupted = False
    def interrupt(*_):
        nonlocal interrupted
        interrupted = True
    signal.signal(signal.SIGINT, interrupt)
    signal.signal(signal.SIGTERM, interrupt)
    def dynamics(message):
        row = json.loads(message.data)
        state['dynamics'] = row
        trace.append({**row, 'mcu': state.get('mcu'), 'safe': state.get('safe'), 'request': state.get('request'),
                      'safety': state.get('safety')})
    subscriptions = [
        node.create_subscription(String, '/sim/drivetrain', dynamics, 100),
        node.create_subscription(String, '/actuation/status', lambda m: state.update(mcu=json.loads(m.data)), 100),
        node.create_subscription(String, '/safety/status', lambda m: state.update(safety=json.loads(m.data)), 100),
        node.create_subscription(AckermannDriveStamped, '/drive/safe',
                                 lambda m: state.update(safe=m.drive.speed), 100),
        node.create_subscription(JointState, '/drive_motor/encoder', lambda m: feedback.append(list(m.name)), qos_profile_sensor_data),
    ]
    arm_client = node.create_client(Trigger, '/actuation/arm')
    stop_client = node.create_client(Trigger, '/actuation/stop')
    log_path = output/'simulation.log'
    log = log_path.open('w')
    reader_log = (output/'readers.log').open('w')
    process = reader = arm = stop_future = None
    start = last_command = last_print = None
    began = time.monotonic()
    try:
        process = subprocess.Popen(['ros2', 'launch', '--noninteractive', 'arena_bringup', 'simulation.launch.py',
            'headless:=true', 'autonomy:=false', 'autonomy_mode:=local_pursuit', 'track:=official', 'grid_slot:=3',
            'actuation_mode:=virtual_mcu', 'lidar_acquisition:=sequential', 'lidar_rate_hz:=10',
            'lidar_compensation:=both', 'depth_camera:=false', 'speed_bump:=false', 'traffic_light:=false',
            'render_backend:=wsl_nvidia', 'batch_static_visuals:=true', 'sensor_wall_timeout_s:=30',
            'evaluation_wheel_contacts:=true', f'runtime_artifacts:={output}', *extra], cwd=REPO,
            stdin=subprocess.DEVNULL, stdout=log, stderr=log, start_new_session=True)
        reader = json_reader(['gz', 'topic', '-e', '-t', '/eval/wheels/contact', '--json-output'],
                             contacts.append, reader_log, audit)
        while True:
            rclpy.spin_once(node, timeout_sec=.005)
            if interrupted or time.monotonic()-began > 600:
                raise TimeoutError('interrupted or wall timeout')
            if process.poll() is not None or reader.poll() is not None:
                raise RuntimeError('owned process exited before completion')
            mcu = state.get('mcu', {})
            data = state.get('dynamics')
            if not data or not mcu:
                continue
            now = data['sim_time_s']
            if mcu['state'] in ('ESTOP_LATCHED', 'FAULT_LATCHED') and stop_future is None:
                raise RuntimeError('unexpected MCU latch: '+mcu['reason'])
            if arm is None and now > 1 and mcu['stationary_ready'] and mcu['output_ready'] and arm_client.service_is_ready():
                arm = arm_client.call_async(Trigger.Request())
            if arm is not None and arm.done() and start is None:
                if not arm.result().success:
                    raise RuntimeError('ARM refused')
                start = now+1.
                report['command_start_sim_s'] = start
            elapsed = now-start if start is not None else -1.
            if last_command is None or now-last_command >= .019:
                command = AckermannDriveStamped()
                command.header.stamp = node.get_clock().now().to_msg()
                command.header.frame_id = 'base_link'
                command.drive.speed = request_speed(elapsed)
                publisher.publish(command)
                state['request'] = {'sim_s': now, 'speed_mps': command.drive.speed}
                last_command = now
            if elapsed >= 4.5 and stop_future is None:
                if not stop_client.service_is_ready():
                    raise RuntimeError('STOP service unavailable')
                stop_future = stop_client.call_async(Trigger.Request())
                report['stop_request_sim_s'] = now
            if elapsed >= 5.5:
                report['stop_acknowledged'] = stop_future.done() and stop_future.result().success
                report['final_mcu'] = mcu
                break
            if last_print is None or time.monotonic()-last_print > 20:
                print(f"{args.surface}: elapsed={elapsed:.3f} body={data['truth_longitudinal_mps']:.3f} wheel={data['wheel_surface_speed_mps']:.3f}", flush=True)
                last_print = time.monotonic()
        active = [r for r in trace if start <= r['sim_time_s'] < start+4.5]
        final = [r for r in trace if start+5 <= r['sim_time_s'] <= start+5.5]
        report.update(peak_body_speed_mps=max(abs(r['truth_longitudinal_mps']) for r in active),
                      feedback_names=sorted(set(tuple(n) for n in feedback)), feedback_samples=len(feedback))
        report['input_valid'] = bool(feedback and active and final) and all(
            r['mcu']['feedback_mode'] == 'drive_motor_shaft' for r in active) and report['peak_body_speed_mps'] > .8
        report['stopped'] = bool(final) and all(math.hypot(r['truth_longitudinal_mps'], r['truth_lateral_mps']) < .05
                                               and abs(r['wheel_surface_speed_mps']) < .05 for r in final)
    except Exception as error:
        report['error'] = f'{type(error).__name__}: {error}'
    finally:
        final_command = AckermannDriveStamped()
        final_command.header.stamp = node.get_clock().now().to_msg()
        publisher.publish(final_command)
        if process is not None:
            report['gazebo_stop_service'] = stop_gazebo_service(process, log_path.read_text(errors='replace'), partition)
        cleanup = stop_launch(process)
        if reader is not None:
            report['reader_forced_cleanup'] = stop_owned(reader)
        node.destroy_node()
        rclpy.shutdown()
        log.close()
        reader_log.close()
        report['shutdown_audit'] = audit_shutdown(log_path.read_text(errors='replace'), process.returncode if process else None,
                                                  cleanup.get('forced_cleanup'))
        report['remaining_pids'] = group_processes(process.pid) if process else {}
        report['shutdown_clean'] = bool(report['shutdown_audit']['clean'] and not report['remaining_pids']
                                       and report.get('gazebo_stop_service', {}).get('verified'))
        for name, rows in (('braking_diagnostics', trace), ('wheel_contacts', contacts)):
            path = output/f'{name}.jsonl'
            path.write_text(''.join(json.dumps(r, allow_nan=False)+'\n' for r in rows))
            report[name] = {'samples': len(rows), 'sha256': sha256(path)}
        report['contact_reader_audit'] = audit
        report['source_unchanged'] = all(sha256(REPO/rel) == value for rel, value in sources.items())
        report['wall_elapsed_s'] = time.monotonic()-began
        report['passed'] = bool(report['input_valid'] and report['stopped'] and report['shutdown_clean']
                                and report.get('stop_acknowledged') and report['source_unchanged']
                                and report.get('final_mcu', {}).get('reason') == 'software_stop'
                                and audit['handled_messages'] > 0 and not audit['parse_errors'] and not audit['handler_errors'])
        (output/'report.json').write_text(json.dumps(report, indent=2, allow_nan=False))
        print(json.dumps({k: report.get(k) for k in ('surface', 'input_valid', 'stopped', 'shutdown_clean', 'passed', 'error')}, indent=2))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
