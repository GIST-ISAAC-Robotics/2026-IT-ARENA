"""관측 벽의 지역 평행 경로 + 후륜축 Pure Pursuit. 지도/정답 위치 불사용."""
import copy
import math

import numpy as np


def mask_scan(scan, rear_half_angle_deg=30.):
    """후방 60도는 장착 미확정 사각으로 취급. 빈 공간으로 채우지 않는다."""
    from arena_autonomy.local_scene import blind_spec
    rear, sectors = blind_spec(rear_half_angle_deg)
    result = copy.deepcopy(scan)
    angles = scan.angle_min + np.arange(len(scan.ranges)) * scan.angle_increment
    ranges = np.asarray(scan.ranges, dtype=float).copy()
    ranges[np.abs(angles) > math.radians(180 - rear)] = np.nan
    # 시험 전용 장착 구조 각도. 거리 반환이 있어도 unknown으로 둔다.
    for center, width in sectors:
        offset = np.remainder(angles - math.radians(center) + math.pi, math.tau) - math.pi
        ranges[np.abs(offset) <= math.radians(width) + 1e-12] = np.nan
    result.ranges = ranges.tolist()
    return result


def ray_continuous_gaps(points, gaps, limits, rays, horizon, tolerance=.03, near=6, span=.30, heading=20.):
    """전방으로 멀어지는 옆 벽에서 광선 간격 때문에 생긴 단절만 고른다.

    같은 회전에서 원시 광선 번호가 이어진 가까운 여섯 점의 직선에 다음 두 실제 점이
    수직 3 cm 안으로 놓일 때만 잇는다. 벽 방향이 차체 전방에서 벗어나거나 결측/다른 면이
    끼면 잇지 않는다. 점을 만들거나 옮기지 않으며 실제 벽의 연속을 인증하지 않는다.
    """
    joined = np.zeros(len(gaps), dtype=bool)
    ranges = np.linalg.norm(points, axis=1)
    for index in np.flatnonzero(gaps > limits):
        first, stop = index+1-near, index+3
        if first < 0 or stop > len(points) or ranges[index+1] > horizon:
            continue
        steps = np.diff(rays[first:stop])
        if abs(steps[0]) != 1 or np.any(steps != steps[0]):
            continue
        base = points[first:index+1]
        if np.linalg.norm(base[-1]-base[0]) < span:
            continue
        center = base.mean(axis=0)
        tangent = np.linalg.svd(base-center, full_matrices=False)[2][0]
        if tangent @ (base[-1]-base[0]) < 0:
            tangent = -tangent
        if tangent[0] <= 0 or abs(tangent[1]) > math.sin(math.radians(heading)):
            continue
        offsets = points[first:stop]-center
        joined[index] = (np.max(np.abs(offsets @ [-tangent[1], tangent[0]])) <= tolerance
                         and np.all(np.diff(offsets @ tangent) > 0))
    return joined


def _polyline_offset_path(samples, sign, offset, fillet=.45, min_radius=.40, tolerance=.02,
                          min_turn_deg=20., corner_range_deg=(45., 135.), min_segment=.10):
    """[격리 직각 코너 시험 전용] 꺾은선 관측 벽의 평행 경로. 실제 관측 표본만 쓰고 외삽하지 않는다."""
    from shapely.geometry import LineString
    pts = np.asarray(samples, dtype=float)
    if len(pts) < 12:
        return None
    simple = np.asarray(LineString(pts).simplify(tolerance, preserve_topology=False).coords)
    # 잡음으로 생긴 작은 꺾임은 이웃 구간과 합친다.
    changed = True
    while changed and len(simple) > 2:
        changed = False
        for i in range(1, len(simple)-1):
            a, b = simple[i]-simple[i-1], simple[i+1]-simple[i]
            turn = math.degrees(math.atan2(a[0]*b[1]-a[1]*b[0], a @ b))
            if abs(turn) < min_turn_deg:
                simple = np.delete(simple, i, axis=0)
                changed = True
                break
    # v3: 모서리 재표본화로 생긴 짧은 모따기 구간은 양옆 직선의 교점 하나로 합친다(끝 구간은 버린다).
    while len(simple) > 2:
        lengths = np.linalg.norm(np.diff(simple, axis=0), axis=1)
        short = np.flatnonzero(lengths < min_segment)
        if not len(short):
            break
        i = int(short[0])
        if i == 0 or i == len(lengths)-1:
            simple = np.delete(simple, 0 if i == 0 else len(simple)-1, axis=0)
            continue
        a0, a1, b0, b1 = simple[i-1], simple[i], simple[i+1], simple[i+2]
        da, db = a1-a0, b1-b0
        m = np.column_stack((da, -db))
        if abs(np.linalg.det(m)) < 1e-9:
            return None
        lam = np.linalg.solve(m, b0-a0)
        simple = np.vstack((simple[:i], a0+lam[0]*da, simple[i+2:]))
    if len(simple) < 3 or len(simple) > 5:
        return None
    seg = np.diff(simple, axis=0)
    lengths = np.linalg.norm(seg, axis=1)
    if np.any(lengths < min_segment):
        return None
    t = seg/lengths[:, None]
    n = sign*np.column_stack((t[:, 1], -t[:, 0]))
    turns = [math.degrees(math.atan2(t[i, 0]*t[i+1, 1]-t[i, 1]*t[i+1, 0], t[i] @ t[i+1])) for i in range(len(t)-1)]
    if any(not corner_range_deg[0] <= abs(x) <= corner_range_deg[1] for x in turns):
        return None
    # 평행선 교점(모서리)과 양 끝.
    while True:
        q = [simple[0]+offset*n[0]]
        for i in range(len(t)-1):
            p0, p1 = simple[i+1]+offset*n[i], simple[i+1]+offset*n[i+1]
            m = np.column_stack((t[i], -t[i+1]))
            lam = np.linalg.solve(m, p1-p0)
            q.append(p0+lam[0]*t[i])
        q.append(simple[-1]+offset*n[-1])
        q = np.asarray(q)
        along = np.sum(np.diff(q, axis=0)*t, axis=1)
        # v2: 가림 뒤로 조금만 보인 마지막 벽 조각은 경로에 쓰지 않는다(그 앞 구간까지만).
        if len(t) > 2 and along[-1] <= .05:
            simple, t, n, turns = simple[:-1], t[:-1], n[:-1], turns[:-1]
            continue
        break
    avail = np.linalg.norm(np.diff(q, axis=0), axis=1)
    if np.any(along[1:] <= .05):
        return None
    out = [q[0]]
    used_before = 0.
    for k in range(len(turns)):
        half = math.tan(math.radians(abs(turns[k]))/2)
        # 앞 구간에서 쓸 수 있는 길이와 뒤 구간 관측 길이(다음 모서리가 있으면 절반)를 넘지 않는다.
        room_in = avail[k]-used_before
        room_out = avail[k+1] if k == len(turns)-1 else avail[k+1]/2
        # v2: 첫 모서리 앞 벽은 관측된 벽이며 창(anchor-0.25 m)만 잘린 것이다. 원호 시작이 창 앞으로 가도 된다.
        radius = min(fillet, room_out/half) if k == 0 else min(fillet, room_in/half, room_out/half)
        if radius < min_radius:
            # 다음 구간 관측이 짧다. 두 평행선의 교점(관측 벽에서 offset 떨어진 마지막 점)에서 끝낸다.
            out.append(q[k+1])
            return _densify(out)
        tan_len = radius*half
        start, end = q[k+1]-t[k]*tan_len, q[k+1]+t[k+1]*tan_len
        if k == 0 and tan_len > room_in:
            out = []
        out.append(start)
        side = 1. if turns[k] > 0 else -1.
        normal_in = side*np.array([-t[k, 1], t[k, 0]])
        center = start+radius*normal_in
        a0 = math.atan2(*(start-center)[::-1])
        sweep = math.radians(turns[k])
        for f in np.linspace(0., 1., 12)[1:-1]:
            ang = a0+f*sweep
            out.append(center+radius*np.array([math.cos(ang), math.sin(ang)]))
        out.append(end)
        used_before = tan_len
    # 마지막 관측 구간 뒤에 다른 벽이 이어질 수 있으므로 관측 끝에서 offset만큼 앞에서 끝낸다.
    # (다음 벽이 짧게 보일 때의 교점 끝과 같은 위치가 되어 스캔 사이 경로 끝이 흔들리지 않는다.)
    end = q[-1]-t[-1]*offset
    if (end-out[-1]) @ t[-1] > .02:
        out.append(end)
    return _densify(out)


def _densify(points, step=.02):
    pts = np.asarray(points, dtype=float)
    keep = np.r_[True, np.linalg.norm(np.diff(pts, axis=0), axis=1) > 1e-9]
    pts = pts[keep]
    if len(pts) < 2:
        return None
    s = np.r_[0., np.cumsum(np.linalg.norm(np.diff(pts, axis=0), axis=1))]
    if s[-1] < .05:
        return None
    grid = np.linspace(0., s[-1], max(3, int(s[-1]/step)+1))
    return np.column_stack([np.interp(grid, s, pts[:, i]) for i in (0, 1)])


def local_path(points, side, offset=.425, horizon=1.8, rays=None):
    """연결된 관측 벽의 호길이 매개곡선. 수직 벽/급커브도 y=f(x)로 강제하지 않는다.

    rays는 points와 같은 순서의 원시 광선 번호다. 주지 않으면 거리 간격만으로 연결한다.
    """
    sign = 1 if side == "left" else -1
    points = np.asarray(points, dtype=float)
    if points.ndim != 2 or points.shape[1] != 2:
        return None, {"reason": "wall_lost"}
    finite = np.all(np.isfinite(points), axis=1)
    points = points[finite]
    if len(points) < 12:
        return None, {"reason": "wall_lost"}
    # 보정이 끝난 현재 좌표의 방위 순서. 왼쪽은 감소, 오른쪽은 증가 방향이 전진이다.
    angles = np.arctan2(points[:, 1], points[:, 0])
    order = np.argsort(-sign * angles)
    points = points[order]
    gaps = np.linalg.norm(np.diff(points, axis=0), axis=1)
    # 먼 점의 각도 간격은 넓지만, 떨어진 벽/차량 사이를 잇는 임의 선분은 만들지 않는다.
    limits = .10 + .035 * np.minimum(np.linalg.norm(points[:-1], axis=1), np.linalg.norm(points[1:], axis=1))
    broken = gaps > limits
    if rays is not None:
        broken &= ~ray_continuous_gaps(points, gaps, limits, np.asarray(rays)[finite][order], horizon)
    breaks = np.flatnonzero(broken)
    eligible = []
    for wall in np.split(points, breaks + 1):
        if len(wall) < 12:
            continue
        candidates = np.flatnonzero((np.abs(wall[:, 0]) < .35) & (sign * wall[:, 1] > .10))
        if not len(candidates):
            continue
        distances = np.linalg.norm(wall[candidates] - [0., sign * offset], axis=1)
        anchor = int(candidates[np.argmin(distances)])
        score = float(np.min(distances))
        if score > .35:
            continue
        # 거리 잡음의 지그재그를 모두 더하면 직선의 호길이가 몇 배 부풀고
        # 1.8 m 관측 예산을 실제 0.5 m 정도에서 소진한다. 연결 구간 안에서만
        # 호길이 측정용 좌표를 평활화한다. 실제 적합/잔차와 보호층은 원시 점을 사용한다.
        # 깨끗한 벽의 실제 모서리까지 바꾸지 않는다. 각 중간점과 양옆 점의
        # 현 사이 수직 잔차의 중앙값으로 구간 전체에 퍼진 거칠기만 검출한다.
        # 소수의 모서리/끝면은 이 중앙값을 올리지 않는다.
        chord = wall[2:] - wall[:-2]
        middle = wall[1:-1] - wall[:-2]
        roughness = float(np.median(np.abs(chord[:, 0]*middle[:, 1] - chord[:, 1]*middle[:, 0]) /
                                    np.maximum(1e-9, np.linalg.norm(chord, axis=1))))
        metric = wall
        if roughness > .003:
            padded = np.pad(wall, ((3, 3), (0, 0)), mode='edge')
            metric = np.column_stack([np.convolve(padded[:, axis], np.ones(7)/7, mode='valid')
                                      for axis in (0, 1)])
        steps = np.maximum(1e-6, np.linalg.norm(np.diff(metric, axis=0), axis=1))
        arc = np.r_[0., np.cumsum(steps)]
        anchor_s = arc[anchor]
        first, last = max(0., anchor_s-.25), min(arc[-1], anchor_s+horizon)
        if last-anchor_s >= .28:
            eligible.append((score, wall, arc, anchor, anchor_s, first, last))
    if not eligible:
        return None, {"reason": "wall_segment_short"}
    # 가까운 구간이 기둥에 끊겼다면 그 앞에서 실제 관측한 긴 벽 구간을 선택한다.
    # 구간 사이를 연결하거나 기둥 점을 보호층에서 제거하지 않는다.
    _, wall, arc, anchor, anchor_s, first, last = min(eligible, key=lambda item: item[0])
    # 같은 호길이 간격으로 재표본화하고 이웃 점으로 접선을 구한다. 관측 끝 밖으로 외삽하지 않는다.
    sample_s = np.linspace(first, last, max(12, int((last-first)/.025)+1))
    samples = np.column_stack([np.interp(sample_s, arc, wall[:, axis]) for axis in (0, 1)])
    # x(s), y(s)를 함께 적합한다. y=f(x)와 달리 수직 벽을 표현하며,
    # 상자 벽의 작은 끝면/돌출부를 매 점의 법선으로 증폭하지 않는다.
    u = (sample_s-first) / max(1e-6, last-first)
    basis = np.column_stack((np.ones_like(u), u, u*u, u*u*u))
    weights = np.ones(len(samples))
    for _ in range(5):
        coefficients = np.linalg.lstsq(basis*weights[:, None], samples*weights[:, None], rcond=None)[0]
        residual = np.linalg.norm(basis@coefficients-samples, axis=1)
        weights = np.sqrt(np.minimum(1., .025/np.maximum(residual, 1e-6)))
    if np.percentile(residual, 80) > .06:
        # [격리 직각 코너 시험 전용] 3차식이 표현하지 못하는 꺾인 실제 벽만 꺾은선으로 다시 표현한다.
        shifted = _polyline_offset_path(samples, sign, offset)
        if shifted is None:
            return None, {"reason": "wall_shape_uncertain"}
        path_s = np.r_[0., np.cumsum(np.linalg.norm(np.diff(shifted, axis=0), axis=1))]
        path = np.column_stack([np.interp(np.linspace(0., path_s[-1], 36), path_s, shifted[:, axis]) for axis in (0, 1)])
        return path, {"reason": "local_path", "shape_model": "polyline_trial", "boundary_samples": len(wall),
                      "boundary_observed_ahead_m": float(last-anchor_s),
                      "wall_distance_m": float(abs(wall[anchor, 1])), "path_points": path.tolist()}
    smoothed = basis @ coefficients
    tangent = np.column_stack((u*0, u*0+1, 2*u, 3*u*u)) @ coefficients
    norm = np.linalg.norm(tangent, axis=1)
    if np.any(norm < 1e-7):
        return None, {"reason": "wall_tangent_uncertain"}
    tangent /= norm[:, None]
    normal = sign * np.column_stack((tangent[:, 1], -tangent[:, 0]))
    shifted = smoothed + offset * normal
    # 판/벽 끝면의 작은 반경에 평행 곡선을 만들면 오프셋 곡선이 접힐 수 있다.
    # 관측 벽과 반대 방향으로 진행하는 접힌 가지를 경로에 포함하지 않는다.
    direction = np.sum(np.diff(shifted, axis=0) * (tangent[1:]+tangent[:-1]), axis=1)
    folds = np.flatnonzero(direction <= 0.)
    anchor_index = int(np.argmin(np.abs(sample_s-anchor_s)))
    before = folds[folds < anchor_index]
    after = folds[folds >= anchor_index]
    lo = int(before[-1]+1) if len(before) else 0
    hi = int(after[0]+1) if len(after) else len(shifted)
    shifted = shifted[lo:hi]
    if len(shifted) < 3:
        return None, {'reason': 'offset_path_folded'}
    # 원래 관측 벽과 그 법선만 사용한다. 36점은 경로 표현 해상도이며 새 센서점이 아니다.
    path_s = np.r_[0., np.cumsum(np.linalg.norm(np.diff(shifted, axis=0), axis=1))]
    path = np.column_stack([np.interp(np.linspace(0., path_s[-1], 36), path_s, shifted[:, axis]) for axis in (0, 1)])
    return path, {"reason": "local_path", "boundary_samples": len(wall),
                  "boundary_observed_ahead_m": float(last-anchor_s),
                  "wall_distance_m": float(abs(wall[anchor, 1])), "path_points": path.tolist()}


def pursuit_command(points, side, speed, wheelbase=.145, max_steering=.37,
                    max_speed=2.0, lateral_acceleration=3.5, offset=.425, scan_age=.2):
    failure = None
    for wall in (side, 'right' if side == 'left' else 'left'):
        target_speed, steering, details = _pursuit_for_wall(
            points, wall, speed, wheelbase, max_steering, max_speed, lateral_acceleration, offset, scan_age)
        details.update(preferred_wall=side, path_wall=wall, wall_fallback=wall != side)
        if target_speed > 0:
            if wall != side:
                details['preferred_wall_failure'] = failure['reason']
                target_speed = min(target_speed, 1.2)
            return target_speed, steering, details
        if failure is None:
            failure = details
        else:
            failure['alternate_wall_failure'] = details['reason']
    return 0., 0., failure


def _pursuit_for_wall(points, side, speed, wheelbase, max_steering, max_speed,
                      lateral_acceleration, offset, scan_age):
    path, details = local_path(points, side, offset)
    if path is None:
        return 0., 0., details
    # 모델 원점은 양 축 중간. Pure Pursuit 원점은 후륜축이다.
    rear = path.copy()
    rear[:, 0] += wheelbase / 2
    distances = np.linalg.norm(rear, axis=1)
    nearest = int(np.argmin(distances))
    ahead = np.flatnonzero((rear[:, 0] > .10) & (np.arange(len(rear)) >= nearest))
    if len(ahead) < 3 or np.max(distances[ahead]) < .25:
        return 0., 0., {**details, "reason": "path_too_short"}
    lookahead = min(.60, max(.30, .30 + .12 * abs(speed)))
    index = int(ahead[np.argmin(np.abs(distances[ahead] - lookahead))])
    target = rear[index]
    curvature = float(2 * target[1] / max(.01, target @ target))
    steering = float(np.clip(math.atan(wheelbase * curvature), -max_steering, max_steering))
    # 관측 끝 뒤를 계속 직선이라고 가정하지 않는다. 새 관측을 못 받더라도
    # 현재 유효한 경로 안에서 감속할 수 있도록 미리 속도를 제한한다.
    path_s = np.r_[0., np.cumsum(np.linalg.norm(np.diff(rear, axis=0), axis=1))]
    remaining = float(path_s[-1]-path_s[nearest])
    observed_cap = braking_speed(remaining, scan_age)
    # 전방의 경로 곡률도 미리 본다. 당장 조향이 0이어도 급커브 전에는 감속한다.
    dx = np.gradient(rear, axis=0)
    ddx = np.gradient(dx, axis=0)
    path_curvature = np.abs(dx[:, 0]*ddx[:, 1]-dx[:, 1]*ddx[:, 0]) / np.maximum(1e-8, np.linalg.norm(dx, axis=1)**3)
    preview_caps = np.sqrt(lateral_acceleration/np.maximum(.15, path_curvature[nearest:]) +
                           4.*np.maximum(0., path_s[nearest:]-path_s[nearest]-.2))
    target_speed = min(max_speed, observed_cap, float(np.min(preview_caps)),
                       math.sqrt(lateral_acceleration / max(.15, abs(curvature))))
    return target_speed, steering, {**details, "lookahead_m": float(distances[index]),
                                   "observed_path_ahead_m": remaining, "observed_path_speed_cap_mps": observed_cap,
                                   "target_xy_rear_m": target.tolist(), "curvature_m_inv": curvature}


def swept_limit(points, steering, wheelbase=.145, horizon=3., margin=.025, length=.20, width=.15):
    """정곡률 예측 차체와 점군의 첫 간섭까지 후륜축 이동 거리를 계산한다."""
    points = np.asarray(points, dtype=float)
    curvature = math.tan(steering) / wheelbase
    distances = np.arange(0., horizon + .001, .04)
    # 같은 4 cm 표본을 여덟 개씩 묶는다. libm 삼각함수와 연산 순서를 유지하여
    # 경계의 포함 판정·첫 간섭·4 cm 차감이 기존 순차 계산과 같도록 한다.
    for start in range(0, len(distances), 8):
        steps = distances[start:start+8]
        yaw = curvature * steps
        c = np.asarray([math.cos(value) for value in yaw])[:, None]
        s = np.asarray([math.sin(value) for value in yaw])[:, None]
        if abs(curvature) < 1e-5:
            rx, ry = steps[:, None] - wheelbase / 2, 0.
        else:
            rx, ry = s / curvature - wheelbase / 2, (1 - c) / curvature
        dx, dy = points[:, 0] - rx, points[:, 1] - ry
        local_x = c * dx + s * dy - wheelbase / 2
        local_y = -s * dx + c * dy
        hit = np.any((np.abs(local_x) <= length/2 + margin) & (np.abs(local_y) <= width/2 + margin), axis=1)
        indices = np.flatnonzero(hit)
        if len(indices):
            return max(0., float(steps[indices[0]]) - .04)  # 이산 검사 간격을 안전 여유로 차감
    return horizon


def braking_speed(clearance, age, deceleration=2.0):
    reaction = max(0., age) + .10
    distance = max(0., clearance - .06)
    return max(0., -deceleration * reaction + math.sqrt((deceleration * reaction) ** 2 + 2 * deceleration * distance))
