"""직선 저속 이동차 추월의 선택형 시뮬 후보. 차량 ID/지도/정답 자세를 받지 않는다.

기존 G1/G2 추종을 기본 출력으로 두고, 연속 전진 관측이 있는 앞면에서만 진입한다.
경로/점유/현재 이동영역은 EntryGuide로 다시 검사한다. 상대를 놓쳤다는 이유로
복귀하지 않는다. 후방 현재 반환에 차량 최대 평면 대각선과 측정/시차 여유를 더한
외곽이 자차 뒤에 있고 복귀 띠도 관측될 때만 기존 복귀 곡선을 허용한다.
이 대각선은 20x15 cm 규격의 조건부 외곽 상계이며 물체 신원/미래 운동 보증은 아니다.
첫 범위는 명목 0.30 m/s 상대 한 대와 직선 통로, 자차 명령 최대 0.65 m/s다.
진입 시 상대 속도는 관측 오차를 더한 추정이 0.50 m/s 이하여야 한다.
"""
from dataclasses import dataclass
import math

import numpy as np

from arena_autonomy.bypass_entry_trial import EntryConfig, EntryGuide
from arena_autonomy.bypass_handoff import front_patch
from arena_autonomy.bypass_handoff_corridor_trial import entry_path_conflict
from arena_autonomy.lidar_motion import MotionUnavailable
from arena_autonomy.known_structure import ACCEPTED_HIDDEN_WIDTH_M, classify, parse_sectors
from arena_autonomy.observation_support import source_valid
from arena_autonomy.scene_motion import transport_points


@dataclass(frozen=True)
class MovingEntryConfig(EntryConfig):
    speed_cap_mps: float = .65
    offsets_m: tuple = (0., -.20, .20, -.24, .24, -.27, .27)

    def __post_init__(self):
        if (isinstance(self.speed_cap_mps, bool) or not math.isfinite(self.speed_cap_mps)
                or not 0 < self.speed_cap_mps <= .65):
            raise ValueError('moving pass initial speed envelope is (0, .65] m/s')
        # 기존 경로 형상 조건은 유지하고 별도 시험 속도 범위만 정의한다.
        EntryConfig(self.offsets_m, self.transitions_m, min(.35, self.speed_cap_mps),
                    self.path_step_m, self.prefer_earlier_transition)


class MovingTargetTrack:
    """한 후보의 현재 반환 연결. 기억은 대응 탐색용이며 자유 공간/복귀 허가가 아니다."""
    max_gap_s = .4
    association_margin_m = .20
    association_speed_mps = .75
    # 완전히 보이지 않은 부분까지 포함한 규격 직사각형의 최대 평면 길이.
    target_diagonal_m = math.hypot(.20, .15)
    rear_margin_m = .06

    def __init__(self, config):
        self.config = config
        self.reset()

    def reset(self):
        self.points = None
        self.reference = self.source = self.epoch = None
        self.walls = None
        self.current = None
        self.rear_count = 0
        self.detail = dict(observed=False, rear_clear=False, reason='not_started')

    def begin(self, scene, points, walls):
        self.reset()
        self.points = np.asarray(points, dtype=float).copy()
        self.reference, self.source, self.epoch = scene.t_ref_s, scene.source_first_s, scene.source_epoch
        self.walls = []
        for side, wall in walls.items():
            sign = 1. if side == 'left' else -1.
            a = wall['slope']
            b = wall['intercept_m'] + sign*self.config.wall_offset_m*math.hypot(1., a)
            x = np.asarray(wall['observed_x_m'])
            self.walls.append(np.c_[x, a*x+b])
        self.current = self.points.copy()
        self.detail = dict(observed=True, rear_clear=False, reason='front_candidate_started')

    @staticmethod
    def clusters(points, indices):
        if len(points) == 0:
            return []
        # 마스크를 사이에 둔 다른 면을 연결하지 않고 각 관측 조각을 대응시킨다.
        cuts = (np.linalg.norm(np.diff(points, axis=0), axis=1) > .10) | (np.diff(indices) > 2)
        return [p for p in np.split(points, np.flatnonzero(cuts)+1)
                if len(p) >= 3 and np.linalg.norm(np.ptp(p, axis=0)) <= .35]

    def update(self, scene, history):
        try:
            return self._update(scene, history)
        except (ValueError, MotionUnavailable) as error:
            self.reset()
            self.detail = dict(observed=False, rear_clear=False,
                               reason='target_motion_unavailable', error=str(error))
            return self.detail

    def front_bound(self, points, scene):
        age = max(0., scene.t_ref_s-self.source)
        return (float(np.max(points[:, 0]))+self.target_diagonal_m
                +self.config.measurement_padding_m+self.config.object_motion_bound_mps*age)

    def _update(self, scene, history):
        self.current = None
        if (self.points is None or not source_valid(scene) or scene.source_epoch != self.epoch
                or scene.source_first_s < self.source or scene.t_ref_s < self.reference):
            self.reset()
            return self.detail
        if scene.source_first_s == self.source:
            # 같은 센서 관측을 재사용하되 뒤로 통과한 확인 횟수는 늘리지 않는다.
            if self.detail.get('observed'):
                self.current = transport_points(self.points, history, self.reference, scene.t_ref_s)
                bound = self.front_bound(self.current, scene)
                if bound >= -self.config.length_m/2-self.rear_margin_m:
                    self.rear_count = 0
                self.detail = dict(self.detail, front_bound_m=bound, rear_clear=self.rear_count >= 2,
                                   rear_confirmations=self.rear_count, fresh=False)
            return dict(self.detail, fresh=False)
        elapsed = scene.source_first_s-self.source
        if elapsed > self.max_gap_s:
            self.rear_count = 0
            self.detail = dict(observed=False, rear_clear=False, reason='target_observation_expired')
            return self.detail
        old = transport_points(self.points, history, self.reference, scene.t_ref_s)
        walls = [transport_points(w, history, self.reference, scene.t_ref_s) for w in self.walls]
        rays = [r for r in scene.rays if r.status == 'return']
        points = np.asarray([r.hit_xy_m for r in rays], dtype=float).reshape(-1, 2)
        indices = np.asarray([r.source_index for r in rays])
        keep = np.ones(len(points), dtype=bool)
        for wall in walls:
            delta = wall[-1]-wall[0]
            norm = np.linalg.norm(delta)
            if norm > .1:
                distance = abs(delta[0]*(points[:, 1]-wall[0, 1])-delta[1]*(points[:, 0]-wall[0, 0]))/norm
                keep &= distance > .035
        center = np.median(old, axis=0)
        gate = self.association_margin_m+self.association_speed_mps*elapsed
        keep &= np.linalg.norm(points-center, axis=1) <= gate
        candidates = self.clusters(points[keep], indices[keep])
        ranked = sorted([(float(np.linalg.norm(np.median(p, axis=0)-center)), p) for p in candidates],
                        key=lambda pair: pair[0])
        if not ranked or (len(ranked) > 1 and ranked[1][0]-ranked[0][0] < .06):
            self.rear_count = 0
            self.detail = dict(observed=False, rear_clear=False, reason='target_missing_or_ambiguous',
                               candidates=len(ranked), fresh=True)
            return self.detail
        chosen = ranked[0][1]
        self.points, self.walls, self.reference, self.source = chosen.copy(), walls, scene.t_ref_s, scene.source_first_s
        self.current = chosen.copy()
        # 보이는 점만으로 앞 범퍼를 단정하지 않는다. 어느 반환에서든 규격 대각선까지 더한다.
        front_bound = self.front_bound(chosen, scene)
        behind = front_bound < -self.config.length_m/2-self.rear_margin_m
        self.rear_count = self.rear_count+1 if behind else 0
        self.detail = dict(observed=True, fresh=True, rear_clear=self.rear_count >= 2,
                           rear_confirmations=self.rear_count, front_bound_m=front_bound,
                           observed_bounds_xy=[chosen.min(axis=0).tolist(), chosen.max(axis=0).tolist()],
                           identity_proven=False, reason='current_associated_returns')
        return self.detail


def rear_wall_witness(scene, config, side, fit, wall, explained_sectors):
    """지지대 양옆에서 실제로 보인 면이 일치할 때만 후륜축의 경로 기준을 연장한다.

    뒤쪽 짧은 면은 작은 차량 옆면일 수도 있다. 긴 벽에 붙이거나 고정 점유로
    분류하지 않는다. 원래의 고정 여유 적용 광선 목록과 가림 상태도 보존한다.
    """
    if fit is None or wall.get('reason') != 'current_connected_straight_wall_fit':
        return fit, wall
    a,b,lower,upper=fit
    if lower <= -config.wheelbase_m/2 or upper < .30 or upper-lower < .65:
        return fit, wall
    ids=wall['source_ray_indices']
    rays={r.source_index:r for r in scene.rays}
    if not ids or ids[0] not in rays or ids[-1] not in rays:
        return fit, wall
    # 광선 획득 순서는 좌/우에서 반대다. 차체 뒤쪽 끝에서 바깥 방향으로 검사한다.
    edge,step=min(((ids[0],-1),(ids[-1],1)), key=lambda e:rays[e[0]].hit_xy_m[0])
    sign=1 if side=='left' else -1
    norm=math.hypot(1.,a)
    actual_b=b+sign*config.wall_offset_m*norm
    shift=sign*config.wall_offset_m*a/norm
    i=edge+step
    gap=[]
    while i in rays and rays[i].status=='masked':
        gap.append(i);i+=step
    if not gap or frozenset(gap) not in explained_sectors or i not in rays or rays[i].status!='return':
        return fit,wall
    chord=math.dist(rays[edge].hit_xy_m,rays[i].hit_xy_m)
    if chord>ACCEPTED_HIDDEN_WIDTH_M:
        return fit,wall
    points=[];last=rays[edge].hit_xy_m
    while i in rays and rays[i].status=='return':
        p=rays[i].hit_xy_m
        if (not -.40<=p[0]<last[0] or math.dist(last,p)>.05
                or abs(p[1]-a*p[0]-actual_b)/norm>.015):
            break
        points.append(p);last=p;i+=step
    if len(points)<12 or points[0][0]-points[-1][0]<.20:
        return fit,wall
    x,y=np.asarray(points).T
    observed_slope=np.dot(x-x.mean(),y-y.mean())/np.dot(x-x.mean(),x-x.mean())
    new_lower=float(min(x)+shift)
    if new_lower > -config.wheelbase_m/2 or abs(math.atan(observed_slope)-math.atan(a))>.08:
        return fit,wall
    proof=dict(principal_x_m=[lower,upper],observed_rear_x_m=[float(min(x)),float(max(x))],
               rear_return_count=len(points),mask_indices=sorted(gap),shadow_chord_m=chord,
               short_piece_static=False,unknown_filled=False)
    return (a,b,new_lower,upper),{**wall,'observed_x_m':[new_lower,upper],'rear_geometry_witness':proof}


class MovingPassGuide(EntryGuide):
    def __init__(self, config, tracker):
        self.tracker = tracker
        self.raw_scan = None
        self.sectors = (parse_sectors(config.known_structure_sectors_json)
                        if config.known_structure_policy=='structure_aware_v1' else ())
        super().__init__(config, MovingEntryConfig(), stationary_outer_boundary=True,
                         rejoin_enabled=True, wall_reanchor=True, tracked_wall_fit=True)

    def _outer_wall_fit(self,scene,remembered_wall):
        fit,wall=super()._outer_wall_fit(scene,remembered_wall)
        if (fit is None or fit[2]<=-self.config.wheelbase_m/2 or not self.sectors
                or self.raw_scan is None or len(self.raw_scan.ranges)!=len(scene.rays)):
            return fit,wall
        _,_,rows=classify(self.raw_scan,self.sectors)
        explained={frozenset(row['rays'].tolist()) for row in rows if row['explained']}
        return rear_wall_witness(scene,self.config,self.side,fit,wall,explained)

    def _rejoin_band(self, scene, fit):
        band = super()._rejoin_band(scene, fit)
        rear = self.tracker.detail.get('rear_clear', False) and self.tracker.current is not None
        return {**band, 'supported': bool(band['supported'] and rear),
                'moving_target_rear_observed': rear, 'target': self.tracker.detail}


class MovingPassAdapter:
    """기존 추종 출력과 이동차 경로를 전환. 구조/독립 보호와 점유 검사를 유지한다."""
    max_lead_speed_mps = .50
    minimum_speed_advantage_mps = .15

    def __init__(self, owner):
        self.owner = owner
        self.tracker = MovingTargetTrack(owner.config)
        self.guide = MovingPassGuide(owner.config, self.tracker)
        self.active = False
        self.admission = {}
        self.blocked_sources = []
        self.deferred = None
        self.front_absent_since = None

    def reset(self):
        self.tracker.reset()
        self.guide.reset()
        self.active = False
        self.admission = {}
        self.blocked_sources.clear()
        self.deferred = self.front_absent_since = None

    def _defer_same_encounter(self,scene):
        if self.deferred is None:
            return False
        if scene.source_epoch!=self.deferred[0] or scene.source_first_s<self.deferred[1]:
            self.deferred=self.front_absent_since=None
            return False
        patch,_=front_patch(scene,self.owner.execution.front_patch_policy)
        if patch is not None:
            self.front_absent_since=None
        elif self.front_absent_since is None:
            self.front_absent_since=scene.source_first_s
        elif scene.source_first_s-self.front_absent_since>=.6:
            # 다음 앞면의 연속 관측부터 새 제안 가능. 앞차 소실은 복귀 허가가 아니다.
            self.deferred=self.front_absent_since=None
            return False
        return True

    def _abort_evidence(self,scene,speed,blocked):
        """현재 스캔의 반복 간섭·실제 저속·상대가 아직 앞이라는 양의 관측을 함께 요구한다."""
        source=scene.source_first_s
        self.blocked_sources=[t for t in self.blocked_sources if 0<=source-t<=.60+1e-9]
        if blocked and source not in self.blocked_sources:
            self.blocked_sources.append(source)
        if (self.guide.phase!='entry' or len(self.blocked_sources)<3
                or self.blocked_sources[-1]-self.blocked_sources[0]<.19 or speed>.15
                or self.tracker.current is None or not self.tracker.detail.get('observed')):
            return None
        cfg=self.owner.config
        age=scene.t_ref_s-source
        # 어느 면을 보고 있는지 확정하지 않고 규격 대각선 전체를 뒤쪽에도 남긴다.
        rear=float(np.min(self.tracker.current[:,0]))-self.tracker.target_diagonal_m
        rear-=cfg.measurement_padding_m+cfg.object_motion_bound_mps*age
        reserve=cfg.length_m/2+.06+speed*(age+.10)+speed*speed/4.
        if rear<=reserve:return None
        return dict(current_rear_lower_m=rear,required_ahead_m=reserve,
                    blocked_scans=len(self.blocked_sources),measured_speed_mps=speed)

    def _try_abort(self,scene,history,speed,side,previous,dt,raw_scan,evidence):
        # 실제 추종기가 현재 센서로 계산한 경로/속도를 그대로 사용한다. 따로 계산한
        # 중앙 좌표로 강제 복귀하거나 정지 출력을 양수로 덮어쓰지 않는다.
        returning='right' if self.guide.side=='left' else 'left'
        normal=self.owner._base_command(scene,history,speed,side,previous,dt,raw_scan=raw_scan)
        if not self.active:
            return normal  # 입력 불연속에 의한 기존 리셋이 우선한다.
        n=normal[2].get('normal',{})
        threat=n.get('selector_sides',{}).get(returning)
        if (normal[0]<=0 or self.owner.mode!='FOLLOW' or threat is None or threat.get('present')
                or threat.get('seen') or not n.get('fresh_boundary_accepted')
                or n.get('boundary_from_memory') or n.get('observed_path_ahead_m',0.)<.30
                or n.get('swept_clearance_m',0.)<=.06):
            return None
        self.reset()
        self.deferred=(scene.source_epoch,scene.source_first_s)
        return normal[0],normal[1],{**normal[2],'moving_pass':dict(
            reason='aborted_to_observed_follow',completed=False,abort=evidence)}

    def eligibility(self, scene, history):
        pace = self.owner.monitor.forward_pace
        if (pace is None or len(pace.rows) < 5 or pace.rate <= 0
                or pace.rows[-1][0] != scene.source_first_s):
            return dict(ready=False, reason='continuous_forward_observation_required')
        span = pace.rows[-1][0]-pace.rows[0][0]
        # 보수 추종율을 역산하면 마지막 구간 감속을 놓친다. 현재 좌표로 옮긴 실제
        # 다섯 관측의 이동량에 같은 거리 오차 예산을 더해 초기 속도 차이를 고른다.
        # 관측 오차에 대한 선택값이지 상대의 미래 가속 상계가 아니다.
        try:
            q = np.asarray([transport_points(p[None], history, ref, scene.t_ref_s)[0]
                            for _, ref, p in pace.rows])
        except (ValueError, MotionUnavailable):
            return dict(ready=False, reason='target_speed_motion_unavailable')
        estimate_upper = (q[-1, 0]-q[0, 0]+pace.bound)/span if span > 0 else math.inf
        ready = (estimate_upper <= self.max_lead_speed_mps and
                 self.guide.entry.speed_cap_mps-estimate_upper >= self.minimum_speed_advantage_mps)
        return dict(ready=ready, reason='slow_forward_candidate' if ready else 'speed_advantage_insufficient',
                    estimated_lead_upper_mps=estimate_upper, source_span_s=span,
                    pass_speed_cap_mps=self.guide.entry.speed_cap_mps,
                    scope='initial_straight_slow_target_only', future_speed_guaranteed=False)

    def command(self, scene, history, speed, side, previous, dt, *, raw_scan=None):
        owner = self.owner
        self.guide.raw_scan = raw_scan
        if (raw_scan is None or not source_valid(scene) or side not in ('left','right')
                or not all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v)
                           for v in (speed,previous,dt))
                or abs(previous)>owner.config.max_steering_rad or not 0<dt<=.2):
            self.reset()
            return owner._base_command(scene,history,speed,side,previous,dt,raw_scan=raw_scan)
        if not self.active:
            normal = owner._base_command(scene, history, speed, side, previous, dt, raw_scan=raw_scan)
            if self._defer_same_encounter(scene):
                return normal[0],normal[1],{**normal[2],'moving_pass':dict(
                    ready=False,reason='same_encounter_follow_after_abort')}
            gate = self.eligibility(scene, history)
            detail = {**normal[2], 'moving_pass': gate}
            if not gate['ready'] or owner.mode != 'FOLLOW' or abs(previous) > .08:
                self.guide.reset()
                return normal[0], normal[1], detail
            patch, _ = front_patch(scene, owner.execution.front_patch_policy)
            if patch is None:
                self.guide.reset()
                return normal[0], normal[1], detail
            proposal = self.guide.evaluate(scene, history, speed, previous, dt)
            chosen = proposal.get('selected')
            detail['moving_pass']['entry'] = proposal
            if not chosen or not chosen['offset_m']:
                return normal[0], normal[1], detail
            conflict = entry_path_conflict(dict(path_points=self.guide.path), scene, owner.config)
            gate['path_conflict'] = conflict
            if chosen['speed_mps'] <= gate['estimated_lead_upper_mps'] or conflict['rejected']:
                self.guide.reset()
                gate['reason'] = 'entry_speed_or_path_conflict'
                return normal[0], normal[1], detail
            selected_side = 'left' if chosen['offset_m'] > 0 else 'right'
            threat = normal[2].get('normal', {}).get('selector_sides', {}).get(selected_side)
            if threat is None or threat.get('present') or threat.get('seen'):
                self.guide.reset()
                detail['moving_pass']['reason'] = 'current_side_threat_or_unavailable'
                return normal[0], normal[1], detail
            self.tracker.begin(scene, patch, proposal['reference']['walls'])
            self.active = True
            self.admission = {k:v for k,v in gate.items() if k != 'entry'}
            return self._output(chosen, proposal, 'moving_pass_entry')
        target = self.tracker.update(scene, history)
        if not source_valid(scene) or scene.source_epoch != self.tracker.epoch:
            self.reset()
            owner.normal.reset()
            return 0., previous, dict(reason='moving_pass_source_reset', behavior='HOLD',
                                     mode='g1_g2_handoff_trial', handoff_state='MOVING_PASS', simulation_trial_only=True,
                                     output_requires_independent_guard=True)
        proposal = self.guide.evaluate(scene, history, speed, previous, dt)
        chosen = proposal.get('selected')
        abort=self._abort_evidence(scene,speed,chosen is None and any(
            row.get('reason')=='known_occupied_command_hold' for row in proposal.get('candidates',())))
        if abort is not None:
            alternative=self._try_abort(scene,history,speed,side,previous,dt,raw_scan,abort)
            if alternative is not None:return alternative
        if proposal.get('entry_phase') == 'centered':
            owner.reset()
            normal = owner._base_command(scene, history, speed, side, previous, dt, raw_scan=raw_scan)
            return normal[0], normal[1], {**normal[2], 'moving_pass':dict(reason='rejoined', completed=True)}
        if chosen is None:
            return 0., previous, dict(reason='moving_pass_current_path_unavailable', behavior='HOLD',
                                     mode='g1_g2_handoff_trial', handoff_state='MOVING_PASS', simulation_trial_only=True,
                                     moving_pass=dict(target=target, entry=proposal),
                                     output_requires_independent_guard=True)
        return self._output(chosen, proposal, 'moving_pass_'+self.guide.phase)

    def _output(self, chosen, proposal, reason):
        return chosen['speed_mps'], chosen['steering_rad'], dict(
            reason=reason, behavior='MOVING_PASS', mode='g1_g2_handoff_trial',
            handoff_state='MOVING_PASS', simulation_trial_only=True,
            output_requires_independent_guard=True,
            moving_pass=dict(admission=self.admission, phase=self.guide.phase,
                             target=self.tracker.detail, entry=proposal))
