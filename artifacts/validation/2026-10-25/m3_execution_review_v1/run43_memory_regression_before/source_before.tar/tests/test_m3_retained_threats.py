"""같은 측면 두 물체의 위협 기록 보존. 합성 상태 검증이며 물리/주행 증명 아님."""
import numpy as np
import pytest
import arena_autonomy.m3_execution_trial as mx
from test_lateral_intent import GRASS, car
from test_local_follow import history
from test_m3_execution_trial import padding
from test_m3_observed_follow import timed_scene


def sequence(kind, side=1.):
    d0 = -.09*side
    trial = mx.ExecutionLateralTrial(GRASS, mx.ExecutionConfig(release_to_baseline=True))
    rows = []
    for k in range(50):
        t = round(1.+.1*k, 3)
        ax, bx = max(-.65, .3-.4*(t-1.)), .30+.4*abs(t-3.5)
        a = car(ax, .08*side, d0, width=.10)
        b = car(bx, .24*side, d0, width=.10)
        objects = [a, b] if kind == 'both' else [a] if kind == 'a_only' else [b]
        scene, path = timed_scene(t, d0, extra=objects)
        motion = history(end=t+.01)
        motion.poses(np.array([t-.2, t]), t)
        rows.append((t, trial.step(scene, [], path, .35, padding(scene), history=motion)))
    return trial, rows


@pytest.mark.parametrize('side', [1., -1.])
def test_new_same_side_vehicle_cannot_erase_hidden_previous_vehicle(side):
    trial, rows = sequence('both', side)
    assert not any(row.get('released_to_baseline') for _, row in rows)
    assert trial.active


def test_first_vehicle_alone_stays_guarded():
    trial, rows = sequence('a_only')
    assert not any(row.get('released_to_baseline') for _, row in rows) and trial.active
