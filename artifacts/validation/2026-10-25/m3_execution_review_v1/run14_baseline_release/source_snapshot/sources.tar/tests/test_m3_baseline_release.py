"""측방 시험의 기본 G1 복귀(선택) 경계. 관측·간격·보호 기준을 면제하지 않는다.

기존 상태기는 중앙 후보가 선택되고 횡위치가 5 mm 안일 때만 시험을 끝낸다. 후방 마스크 경계의 꼬리 흔들림 띠
때문에 주행 중 곡선 명령이 지지되지 않으면 중앙에서 벗어난 출발 자세의 시험은 끝나지 않는다(run13).
"""
import pytest

import arena_autonomy.m3_execution_trial as mx
from arena_autonomy.local_follow import FollowConfig, LocalFollow
from test_lateral_intent import GRASS, car
from test_local_follow import history
from test_m3_execution_trial import padding, ctl
from test_m3_observed_follow import timed_scene

D0 = -.09   # 공식 3번 슬롯과 같은 도로 횡위치
RELEASE = mx.ExecutionConfig(release_to_baseline=True)


def step(trial, now, extra=()):
    scene, path = timed_scene(now, D0, extra=list(extra))
    return trial.step(scene, [], path, .35, padding(scene))


def ahead_left():
    return [car(.30, .13, D0)]       # 뒤 면 ds 약 0.20 m: 자차 앞면(0.10 m)보다 앞


def far_ahead_left():
    return [car(.95, .13, D0)]       # 측방 창(앞 0.35 m) 밖


def test_release_option_is_explicit_bool_and_default_false():
    assert mx.ExecutionConfig().release_to_baseline is False
    with pytest.raises(ValueError):
        mx.ExecutionConfig(release_to_baseline=1)


def test_side_return_positions_match_precheck_counts():
    scene, path = timed_scene(1., D0, extra=ahead_left())
    frame = mx.ExecutionFrame(path)
    state = mx.ego_state(frame, GRASS)
    grid = mx.ReturnGrid(scene, GRASS)
    left, right = mx.side_return_ds(frame, state, grid, GRASS)
    assert mx.side_points(frame, state, grid, GRASS) == (len(left), len(right))
    assert len(left) and not len(right) and min(left) > GRASS.length_m/2


def test_threat_passed_ahead_releases_after_two_distinct_clear_scans():
    trial = mx.ExecutionLateralTrial(GRASS, RELEASE)
    first = step(trial, 1.0, ahead_left())
    assert first['threats']['left']['present'] and trial.active
    assert first['last_threat_rear_ds_m'] > GRASS.length_m/2
    second = step(trial, 1.1, far_ahead_left())
    assert second['mode'] != 'BASELINE' and trial.active and trial.clear_fresh == 1
    third = step(trial, 1.2, far_ahead_left())
    assert third['mode'] == 'BASELINE' and third['released_to_baseline'] and not trial.active
    assert third['path'] is not None and not third['runtime_authorized']
    assert step(trial, 1.3, far_ahead_left())['mode'] == 'BASELINE'


def test_same_scan_repeat_does_not_count_toward_release():
    trial = mx.ExecutionLateralTrial(GRASS, RELEASE)
    step(trial, 1.0, ahead_left())
    scene, path = timed_scene(1.1, D0, extra=far_ahead_left())
    trial.step(scene, [], path, .35, padding(scene))
    from dataclasses import replace
    again = trial.step(replace(scene, t_ref_s=1.12), [], path, .35, padding(scene))   # 같은 원본 스캔
    assert again['mode'] != 'BASELINE' and trial.clear_fresh == 1 and trial.active
    assert step(trial, 1.2, far_ahead_left())['mode'] == 'BASELINE'


@pytest.mark.parametrize('x_center', [-.40, 0.])
def test_threat_lost_behind_or_beside_never_releases(x_center):
    trial = mx.ExecutionLateralTrial(GRASS, RELEASE)
    first = step(trial, 1.0, [car(x_center, .13, D0)])
    assert first['threats']['left']['present']
    assert first['last_threat_rear_ds_m'] < GRASS.length_m/2
    for k in range(1, 6):
        out = step(trial, 1.0+.1*k)
        assert out['mode'] != 'BASELINE' and trial.active
    assert 'center' in out['checks']        # 기존 중앙 후보 경로만 남는다


def test_default_off_keeps_center_only_exit():
    trial = mx.ExecutionLateralTrial(GRASS, mx.ExecutionConfig())
    step(trial, 1.0, ahead_left())
    for k in range(1, 5):
        out = step(trial, 1.0+.1*k, far_ahead_left())
        assert out['mode'] != 'BASELINE' and trial.active
        assert 'last_threat_rear_ds_m' not in out and 'released_to_baseline' not in out
    assert 'center' in out['checks']


def test_reappearing_threat_reactivates_after_release():
    trial = mx.ExecutionLateralTrial(GRASS, RELEASE)
    step(trial, 1.0, ahead_left())
    step(trial, 1.1, far_ahead_left())
    assert step(trial, 1.2, far_ahead_left())['mode'] == 'BASELINE'
    again = step(trial, 1.3, [car(-.40, .13, D0)])
    assert again['mode'] != 'BASELINE' and trial.active and again['last_threat_rear_ds_m'] < 0


def test_epoch_reset_clears_last_threat_position():
    trial = mx.ExecutionLateralTrial(GRASS, RELEASE)
    step(trial, 1.0, ahead_left())
    trial.reset()
    assert trial.last_threat_rear_ds is None and not trial.active


def test_released_controller_output_equals_baseline_g1():
    """해제 뒤 출력은 같은 입력의 기본 G1과 같다. 0.35 m/s 시험 상한·M3 외곽 검사를 덧씌우지 않는다."""
    follow = ctl(RELEASE)
    reference = LocalFollow(FollowConfig(occupancy_timing_mode='per_ray_candidate'))
    h = history(v=.3)
    released, active = [], []
    # 기본 G1의 처음 세 호출은 경계 확인 대기라 측방 상태기가 돌지 않는다. 준비 뒤 옆차를 등장시킨다.
    scenes = [(.4, far_ahead_left()), (.5, far_ahead_left()), (.6, far_ahead_left()), (.7, ahead_left()),
              (.8, ahead_left()), (.9, far_ahead_left()), (1.0, far_ahead_left()), (1.1, far_ahead_left())]
    for now, extra in scenes:
        scene, _ = timed_scene(now, D0, extra=extra)
        got = follow.command(scene, h, .3, 'left')
        expected = reference.command(scene, h, .3, 'left')
        lateral = got[2].get('m3_lateral', {})
        if lateral.get('mode') not in (None, 'BASELINE'):
            active.append(now)
            assert got[0] <= .35+1e-12                     # 활성 중에는 시험 상한 유지
        if lateral.get('released_to_baseline') or (released and lateral.get('mode') == 'BASELINE'):
            released.append(now)
            assert got[:2] == expected[:2] and got[2]['reason'] == expected[2]['reason']
    assert active and released and min(released) > max(active), (active, released)
    after = follow.command(timed_scene(1.2, D0, extra=far_ahead_left())[0], h, .3, 'left')
    assert after[2]['m3_lateral']['mode'] == 'BASELINE' and after[0] > .35   # 해제 뒤에는 기본 G1 속도 상한
