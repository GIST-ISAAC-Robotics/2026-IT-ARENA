#!/usr/bin/env python3
"""고정 /drive 명령의 평가 전용 제동 대조. 보호층과 가상 MCU는 유지한다.

official은 현행 파생본, flat은 충돌 노면만 높이 3 mm 단일 판으로 바꾼
분리 시험이다. 원본 파일/차량/센서/모터 물성은 바꾸지 않는다.
차체 정답은 결과 평가·시험 중단에만 사용하고 목표 속도에는 쓰지 않는다.
"""
import argparse
from datetime import datetime, timezone
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import time
import xml.etree.ElementTree as ET
import zipfile

from braking_command_profile import load_profile, audit_requests
from scheduled_command import (GridSchedule, ProfileSampler, REGISTERED_PERIOD_NS,
                               align_up, audit_scheduled_requests)
from validate_g1_traffic import REPO, SOURCE_FILES, json_reader, sha256, stop_owned
from lidar_shutdown import audit_shutdown, group_processes, stop_gazebo_service, stop_launch


def request_speed(elapsed):
    """0→1 m/s 1초, 유지 1초, 0까지 0.5초, 이후 정지. 시간만 입력."""
    if elapsed < 0:
        return 0.
    if elapsed < 1:
        return elapsed
    if elapsed < 2:
        return 1.
    return max(0., 1.-2.*(elapsed-2.))


def flat_world(source, destination):
    root = ET.parse(source)
    world = root.getroot().find('world')
    count = 0
    for link in world.findall('model/link'):
        for collision in list(link.findall('collision')):
            # 바닥/도로/잔디만 제거한다. 벽·마커·차량 충돌체는 유지.
            name = collision.get('name', '')
            if name == 'ground_plane_link__ground_collision' or name.startswith(('surface_', 'grass_')):
                link.remove(collision)
                count += 1
    if count < 2:
        raise ValueError('시험 노면 충돌체 이름이 변경됐습니다.')
    model = ET.SubElement(world, 'model', name='eval_flat_support')
    ET.SubElement(model, 'static').text = 'true'
    link = ET.SubElement(model, 'link', name='floor')
    collision = ET.SubElement(link, 'collision', name='collision')
    ET.SubElement(collision, 'pose').text = '0 0 -0.047 0 0 0'
    ET.SubElement(ET.SubElement(ET.SubElement(collision, 'geometry'), 'box'), 'size').text = '40 40 0.1'
    # 공식 도로와 같이 surface/friction을 지정하지 않는다.
    for tag in ('uri', 'albedo_map', 'normal_map', 'roughness_map', 'metalness_map'):
        for node in world.findall(f'.//{tag}'):
            if node.text and '://' not in node.text and not Path(node.text).is_absolute():
                node.text = str((source.parent/node.text).resolve())
    root.write(destination, encoding='utf-8', xml_declaration=True)
    return count


def evaluation_extra(physics_step=None, world=None, slot=None):
    """기본 실행 인자는 이전과 같다. 평가 step은 명시했을 때만 launch에 전달한다."""
    extra = [f'evaluation_physics_step:={physics_step}'] if physics_step else []
    if world is not None:
        extra += [f'world_override:={world}', f"test_spawn_x:={slot['x']}",
                  f"test_spawn_y:={slot['y']}", f"test_spawn_yaw:={slot['yaw_rad']}"]
    return extra


def schedule_arguments(schedule, phase_ms, profile_given):
    """선택형 격자 발행 인자 검사. 기본 poll이면 None(기존 발행 경로)."""
    if schedule == 'poll':
        if phase_ms is not None:
            raise ValueError('--schedule-phase-ms requires --command-schedule sim_grid')
        return None
    if schedule != 'sim_grid':
        raise ValueError('unknown command schedule')
    if not profile_given:
        raise ValueError('sim_grid schedule requires --command-profile')
    if phase_ms not in ('0', '10'):
        raise ValueError('sim_grid schedule requires registered --schedule-phase-ms 0 or 10')
    return {'mode': 'sim_grid', 'period_ns': REGISTERED_PERIOD_NS, 'phase_ns': int(phase_ms)*1_000_000}


def clock_summary(values, begin_ns, end_ns):
    """평가기 구독으로 받은 /clock 값의 간격 분포. 발행 해상도와 수신 유실을 구분하지 못한다."""
    inside = [v for v in values if begin_ns <= v <= end_ns]
    deltas = [b-a for a, b in zip(inside, inside[1:])]
    histogram = {}
    for delta in deltas:
        histogram[delta] = histogram.get(delta, 0)+1
    return {'messages': len(inside), 'regressions': sum(d < 0 for d in deltas), 'repeats': sum(d == 0 for d in deltas),
            'min_positive_delta_ns': min((d for d in deltas if d > 0), default=None),
            'max_delta_ns': max(deltas, default=None),
            'delta_ns_top': sorted(histogram.items(), key=lambda kv: -kv[1])[:10],
            'scope': 'best-effort 구독 기준. 간격이 step보다 크면 발행 묶음 또는 수신 유실이며 둘을 구분하지 않는다.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--surface', choices=('official', 'flat'), required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--zero-speed-mode', default='legacy',
                        choices=('legacy', 'reset_integral', 'no_lag', 'passive_damping'))
    parser.add_argument('--command-profile', type=Path,
                        help='선택형 사전 고정 속도/조향 요청 JSON. 생략하면 기존 완만한 제동 시험.')
    parser.add_argument('--physics-step', choices=('0.0005', '0.00025'),
                        help='평가 전용 물리 step 민감도. 생략하면 월드 기본 1 ms.')
    parser.add_argument('--command-schedule', choices=('poll', 'sim_grid'), default='poll',
                        help='poll=기존 now-last>=.019 발행(기본). sim_grid=시뮬레이션 시계 20 ms 정수 격자 발행(평가 전용)')
    parser.add_argument('--schedule-phase-ms', choices=('0', '10'),
                        help='sim_grid 격자의 sim 시각 위상(20 ms 주기 기준 0 또는 10 ms)')
    args = parser.parse_args()
    grid_spec = schedule_arguments(args.command_schedule, args.schedule_phase_ms, args.command_profile is not None)
    profile = load_profile(args.command_profile) if args.command_profile else None
    sampler = ProfileSampler(profile) if grid_spec else None
    output = args.output.resolve()
    if not output.is_relative_to(REPO/'artifacts'):
        raise ValueError('시험 자료는 artifacts 안에 보존합니다.')
    output.mkdir(parents=True, exist_ok=False)
    source_paths = [*SOURCE_FILES, str(Path(__file__).relative_to(REPO))]
    source_paths += ['scripts/braking_command_profile.py']
    if grid_spec:
        source_paths.append('scripts/scheduled_command.py')
    if args.command_profile:
        source_paths.append(args.command_profile.resolve().relative_to(REPO).as_posix())
    sources = {rel: sha256(REPO/rel) for rel in source_paths}
    with zipfile.ZipFile(output/'source_snapshot.zip', 'w', zipfile.ZIP_DEFLATED) as bundle:
        for rel in sources:
            bundle.write(REPO/rel, rel)
    world_dir = REPO/'src/arena_gazebo/worlds/it_arena_official'
    slot = next(s for s in json.loads((world_dir/'scene.json').read_text())['starting_grid']['slots'] if s['index'] == 3)
    report = {'started_at_utc': datetime.now(timezone.utc).isoformat(), 'surface': args.surface,
              'source_sha256': sources, 'scope': 'fixed request, same LiDAR safety and virtual MCU; not autonomous driving',
              'input_valid': False, 'stopped': False, 'shutdown_clean': False}
    report['spawn'] = {key: slot[key] for key in ('x', 'y', 'yaw_rad')}
    report['zero_speed_mode'] = args.zero_speed_mode
    report['physics_step_override_s'] = args.physics_step
    if grid_spec:
        report['command_schedule'] = dict(grid_spec)
    report['command_profile'] = ({'path': args.command_profile.resolve().relative_to(REPO).as_posix(),
                                  'sha256': sha256(args.command_profile), 'duration_s': profile.duration_s,
                                  'brake_window_s': profile.brake_window_s, 'source': profile.source}
                                 if profile else None)
    stop_elapsed = profile.duration_s+1. if profile else 4.5
    finish_elapsed = stop_elapsed+1.
    if args.surface == 'flat':
        world = output/'flat_world.sdf'
        report['replaced_ground_collisions'] = flat_world(world_dir/'world.sdf', world)
    extra = evaluation_extra(args.physics_step, world if args.surface == 'flat' else None, slot)
    partition = f'arena_autonomy_test_{os.getpid()}'
    os.environ.update(ROS_DOMAIN_ID=str(150+os.getpid()%30), ROS_AUTOMATIC_DISCOVERY_RANGE='LOCALHOST',
                      ROS_STATIC_PEERS='', GZ_PARTITION=partition)
    os.environ.setdefault('FASTDDS_BUILTIN_TRANSPORTS', 'LARGE_DATA')
    import rclpy
    from rclpy.signals import SignalHandlerOptions
    from rclpy.parameter import Parameter
    from rclpy.qos import qos_profile_sensor_data
    from ackermann_msgs.msg import AckermannDriveStamped
    from sensor_msgs.msg import JointState
    from std_msgs.msg import String
    from std_srvs.srv import Trigger
    from rclpy.qos import QoSProfile, ReliabilityPolicy
    from rosgraph_msgs.msg import Clock
    rclpy.init(signal_handler_options=SignalHandlerOptions.NO)
    node = rclpy.create_node('fixed_braking_evaluator',
                            parameter_overrides=[Parameter('use_sim_time', value=True)])
    publisher = node.create_publisher(AckermannDriveStamped, '/drive', 10)
    state, trace, contacts, feedback = {}, [], [], []
    requests, safe_commands = [], []
    audit = dict(json_messages=0, handled_messages=0, parse_errors=0, handler_errors=0, last_error=None)
    # sim_grid 전용 전달 추적. 기존 폴링 경로에는 구독을 추가하지 않는다.
    mcu_statuses, output_statuses, clock_values = [], [], []
    schedule = start_ns = None
    last_clock_msg = [None]
    interrupted = False
    def interrupt(*_):
        nonlocal interrupted
        interrupted = True
    signal.signal(signal.SIGINT, interrupt)
    signal.signal(signal.SIGTERM, interrupt)
    def dynamics(message):
        row = json.loads(message.data)
        state['dynamics'] = row
        trace.append({**row, 'mcu': state.get('mcu'), 'safe': state.get('safe'), 'request': state.get('request'),
                      'safety': state.get('safety')})
    def safe_command(message):
        row = {'sim_s': message.header.stamp.sec+message.header.stamp.nanosec*1e-9,
               'speed_mps': message.drive.speed, 'steering_rad': message.drive.steering_angle}
        safe_commands.append(row)
        state.update(safe=row['speed_mps'], safe_command=row)
    subscriptions = [
        node.create_subscription(String, '/sim/drivetrain', dynamics, 100),
        node.create_subscription(String, '/actuation/status', lambda m: state.update(mcu=json.loads(m.data)), 100),
        node.create_subscription(String, '/safety/status', lambda m: state.update(safety=json.loads(m.data)), 100),
        node.create_subscription(AckermannDriveStamped, '/drive/safe', safe_command, 100),
        node.create_subscription(JointState, '/drive_motor/encoder', lambda m: feedback.append(list(m.name)), qos_profile_sensor_data),
    ]
    if grid_spec:
        def on_clock(message):
            value = message.clock.sec*1_000_000_000+message.clock.nanosec
            last_clock_msg[0] = value
            if len(clock_values) < 400_000:
                clock_values.append(value)
        def on_mcu_status(message):
            data = json.loads(message.data)
            mcu_statuses.append({k: data.get(k) for k in ('now_us', 'target_speed_mps', 'steering_rad', 'state',
                                                          'reason', 'accepted_seq', 'deadline_us')})
        def on_output_status(message):
            data = json.loads(message.data)
            output_statuses.append({k: data.get(k) for k in ('now_us', 'speed_mps', 'blocked', 'reason', 'last_status_us')})
        subscriptions += [
            node.create_subscription(Clock, '/clock', on_clock,
                                     QoSProfile(depth=1000, reliability=ReliabilityPolicy.BEST_EFFORT)),
            node.create_subscription(String, '/actuation/status', on_mcu_status, 1000),
            node.create_subscription(String, '/actuation/output_status', on_output_status, 1000),
        ]
    arm_client = node.create_client(Trigger, '/actuation/arm')
    stop_client = node.create_client(Trigger, '/actuation/stop')
    log_path = output/'simulation.log'
    log = log_path.open('w')
    reader_log = (output/'readers.log').open('w')
    process = reader = arm = stop_future = None
    start = last_command = last_print = None
    began = time.monotonic()
    try:
        process = subprocess.Popen(['ros2', 'launch', '--noninteractive', 'arena_bringup', 'simulation.launch.py',
            'headless:=true', 'autonomy:=false', 'autonomy_mode:=local_pursuit', 'track:=official', 'grid_slot:=3',
            'actuation_mode:=virtual_mcu', 'lidar_acquisition:=sequential', 'lidar_rate_hz:=10',
            'lidar_compensation:=both', 'depth_camera:=false', 'speed_bump:=false', 'traffic_light:=false',
            'render_backend:=wsl_nvidia', 'batch_static_visuals:=true', 'sensor_wall_timeout_s:=30',
            'evaluation_wheel_contacts:=true', f'evaluation_zero_speed_mode:={args.zero_speed_mode}',
            f'runtime_artifacts:={output}', *extra], cwd=REPO,
            stdin=subprocess.DEVNULL, stdout=log, stderr=log, start_new_session=True)
        reader = json_reader(['gz', 'topic', '-e', '-t', '/eval/wheels/contact', '--json-output'],
                             contacts.append, reader_log, audit)
        while True:
            rclpy.spin_once(node, timeout_sec=.005)
            if interrupted or time.monotonic()-began > 600:
                raise TimeoutError('interrupted or wall timeout')
            if process.poll() is not None or reader.poll() is not None:
                raise RuntimeError('owned process exited before completion')
            mcu = state.get('mcu', {})
            data = state.get('dynamics')
            if not data or not mcu:
                continue
            now = node.get_clock().now().nanoseconds*1e-9
            if mcu['state'] in ('ESTOP_LATCHED', 'FAULT_LATCHED') and stop_future is None:
                raise RuntimeError('unexpected MCU latch: '+mcu['reason'])
            if arm is None and now > 1 and mcu['stationary_ready'] and mcu['output_ready'] and arm_client.service_is_ready():
                arm = arm_client.call_async(Trigger.Request())
            if arm is not None and arm.done() and start is None:
                if not arm.result().success:
                    raise RuntimeError('ARM refused')
                if profile:
                    report['drive_publishers'] = sorted(i.node_name for i in node.get_publishers_info_by_topic('/drive'))
                    report['safe_drive_publishers'] = sorted(i.node_name for i in node.get_publishers_info_by_topic('/drive/safe'))
                    report['drive_graph_valid'] = (report['drive_publishers'] == ['fixed_braking_evaluator']
                        and report['safe_drive_publishers'] == ['lidar_safety'])
                    if not report['drive_graph_valid']:
                        raise RuntimeError('unexpected command publisher graph')
                if grid_spec:
                    # ARM 확인 시계값 이후 첫 격자점에서 발행을 시작하고, 1 s 뒤 첫 격자점을 프로필 0으로 둔다.
                    now_ns = node.get_clock().now().nanoseconds
                    origin_ns = align_up(now_ns, grid_spec['period_ns'], grid_spec['phase_ns'])
                    start_ns = align_up(now_ns+1_000_000_000, grid_spec['period_ns'], grid_spec['phase_ns'])
                    schedule = GridSchedule(grid_spec['period_ns'], grid_spec['phase_ns'], origin_ns)
                    report['command_schedule'].update(arm_observed_ns=now_ns, origin_ns=origin_ns, start_ns=start_ns)
                    start = start_ns/1e9
                else:
                    start = now+1.
                report['command_start_sim_s'] = start
                # 렌더링/물리 실시간 비율은 시뮬레이션 시간과 구분해 기록한다.
                report['arm_done_wall_s'] = time.monotonic()-began
            elapsed = now-start if start is not None else -1.
            if grid_spec:
                # ARM 전에는 발행하지 않는다. 한 번 읽은 시계값으로 판정과 header stamp를 같이 쓴다.
                if schedule is not None:
                    clock_now = node.get_clock().now()
                    now_ns = clock_now.nanoseconds
                    elapsed = (now_ns-start_ns)/1e9
                    tick = schedule.poll(now_ns)
                    if tick is not None:
                        command = AckermannDriveStamped()
                        command.header.stamp = clock_now.to_msg()
                        command.header.frame_id = 'base_link'
                        speed, steering = sampler.at_ns(tick.scheduled_ns-start_ns)
                        command.drive.speed, command.drive.steering_angle = speed, steering
                        publisher.publish(command)
                        state['request'] = {'sim_s': now_ns/1e9, 'speed_mps': speed, 'steering_rad': steering,
                                            'scheduled_ns': tick.scheduled_ns, 'observed_ns': tick.observed_ns,
                                            'header_ns': command.header.stamp.sec*1_000_000_000+command.header.stamp.nanosec,
                                            'index': tick.index, 'lateness_ns': tick.lateness_ns,
                                            'missed_before': tick.missed_before, 'clock_msg_ns': last_clock_msg[0]}
                        requests.append(state['request'])
            elif last_command is None or now-last_command >= .019:
                command = AckermannDriveStamped()
                command.header.stamp = node.get_clock().now().to_msg()
                command.header.frame_id = 'base_link'
                speed, steering = profile.at(elapsed) if profile else (request_speed(elapsed), 0.)
                command.drive.speed, command.drive.steering_angle = speed, steering
                publisher.publish(command)
                state['request'] = {'sim_s': now, 'speed_mps': speed, 'steering_rad': steering}
                requests.append(state['request'])
                last_command = now
            if elapsed >= stop_elapsed and stop_future is None:
                if not stop_client.service_is_ready():
                    raise RuntimeError('STOP service unavailable')
                stop_future = stop_client.call_async(Trigger.Request())
                report['stop_request_sim_s'] = now
            if elapsed >= finish_elapsed:
                report['finish_wall_s'] = time.monotonic()-began
                report['finish_sim_s'] = now
                report['stop_acknowledged'] = stop_future.done() and stop_future.result().success
                report['final_mcu'] = mcu
                break
            if last_print is None or time.monotonic()-last_print > 20:
                print(f"{args.surface}: elapsed={elapsed:.3f} body={data['truth_longitudinal_mps']:.3f} wheel={data['wheel_surface_speed_mps']:.3f}", flush=True)
                last_print = time.monotonic()
        active = [r for r in trace if start <= r['sim_time_s'] < start+stop_elapsed]
        final = [r for r in trace if start+finish_elapsed-.5 <= r['sim_time_s'] <= start+finish_elapsed]
        report.update(peak_body_speed_mps=max(abs(r['truth_longitudinal_mps']) for r in active),
                      feedback_names=sorted(set(tuple(n) for n in feedback)), feedback_samples=len(feedback))
        report['input_valid'] = bool(feedback and active and final) and all(
            r['mcu']['feedback_mode'] == 'drive_motor_shaft' for r in active) and report['peak_body_speed_mps'] > .8
        report['mode_observed'] = bool(active) and all(
            r.get('evaluation_zero_speed_mode') == args.zero_speed_mode for r in active)
        report['input_valid'] &= report['mode_observed']
        if profile and grid_spec:
            # 격자 모드 전용 감사. 기존 폴링 모드의 audit_requests 판정은 그대로 둔다.
            report['request_audit_mode'] = 'sim_grid_scheduled'
            report['request_audit'] = audit_scheduled_requests(
                requests, sampler, start_ns, start_ns+sampler.duration_ns, grid_spec['period_ns'], grid_spec['phase_ns'])
            report['clock_observation'] = clock_summary(clock_values, report['command_schedule']['origin_ns'],
                                                        round(report['finish_sim_s']*1e9))
        elif profile:
            report['request_audit'] = audit_requests(requests, profile, start, start+profile.duration_s)
            gaps = [b['sim_time_s']-a['sim_time_s'] for a, b in zip(active, active[1:])]
            report['dynamics_coverage'] = {'samples': len(active), 'max_gap_s': max(gaps, default=None),
                'first_delay_s': active[0]['sim_time_s']-start if active else None,
                'last_delay_s': start+stop_elapsed-active[-1]['sim_time_s'] if active else None}
            report['dynamics_coverage']['passed'] = bool(gaps and min(gaps) > 0 and max(gaps) <= .05
                and report['dynamics_coverage']['first_delay_s'] <= .05
                and report['dynamics_coverage']['last_delay_s'] <= .05)
            report['final_stationary_coverage'] = bool(len(final) >= 20
                and final[-1]['sim_time_s']-final[0]['sim_time_s'] >= .45)
            report['input_valid'] &= (report['request_audit']['passed'] and report['dynamics_coverage']['passed']
                                      and report['final_stationary_coverage'] and report['drive_graph_valid'])
        report['stopped'] = bool(final) and all(math.hypot(r['truth_longitudinal_mps'], r['truth_lateral_mps']) < .05
                                               and abs(r['wheel_surface_speed_mps']) < .05 for r in final)
    except Exception as error:
        report['error'] = f'{type(error).__name__}: {error}'
    finally:
        final_command = AckermannDriveStamped()
        final_command.header.stamp = node.get_clock().now().to_msg()
        publisher.publish(final_command)
        if process is not None:
            report['gazebo_stop_service'] = stop_gazebo_service(process, log_path.read_text(errors='replace'), partition)
        cleanup = stop_launch(process)
        if reader is not None:
            report['reader_forced_cleanup'] = stop_owned(reader)
        node.destroy_node()
        rclpy.shutdown()
        log.close()
        reader_log.close()
        report['shutdown_audit'] = audit_shutdown(log_path.read_text(errors='replace'), process.returncode if process else None,
                                                  cleanup.get('forced_cleanup'))
        report['remaining_pids'] = group_processes(process.pid) if process else {}
        report['shutdown_clean'] = bool(report['shutdown_audit']['clean'] and not report['remaining_pids']
                                       and report.get('gazebo_stop_service', {}).get('verified'))
        streams = [('braking_diagnostics', trace), ('wheel_contacts', contacts),
                   ('requested_commands', requests), ('safe_commands', safe_commands)]
        if grid_spec:
            streams += [('actuation_status', mcu_statuses), ('output_status', output_statuses)]
            if schedule is not None:
                report['command_schedule']['diagnostics'] = schedule.diagnostics()
        for name, rows in streams:
            path = output/f'{name}.jsonl'
            path.write_text(''.join(json.dumps(r, allow_nan=False)+'\n' for r in rows))
            report[name] = {'samples': len(rows), 'sha256': sha256(path)}
        report['contact_reader_audit'] = audit
        report['source_unchanged'] = all(sha256(REPO/rel) == value for rel, value in sources.items())
        report['wall_elapsed_s'] = time.monotonic()-began
        report['passed'] = bool(report['input_valid'] and report['stopped'] and report['shutdown_clean']
                                and report.get('stop_acknowledged') and report['source_unchanged']
                                and report.get('final_mcu', {}).get('reason') == 'software_stop'
                                and audit['handled_messages'] > 0 and not audit['parse_errors'] and not audit['handler_errors'])
        (output/'report.json').write_text(json.dumps(report, indent=2, allow_nan=False))
        print(json.dumps({k: report.get(k) for k in ('surface', 'input_valid', 'stopped', 'shutdown_clean', 'passed', 'error')}, indent=2))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
