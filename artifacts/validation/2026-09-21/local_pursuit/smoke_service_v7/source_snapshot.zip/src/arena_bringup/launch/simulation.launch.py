from __future__ import annotations

import json
import copy
import math
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

import xacro
import yaml
from ament_index_python.packages import get_package_share_directory, get_package_prefix
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, LogInfo, OpaqueFunction, SetEnvironmentVariable, TimerAction
from launch.substitutions import EnvironmentVariable, LaunchConfiguration
from launch_ros.actions import Node
from launch.actions import RegisterEventHandler
from launch.event_handlers import OnShutdown


TRACK_DIRECTORIES = {
    "official": "it_arena_official",
    "original": "it_arena_track",
    "experimental": "it_arena_experimental",
}
D435I_STREAM_PROFILES = ("high_speed_async", "synchronized_60", "low_load_30")
TOF_PROFILES = ("low_latency_4x4_60", "tracking_8x8_15")
TOF_MODULE_NAMES = {"front", "front_left", "rear_left", "rear", "rear_right", "front_right"}
AUTONOMY_MODES = ("lidar", "stereo", "local_pursuit")
SENSOR_LAYOUT_BY_MODE = {"lidar": "lidar_tof6", "stereo": "stereo_tof4", "local_pursuit": "none"}
DIFFERENTIAL_PROFILES = ("ideal_open", "lossy_open", "viscous_lsd")
SPEED_PROFILES = {
    "local_fast": {"max_speed_mps": 2.5, "min_speed_mps": .2, "acceleration_mps2": 1.5,
                   "lateral_acceleration_limit_mps2": 3.5},
    "cautious": {"max_speed_mps": .35, "min_speed_mps": .14, "acceleration_mps2": .5},
    "brisk": {"max_speed_mps": .70, "min_speed_mps": .18, "acceleration_mps2": .8},
    "exploratory": {"max_speed_mps": 1.40, "min_speed_mps": .20, "acceleration_mps2": 1.0},
    "hardware_target": {"max_speed_mps": 5.5555555556, "min_speed_mps": .20, "acceleration_mps2": 1.5},
    # 라이다 주기 비교용 목표 속도 상한입니다. 20 km/h 실측 도달을 보장하지 않습니다.
    # 전방 거리·곡률 감속이 남아 있으며 실제 모터 가속도나 안전 속도도 아닙니다.
    "lidar_rate_stress": {"max_speed_mps": 5.5555555556, "min_speed_mps": .20, "acceleration_mps2": 4.0},
    # 입력 급상승 비교 이력을 재현하기 위해 보존합니다. 공식 코스 실측은 약 12~13 km/h였습니다.
    # 단일 모터 3 m/s^2 제한은 그대로입니다. 고정 20 km/h 검사는 별도 LiDAR lab을 씁니다.
    "lidar_20kmh_straight": {"max_speed_mps": 5.5555555556, "min_speed_mps": .20, "acceleration_mps2": 10.0},
}


def _dynamics_mappings(config, drive_mode="configured", differential="configured"):
    drive = config["drivetrain"]
    mode = drive["simulation_drive_mode"] if drive_mode == "configured" else drive_mode
    if mode not in {"single_motor", "legacy_velocity"}:
        raise ValueError("알 수 없는 구동 모드입니다.")
    diff = drive["mechanical_differential"]
    profile = diff["active_profile"] if differential == "configured" else differential
    if profile not in diff["profiles"]:
        raise ValueError("알 수 없는 차동 프로필입니다.")
    selected, motor, servo, tire = diff["profiles"][profile], drive["motor"], drive["steering_servo"], drive["tire_contact"]
    values = {
        "body_cg_z_offset": config["body"].get("center_of_mass_z_offset_m", 0),
        "gear_ratio": motor["gear_ratio"], "gear_efficiency": selected["gear_efficiency"],
        "motor_torque_limit": motor["torque_limit_nm"], "motor_brake_torque_limit": motor["brake_torque_limit_nm"],
        "motor_free_speed": motor["free_speed_rad_s"], "motor_response_time": motor["response_time_s"],
        "motor_speed_kp": motor["speed_kp"], "motor_speed_ki": motor["speed_ki"],
        "motor_acceleration": motor["acceleration_limit_mps2"], "motor_timeout": motor["command_timeout_s"],
        "carrier_drag": selected["carrier_drag_nm_per_rad_s"],
        "differential_viscosity": selected["coupling_nm_per_rad_s"],
        "differential_torque_limit": selected["coupling_limit_nm"],
        "servo_position_gain": servo["position_gain"], "servo_velocity_gain": servo["velocity_gain"],
        "servo_integral_gain": servo["integral_gain"],
        "servo_torque_limit": servo["torque_limit_nm"], "servo_rate_limit": servo["rate_limit_rad_s"],
        "tire_mu_lateral": tire["friction_lateral"], "tire_mu_longitudinal": tire["friction_longitudinal"],
        "tire_slip_lateral": tire["slip_compliance_lateral"],
        "tire_slip_longitudinal": tire["slip_compliance_longitudinal"],
        "tire_normal_force": tire["nominal_wheel_normal_force_n"],
        "wheel_damping": tire["joint_viscous_damping_nm_per_rad_s"],
        "rear_left_friction_scale": tire.get("rear_left_friction_scale", 1.0),
    }
    for name, value in values.items():
        if not math.isfinite(float(value)) or (name != "body_cg_z_offset" and float(value) < 0):
            raise ValueError(f"잘못된 구동 매개변수: {name}")
    if not 0 < float(values["gear_efficiency"]) <= 1:
        raise ValueError("기어 효율은 (0, 1] 범위여야 합니다.")
    return {"drive_mode": mode, **{key: str(value) for key, value in values.items()}}


def _as_bool(value: str) -> bool:
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _nominal_intrinsics(stream: dict) -> dict[str, float]:
    width = int(stream["width_px"])
    height = int(stream["height_px"])
    horizontal_fov = math.radians(float(stream["horizontal_fov_deg"]))
    vertical_fov = math.radians(float(stream["vertical_fov_deg"]))
    if width <= 0 or height <= 0 or not 0 < horizontal_fov < math.pi or not 0 < vertical_fov < math.pi:
        raise RuntimeError(f"Invalid D435i nominal stream geometry: {stream}")
    return {
        "horizontal_fov_rad": horizontal_fov,
        "fx_px": (width / 2.0) / math.tan(horizontal_fov / 2.0),
        "fy_px": (height / 2.0) / math.tan(vertical_fov / 2.0),
        # 실제 principal point와 RGB-깊이 외부 파라미터는 카메라 개체별 보정값으로 교체합니다.
        "cx_px": width / 2.0,
        "cy_px": height / 2.0,
    }


def _resolve_d435i_profile(config: dict, requested: str) -> tuple[str, dict]:
    name = config["active_stream_profile"] if requested == "configured" else requested
    if name not in config["stream_profiles"]:
        raise RuntimeError(f"d435i_profile must be one of {sorted(config['stream_profiles'])}")
    profile = config["stream_profiles"][name]
    color_rate = float(profile["color_rate_hz"])
    depth_rate = float(profile["depth_rate_hz"])
    if not math.isfinite(color_rate) or not math.isfinite(depth_rate) or min(color_rate, depth_rate) <= 0:
        raise RuntimeError("D435i stream rates must be finite and positive")
    if profile["hardware_sync_compatible"] and color_rate != depth_rate:
        raise RuntimeError("A hardware-sync-compatible D435i profile must use equal RGB and depth rates")
    return name, profile


def _resolve_tof_profile(config: dict, requested: str) -> tuple[str, dict]:
    name = config["active_profile"] if requested == "configured" else requested
    if name not in config["profiles"]:
        raise RuntimeError(f"tof_profile must be one of {sorted(config['profiles'])}")
    profile = config["profiles"][name]
    horizontal = profile["horizontal_zones"]
    vertical = profile["vertical_zones"]
    rate = float(profile["update_rate_hz"])
    if horizontal not in {4, 8} or vertical not in {4, 8}:
        raise RuntimeError("VL53L7CX ToF profile zones must be 4 or 8")
    if horizontal != vertical:
        raise RuntimeError("VL53L7CX ToF simulation requires a square zone grid")
    maximum_rate = 60.0 if horizontal == 4 else 15.0
    if not math.isfinite(rate) or not 0 < rate <= maximum_rate:
        raise RuntimeError(
            f"VL53L7CX {horizontal}x{vertical} profile rate must be in (0, {maximum_rate}] Hz"
        )
    return name, profile


def _resolve_lidar_rate(config: dict, requested: str) -> float:
    rate = float(config["scan_rate_hz"] if requested == "configured" else requested)
    if not math.isfinite(rate) or not .5 <= rate <= 100.0:
        raise RuntimeError("lidar_rate_hz는 configured 또는 0.5~100 Hz의 유한한 값이어야 합니다.")
    return rate


def _validate_tof_ring(config: dict, body: dict, layout_name: str | None = None) -> list[dict]:
    modules = config["modules"]
    if len(modules) != 6 or {module["name"] for module in modules} != TOF_MODULE_NAMES:
        raise RuntimeError(f"ToF ring requires these six module names: {sorted(TOF_MODULE_NAMES)}")
    for key in ("frame_id", "topic"):
        if len({module[key] for module in modules}) != len(modules):
            raise RuntimeError(f"ToF modules require unique {key} values")
    for key in ("horizontal_fov_deg", "vertical_fov_deg"):
        value = float(config[key])
        if not math.isfinite(value) or not 0 < value < 180:
            raise RuntimeError(f"Invalid ToF {key}: {value}")
    minimum, maximum = float(config["range_min_m"]), float(config["range_max_m"])
    if not math.isfinite(minimum) or not math.isfinite(maximum) or not 0 < minimum < maximum:
        raise RuntimeError("Invalid ToF range limits")
    half_length = float(body["length_m"]) / 2.0
    half_width = float(body["width_m"]) / 2.0
    by_name = {module["name"]: module for module in modules}
    for module in modules:
        xyz = [float(value) for value in module["xyz_m"]]
        rpy = [float(value) for value in module["rpy_rad"]]
        if len(xyz) != 3 or len(rpy) != 3 or not all(math.isfinite(value) for value in [*xyz, *rpy]):
            raise RuntimeError(f"Invalid ToF module pose: {module}")
        if abs(xyz[0]) > half_length or abs(xyz[1]) > half_width or xyz[2] <= 0:
            raise RuntimeError(f"ToF optical center is outside the vehicle envelope: {module['name']}")
    layouts = config.get("layouts", {})
    selected_layout = layout_name or config.get("active_layout")
    if selected_layout not in layouts:
        raise RuntimeError(f"ToF layout must be one of {sorted(layouts)}")
    names = layouts[selected_layout].get("modules", [])
    if not names or len(names) != len(set(names)) or any(name not in by_name for name in names):
        raise RuntimeError(f"Invalid ToF module list for layout {selected_layout}")
    selected = [by_name[name] for name in names]
    yaws = sorted(module["rpy_rad"][2] % (2.0 * math.pi) for module in selected)
    yaws.sort()
    gaps = [
        (yaws[(index + 1) % len(yaws)] - yaws[index]) % (2.0 * math.pi)
        for index in range(len(yaws))
    ]
    horizontal_fov = math.radians(float(config["horizontal_fov_deg"]))
    coverage = str(layouts[selected_layout].get("nominal_coverage", ""))
    if coverage.startswith("full_azimuth"):
        if max(gaps) > horizontal_fov + 1e-6:
            raise RuntimeError("Nominal ToF ring has an angular coverage gap")
    elif coverage == "front_camera_plus_both_side_arcs_rear_blind":
        expected = {"front_left", "rear_left", "rear_right", "front_right"}
        if set(names) != expected:
            raise RuntimeError("Stereo ToF layout must use two modules on each side")
        # +60/+120도와 -60/-120도의 60도 시야가 양쪽 정측면에서 맞닿습니다.
        actual = {module["name"]: module["rpy_rad"][2] % (2 * math.pi) for module in selected}
        for first, second in (("front_left", "rear_left"), ("rear_right", "front_right")):
            if abs((actual[second] - actual[first]) % (2 * math.pi) - horizontal_fov) > 1e-6:
                raise RuntimeError("Stereo ToF side arcs do not join at the side bearing")
    else:
        raise RuntimeError(f"Unknown ToF coverage declaration: {coverage}")
    return selected


def _batch_static_visuals(world, destination):
    """상자 꼭짓점/면/재질은 유지하고 정적 draw call만 묶는다. 충돌체 불변."""
    face_indices = ((0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4),
                    (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7))
    normals = ((0, 0, -1), (0, 0, 1), (0, -1, 0), (1, 0, 0), (0, 1, 0), (-1, 0, 0))
    total = 0
    for name in ("track_surface", "grass", "walls"):
        link = world.find(f"model[@name='it_arena_track_static']/link[@name='{name}']")
        if link is None:
            continue
        groups = {}
        for visual in link.findall("visual"):
            box, pose, material = visual.find("geometry/box/size"), visual.find("pose"), visual.find("material")
            if box is None or pose is None or material is None or pose.get("relative_to"):
                continue
            values = list(map(float, pose.text.split()))
            if len(values) != 6 or abs(values[3]) + abs(values[4]) > 1e-10:
                continue
            key = ET.tostring(material, encoding="unicode").strip()
            groups.setdefault(key, []).append((visual, values, list(map(float, box.text.split()))))
        for group_index, boxes in enumerate(groups.values()):
            if len(boxes) < 2:
                continue
            lines = ["# exact static box batching; collisions unchanged", "s off"]
            for index, (visual, pose, size) in enumerate(boxes):
                px, py, pz, _, _, yaw = pose
                c, s = math.cos(yaw), math.sin(yaw)
                sx, sy, sz = (v/2 for v in size)
                corners = ((-sx,-sy,-sz),(sx,-sy,-sz),(sx,sy,-sz),(-sx,sy,-sz),
                           (-sx,-sy,sz),(sx,-sy,sz),(sx,sy,sz),(-sx,sy,sz))
                for x, y, z in corners:
                    lines.append(f"v {px+c*x-s*y:.12g} {py+s*x+c*y:.12g} {pz+z:.12g}")
                for nx, ny, nz in normals:
                    lines.append(f"vn {c*nx-s*ny:.12g} {s*nx+c*ny:.12g} {nz}")
                for fi, face in enumerate(face_indices):
                    # 명시적 삼각형과 면 법선: 엔진의 자동 삼각화/평활화에 맡기지 않음.
                    for tri in ((face[0],face[1],face[2]), (face[0],face[2],face[3])):
                        lines.append("f " + " ".join(f"{8*index+v+1}//{6*index+fi+1}" for v in tri))
            path = destination.parent / f"batched_{name}_{group_index}.obj"
            path.write_text("\n".join(lines) + "\n", encoding="utf-8")
            merged = ET.SubElement(link, "visual", name=f"batched_{name}_{group_index}")
            geometry = ET.SubElement(merged, "geometry")
            ET.SubElement(ET.SubElement(geometry, "mesh"), "uri").text = str(path)
            merged.append(copy.deepcopy(boxes[0][0].find("material")))
            for visual, _, _ in boxes:
                link.remove(visual)
            total += len(boxes)
    return total


def _runtime_world_overrides(source, destination, detector, scene_broadcaster, speed_bump=True, batch_visuals=False):
    """형상·물성은 보존하고 선택형 런타임 설정만 사본에 적용합니다."""
    tree = ET.parse(source)
    world = tree.getroot().find("world")
    if not speed_bump:
        for parent in world.iter():
            for child in list(parent):
                if child.tag == "link" and child.get("name", "").startswith("safety_bump_"):
                    parent.remove(child)
    if detector != "configured":
        physics = world.find("physics")
        dart = physics.find("dart")
        if dart is None:
            dart = ET.SubElement(physics, "dart")
        field = dart.find("collision_detector")
        if field is None:
            field = ET.SubElement(dart, "collision_detector")
        field.text = detector
    if not scene_broadcaster:
        for plugin in list(world.findall("plugin")):
            if plugin.get("name") == "gz::sim::systems::SceneBroadcaster":
                world.remove(plugin)
    for tag in ("uri", "albedo_map", "normal_map", "roughness_map", "metalness_map", "environment_map", "emissive_map"):
        for value in world.findall(f".//{tag}"):
            if value.text and "://" not in value.text and not Path(value.text).is_absolute():
                value.text = str((source.parent / value.text).resolve())
    if batch_visuals:
        _batch_static_visuals(world, destination)
    tree.write(destination, encoding="utf-8", xml_declaration=True)


def _b0183_model(model_xml, profile):
    """레거시 카메라 링크를 RGB 모듈과 독립 6축 IMU로 교체한 실행 사본."""
    root = ET.fromstring(model_xml)
    model = root.find("model")
    camera = model.find("link[@name='d435i_link']")
    camera.set("name", "b0183_link")
    camera.find("sensor[@type='camera']").set("name", "b0183_rgb")
    camera.remove(camera.find("sensor[@type='imu']"))
    camera.find("inertial/mass").text = str(profile["camera"]["mass_kg"])
    camera.find("visual/geometry/box/size").text = " ".join(map(str, profile["camera"]["proxy_size_m"]))
    # 표시 형상에 맞춘 직육면체 관성. 모듈 질량/형상은 실측 전 가정.
    x, y, z = profile["camera"]["proxy_size_m"]
    mass = profile["camera"]["mass_kg"]
    for key, value in {"ixx": mass*(y*y+z*z)/12, "iyy": mass*(x*x+z*z)/12,
                       "izz": mass*(x*x+y*y)/12}.items():
        camera.find("inertial/inertia/" + key).text = str(value)
    joint = model.find("joint[@name='d435i_fixed_joint']")
    joint.set("name", "b0183_fixed_joint")
    joint.find("child").text = "b0183_link"
    imu = profile["imu"]
    link = ET.SubElement(model, "link", name="lsm6dsox_link")
    ET.SubElement(link, "pose").text = " ".join(map(str, [*imu["xyz_m"], 0, 0, 0]))
    inertial = ET.SubElement(link, "inertial")
    ET.SubElement(inertial, "mass").text = str(imu["mass_kg"])
    tensor = ET.SubElement(inertial, "inertia")
    for key in ("ixx", "iyy", "izz"):
        ET.SubElement(tensor, key).text = "0.0000001"
    sensor = ET.SubElement(link, "sensor", name="lsm6dsox_imu", type="imu")
    ET.SubElement(sensor, "topic").text = "/imu/data"
    ET.SubElement(sensor, "update_rate").text = str(imu["rate_hz"])
    ET.SubElement(sensor, "always_on").text = "true"
    settings = ET.SubElement(sensor, "imu")
    for kind, sigma in (("angular_velocity", imu["simulated_gyro_stddev_rad_s"]),
                        ("linear_acceleration", imu["simulated_accel_stddev_mps2"])):
        axes = ET.SubElement(settings, kind)
        for axis in ("x", "y", "z"):
            noise = ET.SubElement(ET.SubElement(axes, axis), "noise", type="gaussian")
            ET.SubElement(noise, "mean").text = "0"
            ET.SubElement(noise, "stddev").text = str(sigma)
    joint = ET.SubElement(model, "joint", name="lsm6dsox_fixed_joint", type="fixed")
    ET.SubElement(joint, "parent").text = "chassis"
    ET.SubElement(joint, "child").text = "lsm6dsox_link"
    return ET.tostring(root, encoding="unicode")


def _launch_setup(context):
    bringup_share = Path(get_package_share_directory("arena_bringup"))
    description_share = Path(get_package_share_directory("arena_description"))
    gazebo_share = Path(get_package_share_directory("arena_gazebo"))
    config_path = Path(LaunchConfiguration("vehicle_config").perform(context))
    with config_path.open("r", encoding="utf-8") as stream:
        config = yaml.safe_load(stream)["vehicle"]

    body = config["body"]
    drivetrain = config["drivetrain"]
    rear_marker = config["identification_marker"]
    rear_marker_xyz = [float(value) for value in rear_marker["xyz_m"]]
    rear_marker_rpy = [float(value) for value in rear_marker["rpy_rad"]]
    if (
        rear_marker["dictionary"] != "DICT_4X4_50"
        or int(rear_marker["id"]) != 10
        or not math.isclose(float(rear_marker["printed_board_size_m"]), .05, abs_tol=1e-9)
        or not math.isclose(
            float(rear_marker["black_code_size_m"])
            + 2 * float(rear_marker["quiet_zone_each_side_m"]),
            float(rear_marker["printed_board_size_m"]),
            abs_tol=1e-9,
        )
        or any(not math.isfinite(value) for value in [*rear_marker_xyz, *rear_marker_rpy])
        or not math.isclose(rear_marker_rpy[0], 0.0, abs_tol=1e-9)
        or not math.isclose(rear_marker_rpy[1], 0.0, abs_tol=1e-9)
    ):
        raise RuntimeError("현재 차량 형상은 5 cm DICT_4X4_50 ID 10 후면 마커 설정만 지원합니다.")
    d435i = config["sensors"]["d435i"]
    wheel_encoders = config["sensors"]["wheel_encoders"]
    autonomy_mode = LaunchConfiguration("autonomy_mode").perform(context)
    if autonomy_mode not in AUTONOMY_MODES:
        raise RuntimeError(f"autonomy_mode must be one of {AUTONOMY_MODES}")
    local_mode = autonomy_mode == "local_pursuit"
    profile = None
    if local_mode:
        profile = yaml.safe_load((description_share / "config/b0183_c1.yaml").read_text())
        camera = profile["camera"]
        d435i["xyz_m"], d435i["rpy_rad"] = camera["xyz_m"], camera["rpy_rad"]
        d435i["color"].update({key: camera[key] for key in ("width_px", "height_px", "horizontal_fov_deg")})
        d435i["color"]["vertical_fov_deg"] = math.degrees(2 * math.atan(
            math.tan(math.radians(camera["horizontal_fov_deg"])/2) * camera["height_px"]/camera["width_px"]))
        for stream in d435i["stream_profiles"].values():
            stream.update(color_rate_hz=camera["rate_hz"], depth_rate_hz=camera["rate_hz"])
        config["sensors"]["tof_ring"]["enabled"] = False
        config["sensors"]["lidar_2d"]["xyz_m"] = profile["lidar"]["xyz_m"]
        if LaunchConfiguration("lidar_compensation").perform(context) != "both":
            raise RuntimeError("새 구성은 lidar_compensation:=both로 실행하십시오.")
    tof_layout_name = SENSOR_LAYOUT_BY_MODE[autonomy_mode]
    drive_mappings = _dynamics_mappings(config, LaunchConfiguration("drive_mode").perform(context),
                                       LaunchConfiguration("differential_profile").perform(context))
    safety_enabled = local_mode or _as_bool(LaunchConfiguration("tof_safety").perform(context))
    sensor_wall_timeout = float(LaunchConfiguration("sensor_wall_timeout_s").perform(context))
    if not math.isfinite(sensor_wall_timeout) or not 3 <= sensor_wall_timeout <= 60:
        raise ValueError("sensor_wall_timeout_s must be finite and within 3..60")
    render_sensors = _as_bool(LaunchConfiguration("render_sensors").perform(context))
    if safety_enabled and not render_sensors:
        raise RuntimeError("광학 센서를 끈 동역학 전용 시험에서는 tof_safety:=false를 명시해야 합니다.")
    lidar = config["sensors"]["lidar_2d"]
    tof = config["sensors"]["tof_ring"]
    lidar_enabled = bool(lidar["enabled"] and autonomy_mode in {"lidar", "local_pursuit"})
    if lidar_enabled:
        if int(lidar["samples_per_scan"]) < 10 or not math.isclose(float(lidar["field_of_view_deg"]), 360.0):
            raise RuntimeError("기초 C1 모델은 360도 스캔과 10개 이상의 표본을 요구합니다.")
        if not 0 < float(lidar["range_min_m"]) < float(lidar["range_max_m"]) or float(lidar["scan_rate_hz"]) <= 0:
            raise RuntimeError("라이다 거리·주기 설정이 올바르지 않습니다.")
    lidar_rate_hz = _resolve_lidar_rate(
        lidar, LaunchConfiguration("lidar_rate_hz").perform(context)
    )
    d435i_xyz = d435i["xyz_m"]
    d435i_rpy = d435i["rpy_rad"]
    d435i_profile_name, d435i_profile = _resolve_d435i_profile(
        d435i, LaunchConfiguration("d435i_profile").perform(context)
    )
    tof_profile_name, tof_profile = _resolve_tof_profile(
        tof, LaunchConfiguration("tof_profile").perform(context)
    )
    active_tof_modules = _validate_tof_ring(tof, body, tof_layout_name) if tof["enabled"] else []
    # 두 인지 방식의 조향 성능만 비교할 때 센서 제거로 차량 질량까지 달라지면
    # 결과를 공정하게 해석할 수 없습니다. 빠진 C1과 ToF 캐리어 질량은 충돌체나
    # 시각 형상이 없는 중앙 차체 질량으로 보충합니다. 이는 실차 부품 배치가
    # 아니라 알고리즘 A/B 시험용 비교 ballast입니다.
    comparison_ballast_kg = (
        (0.0 if lidar_enabled else float(lidar["mass_kg"]))
        + (len(tof["modules"]) - len(active_tof_modules)) * float(tof["carrier_mass_kg"])
    )
    if local_mode:
        comparison_ballast_kg += .072 - profile["camera"]["mass_kg"] - profile["imu"]["mass_kg"]
    color = d435i["color"]
    depth = d435i["depth"]
    depth_enabled = not local_mode and _as_bool(LaunchConfiguration("depth_camera").perform(context))
    color_intrinsics = _nominal_intrinsics(color)
    depth_intrinsics = _nominal_intrinsics(depth)
    xacro_path = description_share / "models" / "arena_car" / "model.sdf.xacro"
    model_xml = xacro.process_file(
        str(xacro_path),
        mappings={
            **drive_mappings,
            "render_sensors": str(render_sensors).lower(),
            "body_length": str(body["length_m"]),
            "body_width": str(body["width_m"]),
            "body_height": str(body["height_m"]),
            "body_mass": str(float(body["mass_kg"]) + comparison_ballast_kg),
            "rear_marker_enabled": str(rear_marker["enabled"]).lower(),
            "rear_marker_x": str(rear_marker_xyz[0]),
            "rear_marker_y": str(rear_marker_xyz[1]),
            "rear_marker_z": str(rear_marker_xyz[2]),
            "rear_marker_yaw": str(rear_marker_rpy[2]),
            "rear_marker_board_size": str(rear_marker["printed_board_size_m"]),
            "rear_marker_code_size": str(rear_marker["black_code_size_m"]),
            "wheelbase": str(drivetrain["wheelbase_m"]),
            "track_width": str(drivetrain["track_width_m"]),
            "wheel_radius": str(drivetrain["wheel_radius_m"]),
            "wheel_width": str(drivetrain["wheel_width_m"]),
            "max_steering_angle": str(drivetrain["max_steering_angle_rad"]),
            "max_speed": str(drivetrain["max_speed_mps"]),
            "steering_p_gain": str(drivetrain.get("simulation_steering_p_gain", 12.0)),
            "acceleration_limit": str(drivetrain.get("simulation_acceleration_limit_mps2", 4.0)),
            "lidar_enabled": str(lidar_enabled).lower(),
            **{f"lidar_{axis}": str(value) for axis, value in zip(("x", "y", "z"), lidar["xyz_m"])},
            **{f"lidar_{axis}": str(value) for axis, value in zip(("roll", "pitch", "yaw"), lidar["rpy_rad"])},
            "lidar_rate": str(float(LaunchConfiguration("lidar_source_rate_hz").perform(context)) if LaunchConfiguration("lidar_acquisition").perform(context) != "snapshot" else lidar_rate_hz),
            "lidar_topic": "/sim/lidar_instantaneous" if LaunchConfiguration("lidar_acquisition").perform(context) != "snapshot" else "/scan",
            "lidar_samples": str(lidar["samples_per_scan"]),
            "lidar_min": str(lidar["range_min_m"]),
            "lidar_max": str(lidar["range_max_m"]),
            "lidar_resolution": str(lidar["nominal_range_resolution_m"]),
            "lidar_noise": str(lidar["simulated_noise_stddev_m"]),
            "lidar_mass": str(lidar["mass_kg"]),
            "lidar_radius": str(lidar["proxy_radius_m"]),
            "lidar_height": str(lidar["proxy_height_m"]),
            "tof_enabled": str(tof["enabled"]).lower(),
            "tof_rate": str(tof_profile["update_rate_hz"]),
            "tof_horizontal_zones": str(tof_profile["horizontal_zones"]),
            "tof_vertical_zones": str(tof_profile["vertical_zones"]),
            "tof_horizontal_fov": str(math.radians(float(tof["horizontal_fov_deg"]))),
            "tof_vertical_fov": str(math.radians(float(tof["vertical_fov_deg"]))),
            "tof_min": str(tof["range_min_m"]),
            "tof_max": str(tof["range_max_m"]),
            "tof_resolution": str(tof["nominal_depth_resolution_m"]),
            "tof_noise": str(tof["simulated_noise_stddev_m"]),
            "tof_carrier_size_x": str(tof["carrier_size_m"][0]),
            "tof_carrier_size_y": str(tof["carrier_size_m"][1]),
            "tof_carrier_size_z": str(tof["carrier_size_m"][2]),
            "tof_carrier_mass": str(tof["carrier_mass_kg"]),
            **{
                f"tof_{module['name']}_pose": " ".join(
                    str(value) for value in [*module["xyz_m"], *module["rpy_rad"]]
                )
                for module in tof["modules"]
            },
            **{f"tof_{module['name']}_topic": str(module["topic"]) for module in tof["modules"]},
            **{
                f"tof_{module['name']}_enabled": str(module in active_tof_modules).lower()
                for module in tof["modules"]
            },
            "d435i_x": str(d435i_xyz[0]),
            "d435i_y": str(d435i_xyz[1]),
            "d435i_z": str(d435i_xyz[2]),
            "d435i_roll": str(d435i_rpy[0]),
            "d435i_pitch": str(d435i_rpy[1]),
            "d435i_yaw": str(d435i_rpy[2]),
            "d435i_color_horizontal_fov": str(color_intrinsics["horizontal_fov_rad"]),
            "d435i_color_width": str(color["width_px"]),
            "d435i_color_height": str(color["height_px"]),
            "d435i_color_rate": str(d435i_profile["color_rate_hz"]),
            "d435i_color_near": str(color["render_near_clip_m"]),
            "d435i_color_far": str(color["render_far_clip_m"]),
            "d435i_color_fx": str(color_intrinsics["fx_px"]),
            "d435i_color_fy": str(color_intrinsics["fy_px"]),
            "d435i_color_cx": str(color_intrinsics["cx_px"]),
            "d435i_color_cy": str(color_intrinsics["cy_px"]),
            "d435i_depth_horizontal_fov": str(depth_intrinsics["horizontal_fov_rad"]),
            "d435i_depth_enabled": str(depth_enabled).lower(),
            "d435i_depth_width": str(depth["width_px"]),
            "d435i_depth_height": str(depth["height_px"]),
            "d435i_depth_rate": str(d435i_profile["depth_rate_hz"]),
            "d435i_depth_near": str(depth["minimum_depth_m"]),
            "d435i_depth_far": str(depth["simulation_far_clip_m"]),
            "d435i_depth_fx": str(depth_intrinsics["fx_px"]),
            "d435i_depth_fy": str(depth_intrinsics["fy_px"]),
            "d435i_depth_cx": str(depth_intrinsics["cx_px"]),
            "d435i_depth_cy": str(depth_intrinsics["cy_px"]),
            "d435i_imu_rate": str(d435i["imu"]["update_rate_hz"]),
            "chase_camera_enabled": str(_as_bool(LaunchConfiguration("chase_camera").perform(context))).lower(),
        },
    ).toxml()
    if local_mode:
        model_xml = _b0183_model(model_xml, profile)
    runtime_artifacts = LaunchConfiguration("runtime_artifacts").perform(context)
    if runtime_artifacts:
        evidence = Path(runtime_artifacts).resolve()
        evidence.mkdir(parents=True, exist_ok=True)
        (evidence / "runtime_vehicle.sdf").write_text(model_xml, encoding="utf-8")

    track = LaunchConfiguration("track").perform(context)
    if track not in TRACK_DIRECTORIES:
        raise RuntimeError(f"track must be one of {sorted(TRACK_DIRECTORIES)}")
    world_directory = gazebo_share / "worlds" / TRACK_DIRECTORIES[track]
    scene = json.loads((world_directory / "scene.json").read_text(encoding="utf-8"))
    slots = {int(slot["index"]): slot for slot in scene["starting_grid"]["slots"]}
    slot_index = int(LaunchConfiguration("grid_slot").perform(context))
    if slot_index not in slots:
        raise RuntimeError(f"grid_slot must be one of {sorted(slots)}")
    slot = slots[slot_index]
    spawn_x, spawn_y, spawn_yaw = slot["x"], slot["y"], slot["yaw_rad"]

    world_path = world_directory / "world.sdf"
    world_override = LaunchConfiguration("world_override").perform(context)
    if world_override:
        world_path = Path(world_override).resolve()
        if not world_path.is_file():
            raise RuntimeError(f"시험 월드를 찾을 수 없습니다: {world_path}")
        spawn_x = float(LaunchConfiguration("test_spawn_x").perform(context))
        spawn_y = float(LaunchConfiguration("test_spawn_y").perform(context))
        spawn_yaw = float(LaunchConfiguration("test_spawn_yaw").perform(context))
        if not all(math.isfinite(v) for v in (spawn_x, spawn_y, spawn_yaw)):
            raise ValueError("시험 시작 위치는 유한한 수여야 합니다.")
    headless = _as_bool(LaunchConfiguration("headless").perform(context))
    collision_detector = LaunchConfiguration("collision_detector").perform(context)
    scene_broadcaster = _as_bool(LaunchConfiguration("scene_broadcaster").perform(context))
    if not scene_broadcaster and not headless:
        raise RuntimeError("scene_broadcaster:=false는 headless:=true에서만 사용하십시오.")
    temporary_world = None
    speed_bump = _as_bool(LaunchConfiguration("speed_bump").perform(context))
    batch_visuals = _as_bool(LaunchConfiguration("batch_static_visuals").perform(context))
    if collision_detector != "configured" or not scene_broadcaster or not speed_bump or batch_visuals:
        temporary_world = tempfile.TemporaryDirectory(prefix="arena_world_")
        runtime_path = Path(temporary_world.name) / "world.sdf"
        _runtime_world_overrides(world_path, runtime_path, collision_detector, scene_broadcaster, speed_bump, batch_visuals)
        world_path = runtime_path
    if runtime_artifacts:
        (evidence / "runtime_world.sdf").write_bytes(world_path.read_bytes())
        for mesh in world_path.parent.glob("batched_*.obj"):
            (evidence / mesh.name).write_bytes(mesh.read_bytes())
    render_backend = LaunchConfiguration("render_backend").perform(context)
    render_env = {}
    if render_backend == "software":
        render_env = {"GALLIUM_DRIVER": "llvmpipe", "LIBGL_ALWAYS_SOFTWARE": "true"}
    elif render_backend == "wsl_nvidia" or (render_backend == "auto" and Path("/dev/dxg").exists()):
        # WSLg의 자동 선택이 llvmpipe로 떨어지는 환경에서 D3D12를 명시합니다.
        # auto는 사용자가 명시한 드라이버/소프트웨어 설정을 존중합니다.
        if render_backend == "wsl_nvidia" or not any(
            context.environment.get(key) for key in ("GALLIUM_DRIVER", "LIBGL_ALWAYS_SOFTWARE", "MESA_LOADER_DRIVER_OVERRIDE")
        ):
            render_env = {"GALLIUM_DRIVER": "d3d12", "LIBGL_ALWAYS_SOFTWARE": "false",
                          "MESA_D3D12_DEFAULT_ADAPTER_NAME": context.environment.get("MESA_D3D12_DEFAULT_ADAPTER_NAME", "NVIDIA")}
            library_dir = Path(get_package_prefix("arena_gazebo")) / "lib"
            library_name = "libarena-wsl-d3d12-lifetime.so"
            if not (library_dir / library_name).exists():
                raise RuntimeError("WSL GPU 지원 라이브러리가 없습니다. colcon build --symlink-install --packages-select arena_gazebo 실행 후 다시 시작하십시오.")
            # LD_PRELOAD는 공백도 구분자로 쓰므로 파일명과 검색 경로를 분리합니다.
            render_env["LD_LIBRARY_PATH"] = str(library_dir) + ":" + context.environment.get("LD_LIBRARY_PATH", "")
            render_env["LD_PRELOAD"] = library_name + (":" + context.environment["LD_PRELOAD"]
                                                       if context.environment.get("LD_PRELOAD") else "")
    # Keep the server and GUI as direct child processes. The upstream combined
    # launcher uses a shell wrapper, which can leave the actual Gazebo process
    # orphaned when ROS launch is interrupted.
    gazebo_server = ExecuteProcess(
        cmd=["gz", "sim", "-r", "-s", "-v", "3", *(["--headless-rendering"] if local_mode and headless else []), str(world_path)],
        additional_env=render_env,
        sigterm_timeout=LaunchConfiguration("gazebo_sigterm_timeout"),
        output="screen",
    )
    gazebo_gui = ExecuteProcess(
        cmd=["gz", "sim", "-g", "-v", "3"],
        additional_env=render_env,
        output="screen",
    )

    spawn_vehicle = Node(
        package="ros_gz_sim",
        executable="create",
        output="screen",
        arguments=[
            "-world",
            "it_arena_track",
            "-name",
            "arena_car",
            "-allow_renaming",
            "false",
            "-string",
            model_xml,
            "-x",
            str(spawn_x),
            "-y",
            str(spawn_y),
            "-z",
            "0.01",
            "-Y",
            str(spawn_yaw),
        ],
    )

    bridge = Node(
        package="ros_gz_bridge",
        executable="parameter_bridge",
        output="screen",
        arguments=[
            "/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock",
            "/model/arena_car/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist",
            "/model/arena_car/steer_angle@std_msgs/msg/Float64]gz.msgs.Double",
            "/model/arena_car/drivetrain@std_msgs/msg/String[gz.msgs.StringMsg",
            "/model/arena_car/odometry@nav_msgs/msg/Odometry@gz.msgs.Odometry",
            "/model/arena_car/tf@tf2_msgs/msg/TFMessage@gz.msgs.Pose_V",
            "/model/arena_car/joint_state@sensor_msgs/msg/JointState@gz.msgs.Model",
        ],
        remappings=[
            ("/model/arena_car/cmd_vel", "/sim/cmd_vel"),
            ("/model/arena_car/steer_angle", "/sim/steering_angle"),
            ("/model/arena_car/drivetrain", "/sim/drivetrain"),
            ("/model/arena_car/odometry", "/odom"),
            ("/model/arena_car/tf", "/tf"),
            ("/model/arena_car/joint_state", "/sim/joint_states_raw"),
        ],
    )

    sensor_bridge = Node(
        package="ros_gz_bridge",
        executable="parameter_bridge",
        name="d435i_sensor_bridge",
        output="screen",
        parameters=[{"config_file": str(bringup_share / "config" /
                                        ("b0183_imu_bridge.yaml" if local_mode else
                                         "d435i_sensor_bridge.yaml" if depth_enabled else "d435i_rgb_imu_bridge.yaml"))}],
    )

    # 대용량 포인트 클라우드가 RGB/깊이 영상 브리지를 지연시키지 않게 분리하고,
    # 실제 ROS 구독자가 있을 때만 ROS 변환·전송합니다. 토픽 이름은 유지합니다.
    pointcloud_bridge = Node(
        package="ros_gz_bridge",
        executable="parameter_bridge",
        name="d435i_pointcloud_bridge",
        output="screen",
        parameters=[{"config_file": str(bringup_share / "config" / "d435i_pointcloud_bridge.yaml")}],
    )

    vehicle_interface = Node(
        package="arena_vehicle_interface",
        executable="ackermann_to_twist",
        output="screen",
        remappings=[("/drive", "/drive/safe")] if safety_enabled else [],
        parameters=[
            {
                "wheelbase_m": float(drivetrain["wheelbase_m"]),
                "max_speed_mps": float(drivetrain["max_speed_mps"]),
                "max_steering_angle_rad": float(
                    drivetrain["max_steering_angle_rad"]
                ),
                "use_sim_time": True,
            }
        ],
    )

    actions = [
        LogInfo(msg=f"Collision detector: {collision_detector}; SceneBroadcaster: {scene_broadcaster}"),
        LogInfo(msg=f"Gazebo rendering request: {render_backend}; driver={render_env.get('GALLIUM_DRIVER', 'inherited')}; "
                    f"D3D12 lifetime guard={'LD_PRELOAD' in render_env}. Verify actual GL_RENDERER in Ogre2 log."),
        SetEnvironmentVariable("GZ_SIM_SYSTEM_PLUGIN_PATH", [
            str(Path(get_package_prefix("arena_gazebo")) / "lib"), ":",
            EnvironmentVariable("GZ_SIM_SYSTEM_PLUGIN_PATH", default_value="")]),
        LogInfo(msg=f"Drive: {drive_mappings['drive_mode']}; differential: "
                    f"{LaunchConfiguration('differential_profile').perform(context)}; "
                    f"safety={'LiDAR' if local_mode else 'ToF'} enabled={safety_enabled}. Motor/tire properties are provisional."),
        LogInfo(msg=f"Track: {track}; main width: {scene['track']['width_m']} m; "
                    f"shortcut widths: {[branch['width_m'] for branch in scene['branches']]} m. "
                    + ("Official v2026.09.14 track and complete gantry markers are preserved; "
                     "signal, bump profile and checker finish are team-test provisional."
                     if track == "official" else "Historical reproduction / experimental course.")),
        LogInfo(msg=f"Rear identification marker: enabled={rear_marker['enabled']}; "
                    f"{rear_marker['dictionary']} ID {rear_marker['id']}; "
                    f"board={rear_marker['printed_board_size_m']} m (team provisional)."),
        LogInfo(msg=f"Camera: {'B0183 + independent LSM6DSOX 208 Hz' if local_mode else 'D435i ' + d435i_profile_name}; "
                    f"RGB {color['width_px']}x{color['height_px']} @ "
                    f"{d435i_profile['color_rate_hz']} Hz; depth "
                    f"{depth['width_px']}x{depth['height_px']} @ "
                    f"{d435i_profile['depth_rate_hz']} Hz (enabled={depth_enabled})."),
        LogInfo(msg=f"Sensor mode: {autonomy_mode}; ToF layout={tof_layout_name} "
                    f"(mount provisional); speed_bump={speed_bump}; batch_visuals={batch_visuals}; comparison ballast="
                    f"{comparison_ballast_kg:.3f} kg."),
        LogInfo(msg=f"ToF ring: enabled={tof['enabled']}; profile={tof_profile_name}; "
                    f"{tof_profile['horizontal_zones']}x{tof_profile['vertical_zones']} @ "
                    f"{tof_profile['update_rate_hz']} Hz; "
                    f"modules={[module['name'] for module in active_tof_modules]}."),
        LogInfo(msg=f"2D LiDAR: enabled={lidar_enabled}; {lidar_rate_hz:g} Hz, "
                    f"{lidar['samples_per_scan']} samples/scan. "
                    f"acquisition={LaunchConfiguration('lidar_acquisition').perform(context)}; source={LaunchConfiguration('lidar_source_rate_hz').perform(context)} Hz; capture quantization <=2.1 ms; raw scan uncorrected, controller compensation={LaunchConfiguration('lidar_compensation').perform(context)}."),
        gazebo_server,
        bridge,
        sensor_bridge,
        vehicle_interface,
        TimerAction(period=2.0, actions=[spawn_vehicle]),
    ]
    if not render_sensors:
        actions.remove(sensor_bridge)
    if depth_enabled and render_sensors:
        actions.append(pointcloud_bridge)
    if temporary_world is not None:
        def cleanup_world(context, *args, **kwargs):
            temporary_world.cleanup()
            return []
        actions.append(RegisterEventHandler(OnShutdown(on_shutdown=[OpaqueFunction(function=cleanup_world)])))
    if not headless:
        actions.append(gazebo_gui)

    if safety_enabled and not local_mode:
        if not active_tof_modules or not wheel_encoders["enabled"]:
            raise RuntimeError("ToF 안전층은 ToF 링과 좌우 바퀴 엔코더가 필요합니다.")
        actions.append(Node(package="arena_autonomy", executable="tof_safety", output="screen",
                            parameters=[str(bringup_share / "config/tof_safety.yaml"),
                                        {"use_sim_time": True, "vehicle_config": str(config_path),
                                         "sensor_wall_timeout_s": sensor_wall_timeout,
                                         "active_modules": [module["name"] for module in active_tof_modules]}]))

    if lidar_enabled and render_sensors:
        sequential = LaunchConfiguration("lidar_acquisition").perform(context) != "snapshot"
        lidar_topic = "/sim/lidar_instantaneous" if sequential else "/scan"
        if sequential:
            actions.append(Node(package="arena_vehicle_interface", executable="rotating_lidar",
                                parameters=[{"use_sim_time": True, "rotation_rate_hz": lidar_rate_hz,
                                             "samples_per_scan": int(lidar["samples_per_scan"]),
                                             "acquisition": LaunchConfiguration("lidar_acquisition").perform(context)}],
                                output="screen"))
        actions.extend([
            Node(package="ros_gz_bridge", executable="parameter_bridge", name="lidar_bridge",
                 arguments=[f"{lidar_topic}@sensor_msgs/msg/LaserScan[gz.msgs.LaserScan"],
                 parameters=[{"override_frame_id": str(lidar["frame_id"])}], output="screen"),
            Node(package="tf2_ros", executable="static_transform_publisher", name="lidar_transform",
                 arguments=["--x", str(lidar["xyz_m"][0]), "--y", str(lidar["xyz_m"][1]),
                            "--z", str(lidar["xyz_m"][2]), "--roll", str(lidar["rpy_rad"][0]),
                            "--pitch", str(lidar["rpy_rad"][1]), "--yaw", str(lidar["rpy_rad"][2]),
                            "--frame-id", "base_link", "--child-frame-id", str(lidar["frame_id"])],
                 parameters=[{"use_sim_time": True}], output="screen"),
        ])

    if tof["enabled"] and render_sensors:
        for module in active_tof_modules:
            name = str(module["name"])
            topic = str(module["topic"])
            xyz = module["xyz_m"]
            rpy = module["rpy_rad"]
            actions.extend([
                Node(
                    package="ros_gz_bridge",
                    executable="parameter_bridge",
                    name=f"tof_{name}_pointcloud_bridge",
                    arguments=[
                        f"{topic}/points@sensor_msgs/msg/PointCloud2[gz.msgs.PointCloudPacked"
                    ],
                    parameters=[{"override_frame_id": str(module["frame_id"])}],
                    output="screen",
                ),
                Node(
                    package="tf2_ros",
                    executable="static_transform_publisher",
                    name=f"tof_{name}_transform",
                    arguments=[
                        "--x", str(xyz[0]), "--y", str(xyz[1]), "--z", str(xyz[2]),
                        "--roll", str(rpy[0]), "--pitch", str(rpy[1]), "--yaw", str(rpy[2]),
                        "--frame-id", "base_link", "--child-frame-id", str(module["frame_id"]),
                    ],
                    parameters=[{"use_sim_time": True}],
                    output="screen",
                ),
            ])

    chase_camera = _as_bool(LaunchConfiguration("chase_camera").perform(context))
    if chase_camera and render_sensors:
        actions.append(Node(
            package="ros_gz_bridge",
            executable="parameter_bridge",
            name="chase_camera_bridge",
            arguments=["/sim/chase/image@sensor_msgs/msg/Image[gz.msgs.Image"],
            output="screen",
        ))

    autonomy = _as_bool(LaunchConfiguration("autonomy").perform(context))
    traffic = _as_bool(LaunchConfiguration("traffic_light").perform(context))
    if (autonomy or traffic) and (world_override or not render_sensors):
        raise RuntimeError("시험 월드/광학 센서 비활성화는 본선 자율주행·신호등과 함께 쓰지 않습니다.")
    if (autonomy or traffic) and track not in {"official", "experimental"}:
        raise RuntimeError("신호등·본선 벽 추종 데모는 official/experimental 지도에서만 지원합니다.")
    if autonomy and autonomy_mode in {"lidar", "local_pursuit"} and not lidar_enabled:
        raise RuntimeError("LiDAR 벽 추종에는 lidar_2d.enabled=true가 필요합니다.")
    if autonomy and autonomy_mode == "stereo" and not depth_enabled:
        raise RuntimeError("스테레오 벽 추종에는 depth_camera:=true가 필요합니다.")
    if traffic:
        actions.append(Node(package="arena_gazebo", executable="traffic_light_controller.py",
                            parameters=[{"use_sim_time": True,
                                         "red_duration_s": float(LaunchConfiguration("red_duration_s").perform(context)),
                                         "yellow_duration_s": 2.0}], output="screen"))
    if local_mode:
        if not lidar_enabled or not wheel_encoders["enabled"]:
            raise RuntimeError("새 보호층은 C1과 후륜 엔코더가 필요합니다.")
        equivalent_steering = math.atan(float(drivetrain["wheelbase_m"]) /
            (float(drivetrain["wheelbase_m"])/math.tan(float(drivetrain["max_steering_angle_rad"])) + float(drivetrain["track_width_m"])/2))
        actions.append(Node(package="arena_autonomy", executable="lidar_safety", parameters=[{
            "use_sim_time": True, "lidar_compensation": "both", "motion_scan_timing_verified": True,
            "motion_wheel_radius_m": float(drivetrain["wheel_radius_m"]),
            "motion_rear_axle_x_m": -float(drivetrain["wheelbase_m"])/2,
            "motion_lidar_x_m": float(lidar["xyz_m"][0]), "motion_lidar_y_m": float(lidar["xyz_m"][1]),
            "motion_lidar_yaw_rad": float(lidar["rpy_rad"][2]), "motion_imu_topic": "/imu/data",
            "sensor_wall_timeout_s": sensor_wall_timeout, "max_steering_angle_rad": equivalent_steering,
            "wheelbase_m": float(drivetrain["wheelbase_m"]),
            "vehicle_length_m": float(config['footprint']['length_m']),
            "vehicle_width_m": float(config['footprint']['width_m']),
            "rear_blind_half_angle_deg": float(profile['lidar']['masked_rear_half_angle_deg']),
        }], output="screen"))
    if autonomy:
        speed_profile = SPEED_PROFILES[LaunchConfiguration("speed_profile").perform(context)]
        control_rate = float(LaunchConfiguration("autonomy_control_rate_hz").perform(context))
        if not math.isfinite(control_rate) or not 5 <= control_rate <= 200:
            raise ValueError("autonomy_control_rate_hz must be finite and within 5..200")
        executable = "local_pursuit" if local_mode else "wall_follow" if autonomy_mode == "lidar" else "stereo_wall_follow"
        controller_parameters = {
            "use_sim_time": True,
            **speed_profile,
            "control_rate_hz": control_rate,
            "wheelbase_m": float(drivetrain["wheelbase_m"]),
            "max_steering_angle_rad": float(drivetrain["max_steering_angle_rad"]),
        }
        if autonomy_mode in {"lidar", "local_pursuit"}:
            controller_parameters["lidar_x_m"] = float(lidar["xyz_m"][0])
            controller_parameters.update(
                lidar_compensation=LaunchConfiguration("lidar_compensation").perform(context),
                motion_scan_timing_verified=True,  # 이 launch의 시뮬레이션 어댑터에 한정
                motion_wheel_radius_m=float(drivetrain["wheel_radius_m"]),
                motion_rear_axle_x_m=-float(drivetrain["wheelbase_m"]) / 2,
                motion_lidar_x_m=float(lidar["xyz_m"][0]),
                motion_lidar_y_m=float(lidar["xyz_m"][1]),
                motion_lidar_yaw_rad=float(lidar["rpy_rad"][2]),
                motion_imu_roll_rad=float(d435i["rpy_rad"][0]),
                motion_imu_pitch_rad=float(d435i["rpy_rad"][1]),
                sensor_wall_timeout_s=sensor_wall_timeout,
            )
            if local_mode:
                controller_parameters["motion_imu_topic"] = "/imu/data"
                # 새 IMU는 카메라와 독립이며 현재 차체 축과 나란히 고정한다.
                controller_parameters['motion_imu_roll_rad'] = 0.
                controller_parameters['motion_imu_pitch_rad'] = 0.
                controller_parameters['rear_blind_half_angle_deg'] = float(profile['lidar']['masked_rear_half_angle_deg'])
                # 안쪽 조향 바퀴 0.45 rad 제한을 후륜축 자전거 등가각으로 환산.
                controller_parameters["max_steering_angle_rad"] = equivalent_steering
        else:
            controller_parameters.update(
                camera_x_m=float(d435i_xyz[0]),
                camera_y_m=float(d435i_xyz[1]),
                camera_z_m=float(d435i_xyz[2]),
                color_fx_px=float(color_intrinsics["fx_px"]),
                color_fy_px=float(color_intrinsics["fy_px"]),
                color_cx_px=float(color_intrinsics["cx_px"]),
                color_cy_px=float(color_intrinsics["cy_px"]),
            )
        actions.append(Node(package="arena_autonomy", executable=executable,
                            parameters=[str(bringup_share / "config" / "wall_follow.yaml"),
                                        controller_parameters],
                            output="screen"))

    if wheel_encoders["enabled"]:
        actions.append(
            Node(
                package="arena_vehicle_interface",
                executable="sim_wheel_encoder",
                output="screen",
                parameters=[
                    {
                        "left_joint_name": wheel_encoders["left_joint_name"],
                        "right_joint_name": wheel_encoders["right_joint_name"],
                        "ticks_per_revolution": int(
                            wheel_encoders["ticks_per_revolution"]
                        ),
                        "sample_rate_hz": float(wheel_encoders["sample_rate_hz"]),
                        "latency_ms": float(wheel_encoders["latency_ms"]),
                        "dropout_probability": float(
                            wheel_encoders["dropout_probability"]
                        ),
                        "use_sim_time": True,
                    }
                ],
            )
        )

    return actions


def generate_launch_description() -> LaunchDescription:
    description_share = Path(get_package_share_directory("arena_description"))
    return LaunchDescription(
        [
            DeclareLaunchArgument("lidar_compensation", default_value="none", choices=["none", "deskew", "shift", "both"]),
            DeclareLaunchArgument("autonomy_control_rate_hz", default_value="20.0", description="자율주행 제어 주기; 센서 주기와 독립"),
            DeclareLaunchArgument("sensor_wall_timeout_s", default_value="3.0", description="오프라인 감시 벽시계 한도. 센서의 시뮬레이션 시각 제한은 유지"),
            # 이번 launch의 ROS 하위 프로세스에만 적용합니다. 별도 수신 터미널도
            # 같은 모드를 사용해야 하며, 기존 사용자 지정 환경변수는 덮어쓰지 않습니다.
            SetEnvironmentVariable(
                "FASTDDS_BUILTIN_TRANSPORTS",
                EnvironmentVariable("FASTDDS_BUILTIN_TRANSPORTS", default_value="LARGE_DATA"),
            ),
            DeclareLaunchArgument(
                "track",
                default_value="official",
                choices=list(TRACK_DIRECTORIES),
                description="official: v2026.09.14 45/20 cm unchanged gantry markers; experimental: legacy 45/25 cm test; original: preserved 35/12 cm.",
            ),
            DeclareLaunchArgument(
                "vehicle_config",
                default_value=str(description_share / "config" / "vehicle.yaml"),
                description="Vehicle parameter YAML file.",
            ),
            DeclareLaunchArgument(
                "d435i_profile",
                default_value="configured",
                choices=["configured", *D435I_STREAM_PROFILES],
                description="D435i stream profile. configured follows active_stream_profile in vehicle_config.",
            ),
            DeclareLaunchArgument(
                "tof_profile",
                default_value="configured",
                choices=["configured", *TOF_PROFILES],
                description="ToF zone/rate profile. configured follows active_profile in vehicle_config.",
            ),
            DeclareLaunchArgument(
                "lidar_rate_hz",
                default_value="configured",
                description="configured 또는 시험용 0.5~100 Hz. C1 하드웨어 사양을 바꾸는 설정이 아닙니다.",
            ),
            DeclareLaunchArgument(
                "grid_slot",
                default_value="0",
                description="Starting grid slot index (0-5).",
            ),
            DeclareLaunchArgument(
                "headless",
                default_value="false",
                description="Run the Gazebo server without its GUI.",
            ),
            DeclareLaunchArgument("lidar_acquisition", default_value="snapshot", choices=["snapshot", "snapshot_matched", "sequential"],
                                  description="순간 스캔 또는 물리 프레임 누적 회전 스캔"),
            DeclareLaunchArgument("render_backend", default_value="system", choices=["auto", "system", "wsl_nvidia", "software"],
                                  description="auto: WSL GPU 연결 시 D3D12 선택, system: 기존 환경, software: CPU 비교"),
            DeclareLaunchArgument("collision_detector", default_value="configured", choices=["configured", "ode", "bullet", "fcl"],
                                  description="DART 충돌 검출만 선택하는 비교 옵션. 기본 물성/형상 유지"),
            DeclareLaunchArgument("scene_broadcaster", default_value="true", description="false는 GUI·정답 pose 발행이 필요 없는 headless 검사 전용"),
            DeclareLaunchArgument("gazebo_sigterm_timeout", default_value="5", description="종료 진단용 SIGINT 대기 초. 기본 ROS launch와 같은 5초"),
            DeclareLaunchArgument("lidar_source_rate_hz", default_value="500", choices=["500", "1000"],
                                  description="순차 취득의 내부 광선 계산 주기; C1 회전 주기 아님"),
            DeclareLaunchArgument("autonomy", default_value="false", description="RGB 출발 신호 + 선택한 센서의 본선 벽 추종"),
            DeclareLaunchArgument(
                "autonomy_mode", default_value="lidar", choices=list(AUTONOMY_MODES),
                description="lidar: C1+ToF6, stereo: 전방 D435i 깊이+측면 ToF4 개인 비교안",
            ),
            DeclareLaunchArgument("render_sensors", default_value="true", description="동역학 전용 시험에서 광학 센서만 끕니다. 링크·질량은 유지합니다."),
            DeclareLaunchArgument("world_override", default_value="", description="시험 전용 SDF. 원본/실험 트랙 파일은 덮어쓰지 않습니다."),
            DeclareLaunchArgument("test_spawn_x", default_value="0"),
            DeclareLaunchArgument("test_spawn_y", default_value="0"),
            DeclareLaunchArgument("test_spawn_yaw", default_value="0"),
            DeclareLaunchArgument("drive_mode", default_value="configured", choices=["configured", "single_motor", "legacy_velocity"]),
            DeclareLaunchArgument("differential_profile", default_value="configured", choices=["configured", *DIFFERENTIAL_PROFILES]),
            DeclareLaunchArgument("tof_safety", default_value="true", description="/drive를 ToF 안전층에서 제한하여 /drive/safe로 전달"),
            DeclareLaunchArgument("speed_profile", default_value="cautious", choices=list(SPEED_PROFILES),
                                  description="명령 속도 상한이며 실제 속도/완주 보증이 아닙니다. ToF 안전층이 추가 제한합니다."),
            DeclareLaunchArgument("depth_camera", default_value="true", description="깊이 센서와 점군을 켭니다. RGB·IMU는 유지합니다."),
            DeclareLaunchArgument("speed_bump", default_value="true", description="false는 실행 사본에서만 임시 방지턱 제거"),
            DeclareLaunchArgument("runtime_artifacts", default_value="", description="검증 실행 입력 보관 폴더"),
            DeclareLaunchArgument("batch_static_visuals", default_value="false", description="정적 상자 표시만 동일 꼭짓점/재질의 메시로 묶음; 충돌체 불변"),
            DeclareLaunchArgument("chase_camera", default_value="false", description="영상 검증 전용 차량 추적 3인칭 카메라"),
            DeclareLaunchArgument("traffic_light", default_value="false", description="빨강-노랑-초록 출발 신호와 수동 제어"),
            DeclareLaunchArgument("red_duration_s", default_value="8.0", description="영상 준비 이후 빨간 신호 유지 시간"),
            OpaqueFunction(function=_launch_setup),
        ]
    )
