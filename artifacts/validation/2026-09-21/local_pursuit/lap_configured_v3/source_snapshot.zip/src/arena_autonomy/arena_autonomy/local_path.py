"""관측 벽의 지역 평행 경로 + 후륜축 Pure Pursuit. 지도/정답 위치 불사용."""
import copy
import math

import numpy as np


def mask_scan(scan, rear_half_angle_deg=30.):
    """후방 60도는 장착 미확정 사각으로 취급. 빈 공간으로 채우지 않는다."""
    result = copy.deepcopy(scan)
    angles = scan.angle_min + np.arange(len(scan.ranges)) * scan.angle_increment
    ranges = np.asarray(scan.ranges, dtype=float).copy()
    ranges[np.abs(angles) > math.radians(180 - rear_half_angle_deg)] = np.nan
    result.ranges = ranges.tolist()
    return result


def local_path(points, side, offset=.425, horizon=.85):
    sign = 1 if side == "left" else -1
    points = np.asarray(points, dtype=float)
    x, y = points[:, 0], sign * points[:, 1]
    keep = np.isfinite(x) & np.isfinite(y) & (x > -.12) & (x < horizon) & (y > .10) & (y < 1.1)
    x, y = x[keep], y[keep]
    if len(x) < 12 or np.ptp(x) < .22:
        return None, {"reason": "wall_lost"}
    for _ in range(3):
        coef = np.polynomial.polynomial.polyfit(x, y, 2)
        errors = np.abs(y - np.polynomial.polynomial.polyval(x, coef))
        keep = errors < max(.025, 3 * float(np.median(errors)))
        if np.all(keep) or np.count_nonzero(keep) < 12 or np.ptp(x[keep]) < .22:
            break
        x, y = x[keep], y[keep]
    # 마지막 이상점 제거 뒤 남은 표본으로 다시 적합한다.
    coef = np.polynomial.polynomial.polyfit(x, y, 2)
    residual = float(np.sqrt(np.mean((y - np.polynomial.polynomial.polyval(x, coef)) ** 2)))
    if residual > .075:
        return None, {"reason": "wall_fit_uncertain", "fit_residual_m": residual}
    # 관측 범위 밖으로 외삽하지 않고 벽의 법선 방향으로 경로를 띄운다.
    wx = np.linspace(max(-.08, float(x.min())), float(x.max()), 36)
    wy = np.polynomial.polynomial.polyval(wx, coef)
    slope = coef[1] + 2 * coef[2] * wx
    norm = np.sqrt(1 + slope ** 2)
    path = np.column_stack((wx + offset * slope / norm, sign * (wy - offset / norm)))
    return path, {"reason": "local_path", "fit_samples": len(x), "fit_residual_m": residual,
                  "wall_distance_m": float(coef[0]), "path_points": path.tolist()}


def pursuit_command(points, side, speed, wheelbase=.145, max_steering=.37,
                    max_speed=2.0, lateral_acceleration=3.5, offset=.425):
    path, details = local_path(points, side, offset)
    details.update(preferred_wall=side, path_wall=side, wall_fallback=False)
    if path is None:
        # 급커브 안쪽 벽은 차량 전방에서 y=f(x)가 아니거나 관측이 짧다.
        # 반대쪽의 관측 경로가 유효할 때만 대체한다. 지도/미관측 경로 외삽은 하지 않는다.
        opposite = 'right' if side == 'left' else 'left'
        alternate, alternate_details = local_path(points, opposite, offset)
        if alternate is not None:
            path = alternate
            details = {**alternate_details, 'preferred_wall': side, 'path_wall': opposite,
                       'wall_fallback': True, 'preferred_wall_failure': details['reason']}
    if path is None:
        return 0., 0., details
    # 모델 원점은 양 축 중간. Pure Pursuit 원점은 후륜축이다.
    rear = path.copy()
    rear[:, 0] += wheelbase / 2
    distances = np.linalg.norm(rear, axis=1)
    ahead = np.flatnonzero(rear[:, 0] > .10)
    if len(ahead) < 3:
        return 0., 0., {**details, "reason": "path_too_short"}
    lookahead = min(.60, max(.30, .30 + .12 * abs(speed)))
    index = int(ahead[np.argmin(np.abs(distances[ahead] - lookahead))])
    target = rear[index]
    curvature = float(2 * target[1] / max(.01, target @ target))
    steering = float(np.clip(math.atan(wheelbase * curvature), -max_steering, max_steering))
    target_speed = min(max_speed, math.sqrt(lateral_acceleration / max(.15, abs(curvature))))
    if details['wall_fallback']:
        target_speed = min(target_speed, 1.2)  # 경로 기준 변경 중에는 보수적으로 재관측
    return target_speed, steering, {**details, "lookahead_m": float(distances[index]),
                                   "target_xy_rear_m": target.tolist(), "curvature_m_inv": curvature}


def swept_limit(points, steering, wheelbase=.145, horizon=3., margin=.025, length=.20, width=.15):
    """정곡률 예측 차체와 점군의 첫 간섭까지 후륜축 이동 거리를 계산한다."""
    points = np.asarray(points, dtype=float)
    curvature = math.tan(steering) / wheelbase
    for distance in np.arange(0., horizon + .001, .04):
        yaw = curvature * distance
        if abs(curvature) < 1e-5:
            rx, ry = distance - wheelbase / 2, 0.
        else:
            rx, ry = math.sin(yaw) / curvature - wheelbase / 2, (1 - math.cos(yaw)) / curvature
        dx, dy = points[:, 0] - rx, points[:, 1] - ry
        local_x = math.cos(yaw) * dx + math.sin(yaw) * dy - wheelbase / 2
        local_y = -math.sin(yaw) * dx + math.cos(yaw) * dy
        if np.any((np.abs(local_x) <= length/2 + margin) & (np.abs(local_y) <= width/2 + margin)):
            return max(0., float(distance) - .04)  # 이산 검사 간격을 안전 여유로 차감
    return horizon


def braking_speed(clearance, age, deceleration=2.0):
    reaction = max(0., age) + .10
    distance = max(0., clearance - .06)
    return max(0., -deceleration * reaction + math.sqrt((deceleration * reaction) ** 2 + 2 * deceleration * distance))
