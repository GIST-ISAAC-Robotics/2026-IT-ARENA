# 공식 ZIP 원본부터 다시 확인한 Gazebo 로드 감사

확인일: 2026-08-31. **원본 로드 실패·첫 물리 갱신 지연·마커 렌더링 실패를 분리해 재현했습니다. 이슈·댓글·push는 하지 않았습니다.**

기존 검토는 기하·시설에 비중을 두었고, 재질 문제도 `gz sdf -k` 결과를 중심으로 설명했습니다. 이번에는 사용자의 요청대로 배포 ZIP을 새 폴더에 풀어 실제 `gz sim world.sdf`부터 실행했습니다. 팀 파생 월드의 완주 성공을 원본 로드 성공으로 대신하지 않습니다.

## 결론과 초안 우선순위

| 우선순위 | 확인한 문제 | 이슈 초안 |
|---|---|---|
| 1 — 시작 차단 | 불완전한 ArUco `script`의 필수 `name` 누락. 실제 Gazebo에서 월드 전체 파싱 실패 | [03 원본 월드 로드 실패](issues/official-v2026.08.31/03-aruco-sdf-material.md) — 기존 초안을 실제 실행 근거로 재작성 |
| 2 — 실행 준비 지연 | 파싱을 통과해도 링크 1,113개 상태에서는 첫 물리 갱신 1회가 180초 내 미완료. 동일 형상을 링크 10개로 병합하면 약 2.9초 | [08 첫 물리 갱신 지연](issues/official-v2026.08.31/08-static-link-startup-delay.md) — 신규 |
| 3 — 인지 입력 실패 | albedo 상대경로 오류. 경로 수정 후에도 `diffuse` 기본 검정으로 네 마커가 검게 표시됨. 흰색 한 항목 추가 후 4/4 검출 | [09 ArUco 텍스처·재질](issues/official-v2026.08.31/09-aruco-texture-rendering.md) — 기존 03의 경로 문제를 옮기고 실제 렌더링 원인을 추가 |

기존 마커 간섭·방지턱 축·신호등 방향·출발 기준·그리드 간격/높이의 여섯 건도 유지합니다. 따라서 **초안은 총 9건**이며 번호는 과거 검토와의 대응을 위해 유지합니다. 위 3건을 먼저 검토하는 순서입니다. [전체 현황과 승인 상태](OFFICIAL_UPSTREAM_ISSUE_DRAFTS.md)

## 1. 무엇을 원본으로 실행했는가

- [공식 릴리스 `v2026.08.31`](https://github.com/MOSW626/istech-it-arena/releases/tag/v2026.08.31), 커밋 `d61c5db9252cedfbc163cd044a47671df91e1660`. 이번에도 `main`이 같은 커밋임을 읽기 전용으로 확인했습니다.
- 보존 ZIP: `assets/track/official/v2026.08.31/it_arena_track_v2026.08.31.zip`, 746,603 bytes, 파일 23개.
- ZIP SHA-256: `897183d2e2541458d190a0a1e3f76bff754c67fab894f2302c3110830a86149b`.
- ZIP의 `output_final/world.sdf` SHA-256: `62d7ae4abf2dbcc0ce850065de5ade28703a67649ab6a8c62311c432cc2200de`.
- 새 작업 폴더: `build/official_load_audit_20260831/`. `raw` 사본의 23개 파일은 ZIP 바이트 그대로입니다. Windows Git의 CRLF 변환본도 사용하지 않았습니다.
- 이 문서에서 **원본**은 ZIP의 `world.sdf`입니다. 팀 launch의 `track:=original`도 이미 호환성 변환을 거친 구버전 재현본이므로, 무수정 원본 시험과 같지 않습니다.
- 초기 7월 ZIP, 새 공식 ZIP, 기존 운영 월드, 차량 설정과 과거 활동 기록은 수정하지 않았습니다.

환경은 WSL Ubuntu 24.04.4 LTS·ROS 2 Jazzy·Gazebo Sim 8.11.0·libsdformat 14.9.0입니다. 기본 서버 설정은 `Physics`·`UserCommands`·`SceneBroadcaster` 3개이며 실제 물리는 DART입니다. 새 센서 플러그인을 넣지 않아도 정적 트랙의 기본 시스템은 로드됐습니다. `GZ_SIM_RESOURCE_PATH=/opt/ros/jazzy/share`였고 팀 실행 월드의 경로는 주입하지 않았습니다.

## 2. 한 번에 한 원인을 바꾼 비교

각 시험은 별도 `GZ_PARTITION`을 사용하고, 해당 시험의 새 프로세스 그룹만 종료했습니다. 사용자가 보던 기존 공식 트랙 GUI·서버는 그대로 유지했습니다.

| 사본 | 변경 | 엄격 SDF 검사 | 서버의 첫 갱신 1회 |
|---|---|---|---|
| `raw` | 없음 | Code 8 ×4, Code 9 ×1 | Code 14 ×4, Code 8 ×4, Code 9 ×1; 파싱 실패 |
| `paths_only` | URI 8곳의 `../aruco/`만 `aruco/`로 수정 | Code 8 ×4, Code 9 ×1 | URI 오류는 사라져도 Code 8/9로 파싱 실패 |
| `remove_script` | 불완전한 `script` 4개만 제거 | 통과 | 45초 내 미완료. albedo의 잘못된 경로는 남아 있음 |
| `script_and_paths` | script 제거 + albedo 경로 4개 수정 | 통과 | 45초, 별도 180초 관측 모두 미완료 |
| `merge_static` | 위 사본에서 반복 정적 링크만 병합 | 통과 | 약 2.886초·2.884초, 첫 갱신 후 정상 종료 |

병합 전 1,113개·병합 후 10개 링크이며, **충돌체 1,107개·시각 형상 1,113개는 동일**합니다. 모든 사본의 개별 형상·모델 기준 자세·접촉 설정을 정규화 대조했고 일치했습니다. 재질 외 XML은 병합 전 네 사본에서 동일합니다. 신호등/마커의 위치·치수를 고치거나, 센서·차량·팀 시설을 끼워 넣은 비교가 아닙니다.

추가 대조로 `script_and_paths`의 링크 1,113개를 그대로 두고 **시험용 서버 설정에서 Physics만 제외**했을 때 약 5.946초에 첫 갱신과 종료가 완료됐습니다. 이것은 물리 엔진 경로와의 관련성을 분리하는 진단이며, Physics를 끈 것을 정상 주행 환경의 해결책으로 권하지 않습니다.

### 파서 실패인데 종료 코드가 0인 점

README 방식의 `gz sim -v 4 world.sdf`와 서버 단독 명령 모두 원본에서 파싱에 실패한 뒤 종료했습니다. 실제 오류 중 일부는 다음과 같습니다.

```text
[Err] [Server.cc:86] Error Code 14: Msg: Parser configurations requested resolved uris, but uri [../aruco/aruco_id0.png] could not be resolved.
[Err] [Server.cc:86] Error Code 8: Msg: A <script> element is missing a child <name> element, or the <name> element is empty.
[Err] [Server.cc:86] Error Code 9: Msg: Failed to load a world.
```

원본 `gz sim` 자식 종료 코드는 **0**이었습니다. 반면 직접 관측한 `gz sdf -k` 자식 종료 코드는 **255**였습니다. 이전 Windows/WSL 명령 도구가 보고한 엄격 검사 exit 1 기록은 과거 기록으로 보존하며, 이번에는 직접 자식 코드와 오류 내용을 명시합니다. 공통 결론은 엄격 검사 실패이며, `gz sim`의 exit 0만을 성공 판정으로 쓰면 안 됩니다.

`script`를 제거하면 해당 파서 오류들이 사라집니다. 하지만 남은 PBR 경로 문제는 아래 렌더링에서 다시 나타납니다. **파서 오류·파일 존재·실제 영상은 서로 다른 검사**입니다. `script`의 선택 여부와 그 내부 `name`의 필수 여부는 [SDFormat 1.8 명세](https://sdformat.org/spec/1.8/material/)에서 확인할 수 있습니다.

### 180초 대기를 어떻게 해석했는가

줄 단위 로그로 다시 관측한 180초 실행에서는 세 기본 시스템 로드, `World [it_arena_track] initialized`, PostUpdate worker 생성까지 확인했습니다. 그러나 `--iterations 1`이 끝나지 않았습니다. 따라서 “XML을 전혀 못 읽는다” 또는 “영구 교착이 확정됐다”로 표현하지 않습니다. **월드 초기화 메시지 이후 첫 물리 갱신 미완료**가 확인 범위입니다.

관측 종료 뒤 SIGINT·SIGTERM으로 종료되지 않아 그 시험 프로세스 그룹만 SIGKILL로 정리했습니다. cleanup 포함 총 시간은 약 192.3초였고 잔여 실행 프로세스는 없었습니다. 병합 대조군은 강제 종료 없이 약 2.9초에 끝났습니다. 다른 PC·OS·엔진의 성능, 내부 함수의 정확한 병목·교착 여부는 미확인입니다. 시간은 엄밀한 벤치마크나 초당 프레임률이 아닙니다.

## 3. 실제 RGB로 분리한 두 재질 문제

별도 진단 카메라 네 개를 원본 마커의 정면 0.35 m·높이 0.10 m에 놓았습니다. 640×480·수평 화각 0.65 rad·2 Hz이며 각각 3프레임 이상 수신한 뒤 영상을 저장했습니다. 이 영상 시험은 Physics를 제외하고 `UserCommands`·`SceneBroadcaster`·`Sensors(Ogre2)`를 사용합니다. **D435i 또는 실제 주행 카메라 설정이 아닙니다.**

| 조건 | 렌더링 결과 | 저장 RGB의 예상 ID 검출 |
|---|---|---|
| `path_bad`: script만 제거 | 각 PNG에 `Unable to find file` 출력; 검은 판 | 0/4 |
| `path_fixed`: albedo 경로까지 수정 | 파일 오류는 없지만 여전히 검은 판 | 0/4 |
| `diffuse_white`: 바로 위에 diffuse 흰색만 추가 | 패턴 표시, 네 예상 ID 일치 | 4/4 |

대표 ID 30의 같은 카메라·같은 조명·같은 원위치 비교입니다.

- [경로만 수정한 원본 RGB: 검은 판](../../artifacts/validation/2026-08-31/official_raw_load/render/path_fixed/marker_30.png)
- [diffuse만 추가한 대조 RGB: ID 30 패턴](../../artifacts/validation/2026-08-31/official_raw_load/render/diffuse_white/marker_30.png)
- [두 SDF의 실제 차이: diffuse 네 줄뿐](../../artifacts/validation/2026-08-31/official_raw_load/patches/diffuse_only.diff)

밝기 보정·확대 보간·패턴 합성을 하지 않은 Gazebo RGB입니다. 파서 실패 화면을 이 사진으로 대체하지 않으며, 두 번째 사진은 **최소 재질 변경을 적용한 대조군**이라고 표시합니다. 조명 때문에 흰 영역도 회색으로 보일 수 있지만 패턴이 전부 0으로 지워지던 현상과 구분합니다.

SDFormat 1.8에서 `diffuse`는 선택 요소이고 기본값은 `0 0 0 1`입니다. `<diffuse>1 1 1 1</diffuse>`만 추가하여 이미지가 나타나는 대조를 확보했습니다. 필수 `name` 누락에 따른 파싱 실패와 다르며, `ambient` 추가·UV 수정·마커 이동·감지기 완화는 이 해결 대조에 사용하지 않았습니다. [재질 기본값 명세](https://sdformat.org/spec/1.8/material/)

OpenCV `DICT_4X4_50` 기본 검출에서 네 ID가 그대로 나왔고, 좌우 반전 진단 영상에서는 나오지 않았습니다. 반전본은 관찰값일 뿐 저장된 성공 RGB를 대체하지 않았습니다. 이 실험에서는 **PNG 사전·ID·원본 상자 앞면 UV 오류를 추가 결함으로 확인하지 못했습니다**. 주행 시 입사각·시야·가림·센서 지연과 네 마커의 물리 배치 문제는 별도입니다.

## 4. 기존 변환기의 작업을 다시 분류

| 기존 작업 | 이번 재현에 따른 분류 |
|---|---|
| 불완전한 legacy script 제거 | 원본 월드 파싱을 통과하기 위한 보정 |
| `../aruco/` 경로 수정 | 패키지 상대경로/실제 텍스처 로드 보정. 이것만으로 재질이 보이지는 않음 |
| 재질 색 명시 | 실제 RGB의 코드 패턴을 위한 보정. 이번에는 diffuse 한 항목으로 분리 확인 |
| 정적 링크 병합 | 이 DART 환경에서 초기 물리 갱신 지연을 줄이는 성능·호환 보정. XML 스키마 필수사항은 아님 |
| Physics/UserCommands/SceneBroadcaster 명시 추가 | 팀의 명시적 시스템 구성. 원본이 플러그인을 쓰지 않아도 기본 3개는 로드됨 |
| Sensors/IMU 추가 | 팀 센서 시뮬레이션 확장. 정적 원본 월드를 읽기 위한 필수 누락 항목으로 보고하지 않음 |
| 마커 벽 부착·신호등/방지턱 축·그리드 높이 보정 | 로드 이후 시설의 기하·표현 문제. 이번 파서/물리/재질 대조에 섞지 않음 |

현재 팀 운영 월드의 셀 기반 마커 표현이나 시설 보정을 이번에 교체하지 않았습니다. 기존 완주 결과는 그대로 유지하며, 이번 원인 분리만으로 운영 코드 개선이 구현됐다고 쓰지 않습니다.

## 5. 이슈에서 제외한 사항

- GUI의 QML binding-loop·안티앨리어싱 경고, 진단 카메라의 visibility-mask 경고: 정상 대조 실행에도 나타났으며 트랙 소스 오류로 분류하지 않았습니다.
- Python Gazebo 직접 바인딩 미설치: 기존 ROS 이미지 브리지를 사용해 검사했고 추가 패키지를 설치하지 않았습니다.
- vendor의 pkg-config 검색 경로 문제: `gz sim --versions`, `gz sdf --versions`, `dpkg-query`로 실제 버전을 확인했습니다. 이를 배포 트랙의 의존성 누락으로 보고하지 않습니다.
- 초기 감사 도구의 물리 로드 문자열 판정 불일치: 검색 문자열을 수정하고 공개 요약은 원시 로그를 재대조했습니다. 초기 JSON·강제 종료로 버퍼가 덜 기록된 로그도 `build`에 보존했습니다. 첫 갱신 시간·오류 코드·형상 비교 결론에는 영향이 없습니다.
- 원본 UDP 신호등의 화면 미연동, preview의 6배 방지턱 과장, 의도적으로 남긴 최소 반경: 앞선 정정·공식 설명을 유지하며 새 결함으로 되돌리지 않습니다.

## 6. 근거와 재실행

- [근거 묶음 README](../../artifacts/validation/2026-08-31/official_raw_load/README.md)
- [로드 시험 15건의 원시 기반 요약](../../artifacts/validation/2026-08-31/official_raw_load/summary.json)
- [원본·사본의 파일 해시](../../artifacts/validation/2026-08-31/official_raw_load/fixtures.json)
- [로드 비교 도구](../../scripts/audit_official_world_load.py), [진단 RGB 도구](../../scripts/audit_official_marker_render.py), [보존/형상 회귀 검사](../../tests/test_official_load_audit.py)
- [제출 전 로컬 근거 검증](../../artifacts/validation/2026-08-31/official_raw_load/review_validation.json): 초안 08 원문 코드 실행·두 사본의 엄격 SDF/형상 검사, RGB 12개의 해시/ID 재검출, 기존 활동 307줄·68,166 bytes 보존, 로컬 링크 119개 확인.

최종 Python/ROS 회귀 검사는 신규 감사 검사 8개를 포함하여 **113개 통과**했습니다. 공식·기존 실험 트랙의 `--check`도 통과했습니다. 이는 감사 도구와 기존 파생 월드의 일관성 검사이며, 위에서 실패한 무수정 원본을 정상이라고 판정한 결과가 아닙니다. 로그 정제의 잘린 ANSI 색 코드 처리도 검사했으며 원시 파일은 유지했습니다.

기존 결과를 덮어쓰지 않도록 새 `--workdir`을 사용합니다. 아래 명령은 WSL에서 저장소 루트를 현재 디렉터리로 두고 실행합니다. GUI는 선택적인 별도 검사입니다.

```bash
source /opt/ros/jazzy/setup.bash
python3 scripts/audit_official_world_load.py --workdir build/raw_load_audit_new --prepare --cases raw paths_only remove_script script_and_paths merge_static --modes check server --timeout 45
python3 scripts/audit_official_world_load.py --workdir build/raw_load_audit_new --cases script_and_paths --modes server --timeout 180 --run-id long --line-buffered
python3 scripts/audit_official_marker_render.py path_bad --workdir build/raw_load_audit_new
python3 scripts/audit_official_marker_render.py path_fixed --workdir build/raw_load_audit_new
python3 scripts/audit_official_marker_render.py diffuse_white --workdir build/raw_load_audit_new
python3 -m pytest tests/test_official_load_audit.py -q
```

로드 감사 도구가 실행을 마치고 exit 0을 반환하는 것은 **예상된 실패를 포함한 결과 수집이 끝났다는 뜻**입니다. 원본 통과 여부는 개별 결과의 오류·타임아웃·실제 첫 갱신 완료를 함께 봅니다. 원본 실패를 검사의 성공으로 오인하지 않습니다.

이슈는 로컬 본문만 준비합니다. 새 비교 사진도 로컬 근거로 보관하며, 아직 존재하지 않는 공개 이미지 URL을 본문에 넣지 않습니다. 새 명시적 승인 전에는 주최 측 이슈·댓글 게시나 팀 저장소 push를 하지 않습니다.
