**어떤 파일에서**

`track/output_final/world.sdf`의 `aruco_*` 재질, `track/track_gen.py:write_sdf()`

**무엇이 이상한가요**

릴리스 ZIP을 새 디렉터리에 풀고 README의 `gz sim world.sdf`를 실행했으나, ArUco 재질 파싱 단계에서 **월드 전체를 불러오지 못했습니다**. 기존에 수정한 실행본이 아닌 배포 원본으로 재현하여 확인 부탁드립니다.

**환경**

- 확인일: 2026-08-31
- 배포 버전: `v2026.08.31` / `d61c5db9252cedfbc163cd044a47671df91e1660`
- Windows / WSL Ubuntu 24.04.4 LTS / ROS 2 Jazzy / Gazebo Sim 8.11.0
- libsdformat 14.9.0, 파일의 SDF 버전 1.8
- 별도 차량·ROS launch·팀 월드 변환기를 사용하지 않은 실행
- ZIP SHA-256: `897183d2e2541458d190a0a1e3f76bff754c67fab894f2302c3110830a86149b`
- 원본 `world.sdf` SHA-256: `62d7ae4abf2dbcc0ce850065de5ade28703a67649ab6a8c62311c432cc2200de`

## 재현 방법과 실제 출력

압축 해제 후 `output_final/`에서 아래를 각각 실행했습니다. 폴더 구조와 원본 파일 23개를 유지했습니다.

```bash
source /opt/ros/jazzy/setup.bash
gz sdf -k world.sdf
gz sim -v 4 world.sdf
```

엄격 검사는 첫 오류 네 번과 마지막 오류 한 번으로 실패합니다. 감사 도구가 직접 관측한 `gz sdf` 자식 프로세스 종료 코드는 255였습니다.

```text
Error Code 8: Msg: A <script> element is missing a child <name> element, or the <name> element is empty.
Error Code 9: Msg: Failed to load a world.
```

실제 `gz sim`에도 같은 Code 8 네 회·Code 9 한 회가 발생하며, 아래 URI 오류도 네 회 함께 출력됩니다.

```text
[Err] [Server.cc:86] Error Code 14: Msg: Parser configurations requested resolved uris, but uri [../aruco/aruco_id0.png] could not be resolved.
[Err] [Server.cc:86] Error Code 8: Msg: A <script> element is missing a child <name> element, or the <name> element is empty.
...
[Err] [Server.cc:86] Error Code 9: Msg: Failed to load a world.
```

GUI 실행과 `gz sim -s -r -v 4 --iterations 1 world.sdf` 모두 파싱 실패 후 종료했습니다. **이 환경에서 `gz sim` 종료 코드는 0이었지만 월드 초기화 메시지는 없었습니다.** 종료 코드만으로 로드 성공을 판정할 수 없다는 관찰이며, Gazebo의 종료 코드 처리까지 트랙 생성기의 책임이라고 주장하는 것은 아닙니다.

## 최소 변경으로 분리한 결과

| 원본 사본의 변경 | `gz sdf -k` | 실제 서버 파싱 |
|---|---|---|
| 없음 | Code 8 ×4, Code 9 ×1 | Code 14 ×4, Code 8 ×4, Code 9 ×1; 월드 로드 실패 |
| 이미지 경로 8곳만 `../aruco/` → `aruco/` | 같은 Code 8/9 | URI 오류는 사라지지만 Code 8/9로 여전히 실패 |
| 불완전한 `script` 블록 4개만 제거 | 통과 | Code 8/9/14 없이 월드 초기화 단계에 진입. 이후 물리 갱신 지연·텍스처 문제는 별개 |

따라서 이미지 상대경로만 수정해서는 원본 로드 실패가 해결되지 않았습니다. 문제의 블록은 아래와 같고, 네 마커에 반복됩니다.

```xml
<script><uri>../aruco/aruco_id0.png</uri></script>
```

SDFormat 1.8에서 `script` 자체는 선택 항목이지만, 이를 사용하면 `name`은 필수입니다. 또한 이 URI는 material script가 아니라 PNG를 가리킵니다. Gazebo Sim용으로 이미 있는 PBR `albedo_map`을 사용할 경우 불완전한 legacy `script`를 제거하는 방법으로 파싱 실패를 해소할 수 있었습니다. 경로·재질 색·물리 초기화까지 모두 해결됐다는 뜻은 아닙니다.

## 근거자료

- [마커 재질·URI를 생성하는 부분](https://github.com/MOSW626/istech-it-arena/blob/d61c5db9252cedfbc163cd044a47671df91e1660/track/track_gen.py#L1727-L1744)
- [배포 SDF의 해당 재질](https://github.com/MOSW626/istech-it-arena/blob/d61c5db9252cedfbc163cd044a47671df91e1660/track/output_final/world.sdf#L15098-L15153)
- [SDFormat 1.8 material 명세](https://sdformat.org/spec/1.8/material/)

이 문제는 화면이 정상 구성되기 전의 파싱 실패이므로, 변환 후 트랙 사진 대신 직접 오류 출력을 제시했습니다.

## 확인 부탁드리는 점

1. Gazebo Sim용 출력에서는 불완전한 `script`를 제거하고 PBR 재질을 사용하는 방향이 맞을까요? 다른 시뮬레이터와의 호환 의도가 있다면 유효한 스크립트·이름 조합을 확인 부탁드립니다.
2. 출력물뿐 아니라 `write_sdf()`에서도 수정하여 재생성 시 같은 문제가 다시 생기지 않게 할 수 있을까요?
3. 배포 전 `gz sdf -k`와 실제 `gz sim` 초기화·첫 갱신을 함께 확인하는 절차를 검토 부탁드립니다.
