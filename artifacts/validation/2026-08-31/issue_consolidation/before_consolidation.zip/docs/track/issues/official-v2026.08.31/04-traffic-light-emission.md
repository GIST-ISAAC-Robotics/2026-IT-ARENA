**어떤 파일에서**

`track/output_final/world.sdf`의 `tl_post`·`tl_beam`·`lamp_*`, `track/track_gen.py:write_sdf()`, `track/output_final/traffic_light.py`

**무엇이 이상한가요**

배포 SDF의 신호등에서 가로대와 세 LED 중심이 도로를 가로지르지 않고 **주행 방향으로 나란히** 놓이는 점을 확인했습니다. 좌측 기둥에서 도로를 가로지르는 배치가 의도된 것인지 여쭙습니다.

실물 제작·색 배열과 점등 시퀀스는 [기존 #3](https://github.com/MOSW626/istech-it-arena/issues/3)의 후속 사양을 따르며, [#5의 랜덤 hold](https://github.com/MOSW626/istech-it-arena/issues/5) 작업을 중복 요청하는 것은 아닙니다.

**환경**

- 확인 버전: `v2026.08.31` / `d61c5db9252cedfbc163cd044a47671df91e1660` (등록 전 최신 `main`과 동일함을 재확인)
- Windows / WSL Ubuntu 24.04.4 LTS / ROS 2 Jazzy / Gazebo Sim 8.11.0

## 확인한 결과

| 항목 | 원본 값·계산 결과 |
|---|---|
| 신호 위치의 도로 접선 yaw | 약 1.569414 rad, 89.9208° |
| 가로대 yaw / 크기 | 1.56941 rad / 0.75×0.06×0.06 m |
| 빨강→초록 중심의 XY 차이 | (0.0004, 0.3000) m |
| 위 중심 차이의 진행 방향 성분 | 약 0.300000 m |
| 위 중심 차이의 횡단 방향 성분 | 약 0.000015 m |

가로대의 긴 X축과 LED 열 모두 진행 방향에 가깝습니다. 반면 **기둥은 이미 도로 좌측 횡방향 약 0.275 m에 배치**되어 있으므로, 신호등 전체를 통째로 90도 돌리는 수정과 가로대·등 배열만 정렬하는 수정은 다릅니다.

![원본 신호등의 가로대·세 등 배열과 주변 도로](https://raw.githubusercontent.com/GIST-ISAAC-Robotics/2026-IT-ARENA/57067bc870e37b68da2e10aa374de09c838dbfaf/artifacts/screenshots/2026-08-31/official_update/upstream_signal_all_lit.png)

사진은 로드 호환성만 보정하고 신호등의 좌표·치수·발광값을 유지한 실행입니다. 정확한 각도는 사진에서 측정한 값이 아니라 위 SDF 좌표로 계산했습니다.

## 초기 점등 표현의 해석

현재 세 색 모두 `emissive`가 설정되어 있습니다. 다만 동봉 `traffic_light.py`의 설명을 다시 확인하니 **Gazebo 직접 제어를 하지 않고, 화면 연결은 사용하는 팀이 별도 bridge로 구성하는 시뮬레이터 중립 설계**라고 명시되어 있습니다.

따라서 **UDP 상태가 기본 화면과 연동되지 않는 것 자체를 구현 누락이나 버그로 보고하지 않습니다.** 기본 월드의 세 색 동시 표시는 형태 확인용 정적 예시인지 확인하고자 합니다.

## 근거자료

- [신호등 기준 pose](https://github.com/MOSW626/istech-it-arena/blob/d61c5db9252cedfbc163cd044a47671df91e1660/track/track_gen.py#L545-L550)
- [기둥·가로대·LED 배치 생성](https://github.com/MOSW626/istech-it-arena/blob/d61c5db9252cedfbc163cd044a47671df91e1660/track/track_gen.py#L1693-L1711)
- [배포 SDF의 실제 신호등](https://github.com/MOSW626/istech-it-arena/blob/d61c5db9252cedfbc163cd044a47671df91e1660/track/output_final/world.sdf#L15030-L15095)
- [팀별 bridge를 명시한 동봉 설명](https://github.com/MOSW626/istech-it-arena/blob/d61c5db9252cedfbc163cd044a47671df91e1660/track/output_final/traffic_light.py#L19-L31)

## 확인 부탁드리는 점

1. 횡단 배치가 의도라면 **기둥은 유지하고 가로대 축과 LED 중심 배열만 90도 정렬**하는 것이 맞을까요? 회전 부호에 따른 색의 좌우 순서는 #3의 사양과 대조하겠습니다.
2. 기본 세 색 동시 발광은 정적 예시 상태로 이해하면 될까요? 실제 출발 인식 시험은 안내된 팀별 bridge에서 활성 색을 제어하는 것으로 이해했습니다.
