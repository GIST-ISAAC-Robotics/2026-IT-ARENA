**어떤 파일에서**

`track/output_final/scene.json:starting_grid`, `track/track_gen.py:build_grid_zone_slots()/write_scene_json()`

**무엇이 이상한가요**

`longitudinal_stagger_m`는 0.30 m인데 실제 두 열의 슬롯 s 차이는 0.20 m여서, 이 메타데이터가 요청값인지 실제 적용값인지 확인 부탁드립니다. 슬롯끼리 충돌한다는 보고는 아닙니다.

**환경**

- 확인 버전: `v2026.08.31` / `d61c5db9252cedfbc163cd044a47671df91e1660` (등록 전 최신 `main`과 동일함을 재확인)
- Windows / WSL Ubuntu 24.04.4 LTS / ROS 2 Jazzy / Gazebo Sim 8.11.0

## 확인한 결과

| row | col 0의 s [m] | col 1의 s [m] | 실제 차이 [m] |
|---|---:|---:|---:|
| 0 | 44.846 | 44.646 | 0.200 |
| 1 | 45.346 | 45.146 | 0.200 |
| 2 | 45.846 | 45.646 | 0.200 |

위 슬롯의 s는 표시를 위해 소수 셋째 자리로 반올림했습니다. 요약 필드 `starting_grid.longitudinal_stagger_m`는 **0.300 m**입니다.

생성기는 `min(GRID_STAGGER, row_spacing * 0.4)`로 실제 배치를 제한하지만, 요약에는 제한 전 `GRID_STAGGER`를 기록합니다. 슬롯 pose 대신 이 필드로 그리드를 재구성하면 배포 SDF와 다른 배치가 나올 수 있습니다.

## 읽기 전용 재현

Gazebo 없이, 릴리스 ZIP을 푼 디렉터리에서 Python 3로 확인할 수 있습니다.

```bash
python3 -B - <<'PY'
import json
from pathlib import Path
g = json.loads(Path("output_final/scene.json").read_text())["starting_grid"]
print("metadata_stagger_m:", g["longitudinal_stagger_m"])
for row in sorted({s["row"] for s in g["slots"]}):
    pair = {s["col"]: s for s in g["slots"] if s["row"] == row}
    print("row", row, "actual_delta_s_m:",
          round(pair[0]["s_m"] - pair[1]["s_m"], 6))
PY
```

출력:

```text
metadata_stagger_m: 0.3
row 0 actual_delta_s_m: 0.2
row 1 actual_delta_s_m: 0.2
row 2 actual_delta_s_m: 0.2
```

- [실제 간격 제한 계산](https://github.com/MOSW626/istech-it-arena/blob/d61c5db9252cedfbc163cd044a47671df91e1660/track/track_gen.py#L501-L520)
- [요약 필드에 기록하는 값](https://github.com/MOSW626/istech-it-arena/blob/d61c5db9252cedfbc163cd044a47671df91e1660/track/track_gen.py#L2012-L2017)
- [배포 scene의 슬롯 값](https://github.com/MOSW626/istech-it-arena/blob/d61c5db9252cedfbc163cd044a47671df91e1660/track/output_final/scene.json#L4151-L4222)

그리드가 보이지 않는 전체 사진으로는 이 차이를 설명할 수 없어 사진은 첨부하지 않았습니다. 위 표와 재현 출력이 직접 근거입니다.

## 확인 부탁드리는 점

1. `longitudinal_stagger_m`는 요청값으로 해석하는 것이 맞을까요, 실제 적용된 간격을 나타내는 것이 맞을까요?
2. 두 값 모두 필요하다면 요청값/적용값을 구분해 제공하거나 의미를 문서화할 수 있을지 검토 부탁드립니다.
