**어떤 파일에서**

`track/track_gen.py:markers_from_design()`, `track/output_final/world.sdf`, `scene.json`, `branch_1.csv`

**무엇이 이상한가요**

배포해 주신 트랙으로 시뮬레이션을 구성하면서, 코스 ArUco의 벽 부착 안내와 실제 배치에 차이가 있어 확인 부탁드립니다. 특히 ID 30은 지름길 2의 중심선에 정렬한 20×15 cm 차량 외형과 일부 구간에서 겹칩니다.

**환경**

- 확인 버전: `v2026.08.31` / `d61c5db9252cedfbc163cd044a47671df91e1660` (등록 전 최신 `main`과 동일함을 재확인)
- Windows / WSL Ubuntu 24.04.4 LTS / ROS 2 Jazzy / Gazebo Sim 8.11.0

## 확인한 결과

| 항목 | 원본에서 계산한 값 |
|---|---|
| ID 0/20/45 판 중심에서 가장 가까운 벽 폴리곤까지 거리 | 각각 약 0.070 m |
| ID 30 판 중심에서 벽 폴리곤까지 거리 | 약 0.0964 m |
| 지름길 2의 ID 30 간섭 | `branch_1.csv` 141표본 중 index 13~22, 총 10표본 |
| 간섭 구간 | 분기 시작 기준 s≈0.262509~0.444246 m |

검사는 각 CSV 표본에 진행 방향으로 길이 0.20 m·폭 0.15 m 직사각형을 놓고, SDF의 판 충돌체와 면적 교차를 확인한 것입니다. **중앙 경로의 정적 간섭 검사**이며, 다른 회피 경로까지 모두 불가능하다거나 실제 차량이 반드시 충돌한다고 판단한 것은 아닙니다.

## 근거와 재현

- [마커 배치 함수](https://github.com/MOSW626/istech-it-arena/blob/d61c5db9252cedfbc163cd044a47671df91e1660/track/track_gen.py#L524-L542)
- [배포 SDF의 ID 30](https://github.com/MOSW626/istech-it-arena/blob/d61c5db9252cedfbc163cd044a47671df91e1660/track/output_final/world.sdf#L15140-L15152)
- [CSV·SDF로 간섭 도식을 재현하는 코드](https://github.com/GIST-ISAAC-Robotics/2026-IT-ARENA/blob/57067bc870e37b68da2e10aa374de09c838dbfaf/scripts/illustrate_official_issues.py)

![원본 위치의 ID 30 판과 지름길 입구](https://raw.githubusercontent.com/GIST-ISAAC-Robotics/2026-IT-ARENA/57067bc870e37b68da2e10aa374de09c838dbfaf/artifacts/screenshots/2026-08-31/official_update/upstream_marker_id30.png)

이 화면은 원본의 좌표·치수는 유지하고 로드 호환성만 보정한 실행입니다. 벽에서 떨어진 판의 위치를 보여주기 위한 사진이며, 검은 판의 렌더링 원인을 입증하는 사진은 아닙니다.

![원본 CSV와 SDF를 이용한 중앙 경로 10표본 간섭 계산](https://raw.githubusercontent.com/GIST-ISAAC-Robotics/2026-IT-ARENA/57067bc870e37b68da2e10aa374de09c838dbfaf/artifacts/screenshots/2026-08-31/official_update/upstream_id30_collision_plan.png)

두 번째 그림은 실제 화면이 아니라 CSV/SDF 수치로 그린 **정적 간섭 도식**입니다.

## 확인 부탁드리는 점

1. 안내대로 판을 벽에 붙이는 것이 의도된 배치라면, 기존 ID·경로상 s·좌우 측면을 유지하면서 벽면으로 옮기는 방향이 맞을까요?
2. ID 30 위치를 조정할 때 지름길의 차량 외형 간섭도 함께 확인하고, `scene.json`과 SDF에 같은 보정 위치를 기록할 수 있을지 검토 부탁드립니다.
