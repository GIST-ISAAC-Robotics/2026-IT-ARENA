**어떤 파일에서**

`track/output_final/world.sdf`의 `it_arena_track_static`, `track/track_gen.py:write_sdf()`

**무엇이 이상한가요**

배포 SDF의 재질 파싱 문제를 최소 수정한 뒤에도, 기본 물리 시스템으로 **첫 갱신 1회를 완료하는 데 180초 이상 대기**하는 현상을 확인했습니다. 원본 형상을 유지하고 정적 링크만 병합한 경우에는 약 2.9초에 완료되어, 지원 환경에서의 초기화 성능을 확인 부탁드립니다.

**환경**

- 확인일: 2026-08-31
- `v2026.08.31` / `d61c5db9252cedfbc163cd044a47671df91e1660`
- Windows / WSL Ubuntu 24.04.4 LTS / ROS 2 Jazzy
- Gazebo Sim 8.11.0, libsdformat 14.9.0
- 실제 로드된 물리 엔진: `gz::physics::dartsim::Plugin`
- 기본 서버 시스템: `Physics`, `UserCommands`, `SceneBroadcaster`
- GUI·센서·차량이 없는 서버 단독 시험. 기존 관찰용 Gazebo는 별도 통신 영역에서 일시정지 상태로 유지

## 재현 조건

무수정 배포본은 `<script><name>` 누락 때문에 파싱에서 중단되므로, 이 시험에서는 별도 사본에서 **불완전한 script 4개 제거 + albedo 경로 4개 수정**만 먼저 적용했습니다. 도로·벽·시설·충돌체·마찰·링크 수는 바꾸지 않았습니다.

```bash
gz sim -s -r -v 4 --iterations 1 world.sdf
```

| 대조 조건 | 트랙 링크 / 충돌체 / 시각 형상 | 첫 갱신 1회 및 종료 |
|---|---|---|
| 재질·경로만 수정, 기본 물리 | 1113 / 1107 / 1113 | 45초 관측과 별도 180초 관측에서 모두 미완료 |
| 같은 사본에서 정적 링크만 병합, 기본 물리 | 10 / 1107 / 1113 | 두 실행에서 약 2.886초·2.884초, 정상 종료 |
| 링크 1113개 유지, 시험용 서버 설정에서 Physics만 제외 | 1113 / 1107 / 1113 | 약 5.946초, 정상 종료. **물리 검증 성공을 뜻하지 않는 대조군** |

시간은 시작부터 프로세스 종료까지이며 첫 이미지 생성 시간이나 엄밀한 성능 벤치마크는 아닙니다. 180초는 **관측 상한**이고, 그 이후 언젠가 완료되는지 또는 내부적으로 교착됐는지는 확인하지 못했습니다. 관측 종료 후 시험 프로세스는 SIGINT·SIGTERM에 응답하지 않아 해당 시험 그룹만 SIGKILL로 정리했습니다. 실제 cleanup을 포함한 총 대기는 약 192초였으며 이를 180초 로드 성공으로 기록하지 않았습니다.

## 로그에서 확인한 진행 단계

180초 시험에서는 파서 오류 없이 아래까지 진행했습니다.

```text
Loaded system [gz::sim::systems::Physics] for entity [1]
Loaded system [gz::sim::systems::UserCommands] for entity [1]
Loaded system [gz::sim::systems::SceneBroadcaster] for entity [1]
World [it_arena_track] initialized with [default_physics] physics profile.
Creating PostUpdate worker threads: 2
Creating postupdate worker thread (0)
```

따라서 단순 XML 읽기 실패가 아니라 **월드 초기화 메시지 이후 첫 물리 갱신 완료가 지연되는 현상**으로 분류했습니다. 위 메시지만으로 사용 가능한 시뮬레이션이 준비됐다고 판정하지 않았습니다. SDF의 `physics type="ode"` 표기와 실제 선택된 DART 플러그인은 구분했습니다.

## 원본을 보존하는 비교 사본 만들기

압축을 해제한 `output_final/`에서 아래 코드는 새 SDF 두 개만 생성합니다. 기존 파일이 있으면 중단합니다.

```python
from pathlib import Path
import copy
import xml.etree.ElementTree as ET

for name in ("audit_materials_only.sdf", "audit_merged.sdf"):
    assert not Path(name).exists(), name
tree = ET.parse("world.sdf")
root = tree.getroot()
for material in root.findall(".//material"):
    for script in list(material.findall("script")):
        material.remove(script)
for tag in root.findall(".//albedo_map"):
    tag.text = tag.text.replace("../aruco/", "aruco/")
tree.write("audit_materials_only.sdf", encoding="utf-8", xml_declaration=True)

model = root.find("world/model[@name='it_arena_track_static']")
merged = ET.Element("link", name="audit_merged_static_geometry")
prefixes = ("ground_plane_", "surface_", "grass_", "walls_", "bump_", "grid_")
for link in list(model.findall("link")):
    if not link.get("name").startswith(prefixes):
        continue
    pose = link.findtext("pose", "0 0 0 0 0 0")
    for tag in ("collision", "visual"):
        for original in link.findall(tag):
            assert original.find("pose") is None
            child = copy.deepcopy(original)
            child.set("name", link.get("name") + "__" + child.get("name"))
            ET.SubElement(child, "pose").text = pose
            merged.append(child)
    model.remove(link)
model.insert(1, merged)
tree.write("audit_merged.sdf", encoding="utf-8", xml_declaration=True)
print("links:", len(model.findall("link")))  # 10
print("collisions:", len(model.findall(".//collision")))  # 1107
print("visuals:", len(model.findall(".//visual")))  # 1113
```

각 파일을 별도 `GZ_PARTITION`에서 같은 `--iterations 1` 명령으로 비교할 수 있습니다. 오래 걸리는 경우에는 관측 시간을 제한하는 것이 좋습니다. 병합 전후의 개별 형상·자세·접촉 설정을 정규화 대조하여 일치함을 확인했으며, 신호등·마커 링크는 별도로 유지했습니다. 이 코드는 이번 배포본의 평탄한 정적 링크 구조를 위한 비교용이지 일반 로봇 관절 모델의 병합 도구는 아닙니다.

## 확인 부탁드리는 점

1. 안내하시는 Gazebo 버전·물리 엔진에서도 같은 초기 갱신 지연이 발생하는지 확인할 수 있을까요?
2. 필요하다면 반복 정적 형상의 링크 병합, 또는 검증된 실행 환경 안내를 검토 부탁드립니다. 형상 삭제나 도로 단순화가 필수라는 의미는 아닙니다.
3. 원본 파일의 파싱 통과뿐 아니라 첫 갱신·정상 종료까지 배포 검사에 포함할 수 있을까요?

다른 운영체제·물리 엔진에서도 반드시 같은 문제가 발생한다고 단정하지 않습니다. 정지 상태의 화면 사진으로 긴 대기를 입증하기 어려워 수치와 실행 조건을 제시했습니다.
