**어떤 파일에서**

`track/track_gen.py:write_sdf()`, `track/output_final/world.sdf:bump_0`, `scene.json:speed_bumps`

**무엇이 이상한가요**

방지턱의 주행 방향 길이는 0.05 m로 안내되어 있는데, SDF에서는 주행 방향 0.45 m·횡단 방향 0.05 m로 생성되는 것을 확인했습니다. 치수를 내보내는 X/Y 순서가 바뀐 것인지 확인 부탁드립니다.

실물 제작을 관리하는 [기존 #2](https://github.com/MOSW626/istech-it-arena/issues/2)와는 별도로, 현재 배포된 SDF의 축 방향만 확인한 내용입니다.

**환경**

- 확인 버전: `v2026.08.31` / `d61c5db9252cedfbc163cd044a47671df91e1660` (등록 전 최신 `main`과 동일함을 재확인)
- Windows / WSL Ubuntu 24.04.4 LTS / ROS 2 Jazzy / Gazebo Sim 8.11.0

## 확인한 결과

| 항목 | 안내·생성 중간값 | 배포 SDF |
|---|---|---|
| 주행 방향 길이 | 0.05 m | 약 0.45 m |
| 횡단 방향 폭 | 0.45 m | 약 0.05 m |
| 높이 | 기본 0.01 m | 0.01 m |

- `bump_0`의 yaw는 `1.57380 rad`로 해당 도로의 진행 방향과 같습니다.
- box size는 `0.4500 0.0500 0.0100`이며, 긴 로컬 X축이 주행 방향입니다.
- 생성기의 `_sdf_box_link()` 호출에서 X에 `bmp["width"]`, Y에 `bmp["length"]`가 전달됩니다.

## 근거와 재현

- [진행 길이 상수와 주석](https://github.com/MOSW626/istech-it-arena/blob/d61c5db9252cedfbc163cd044a47671df91e1660/track/track_gen.py#L54)
- [SDF 내보내기의 X/Y 전달 순서](https://github.com/MOSW626/istech-it-arena/blob/d61c5db9252cedfbc163cd044a47671df91e1660/track/track_gen.py#L1677-L1679)
- [배포 SDF의 pose·box size](https://github.com/MOSW626/istech-it-arena/blob/d61c5db9252cedfbc163cd044a47671df91e1660/track/output_final/world.sdf#L14969-L14979)

![원본 SDF에서 주행 방향으로 길게 놓인 방지턱](https://raw.githubusercontent.com/GIST-ISAAC-Robotics/2026-IT-ARENA/57067bc870e37b68da2e10aa374de09c838dbfaf/artifacts/screenshots/2026-08-31/official_update/upstream_bump_axis.png)

![원본 SDF와 명목 진행·횡단 치수의 계산 도식](https://raw.githubusercontent.com/GIST-ISAAC-Robotics/2026-IT-ARENA/57067bc870e37b68da2e10aa374de09c838dbfaf/artifacts/screenshots/2026-08-31/official_update/upstream_bump_axis_plan.png)

첫 사진은 로드 호환성만 보정하고 원본 방지턱 좌표·치수를 유지한 실행입니다. 두 번째는 원본 SDF를 계산해 그린 도식입니다. `preview.png`가 시인성을 위해 방지턱 길이를 **의도적으로 6배 과장**하는 것은 별개이며, 도면의 표시 길이를 실물 치수로 해석하지 않았습니다.

## 확인 부탁드리는 점

1. 현재 명목 치수를 유지한다면 SDF의 X/Y 인수를 `length, width` 순서로 바꾸는 것이 맞을까요?
2. 최종 단면·재질은 #2의 제작 자료를 따르되, 시뮬레이션과 안내에서 진행/횡단 축의 의미를 일치시키는 방향으로 검토 부탁드립니다.
