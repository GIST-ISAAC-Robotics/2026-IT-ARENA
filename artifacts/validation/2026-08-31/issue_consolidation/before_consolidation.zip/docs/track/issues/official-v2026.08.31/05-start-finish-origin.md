**어떤 파일에서**

`track/design_final.json:features.start_line`, `track/track_gen.py:build_all_from_design()/write_dxf()`, `track/output_final/scene.json`, `venue_layout.dxf`

**무엇이 이상한가요**

설계에 저장된 출발/결승선의 s와 출력 도면에 사용된 기준점이 약 38.7 cm 달라, 어느 쪽을 경기 기준으로 사용하면 될지 확인 부탁드립니다.

**환경**

- 확인 버전: `v2026.08.31` / `d61c5db9252cedfbc163cd044a47671df91e1660` (등록 전 최신 `main`과 동일함을 재확인)
- Windows / WSL Ubuntu 24.04.4 LTS / ROS 2 Jazzy / Gazebo Sim 8.11.0

## 확인한 결과

| 구분 | 경로 기준 s | 해당 중심선 기준점 XY |
|---|---:|---|
| 설계 `features.start_line` | 약 46.246139726 m | 약 (9.963404, 6.079770) m |
| 신호등·ID 0의 경로상 기준 | 0 m | 약 (9.9660, 6.4665) m |
| DXF 출발/결승선 중심 | 신호등 pose 사용 | (9.9660, 6.4665) m |

이 표의 s=0 좌표는 **중심선 기준점**입니다. ID 0 판의 실제 위치인 약 (10.3210, 6.4660) m와 구분합니다. 두 s의 폐회로상 차이는 약 0.3867 m입니다.

생성기는 설계 출발선을 `meta.startfinish_s`에 저장하지만, DXF 선을 그릴 때는 신호등 pose를 사용합니다. `scene.json`에는 독립적인 start_line pose가 없어 이 파일만 읽는 팀은 기준 선택이 달라질 수 있습니다.

## 읽기 전용 재현

릴리스 ZIP을 푼 디렉터리에서 실행할 수 있습니다.

```bash
python3 -B - <<'PY'
import json
from pathlib import Path
f = json.loads(Path("design_final.json").read_text())["features"]
print("design_start_line_s:", f["start_line"]["s"])
print("traffic_light_s:", f["traffic_light"]["s"])
print("id0_s:", next(m["s"] for m in f["aruco"] if m["id"] == 0))
PY
```

- [설계 JSON](https://github.com/MOSW626/istech-it-arena/blob/d61c5db9252cedfbc163cd044a47671df91e1660/track/design_final.json)
- [start_line을 읽는 코드](https://github.com/MOSW626/istech-it-arena/blob/d61c5db9252cedfbc163cd044a47671df91e1660/track/track_gen.py#L1136-L1139)
- [신호등 pose를 사용하는 DXF 출력](https://github.com/MOSW626/istech-it-arena/blob/d61c5db9252cedfbc163cd044a47671df91e1660/track/track_gen.py#L1848-L1856)

전체 트랙 사진에서는 두 기준의 차이를 식별하기 어려워 첨부하지 않았습니다. 근거는 JSON 값과 DXF·생성기 코드입니다.

## 확인 부탁드리는 점

1. 설계 start_line과 s=0 중 어느 값이 출발/결승선의 의도된 기준일까요? 두 위치를 의도적으로 구분한 것이라면 그 의미를 안내해 주실 수 있을까요?
2. 기준을 `scene.json`에도 명시하여 도면·계측·시뮬레이션에서 같은 의미로 사용할 수 있을지 검토 부탁드립니다.
