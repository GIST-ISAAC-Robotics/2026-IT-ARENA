**어떤 파일에서**

`track/output_final/world.sdf`의 `aruco_0/20/30/45` 재질, `track/output_final/aruco/`, `track/track_gen.py:write_sdf()`

**무엇이 이상한가요**

월드의 재질 파싱 오류를 우회한 뒤에도 ArUco 네 개가 검은 판으로 표시되어, 텍스처 경로와 재질 색을 단계별로 비교했습니다. **상대경로 오류와, 경로 수정 후에도 남는 검은 재질 표시를 각각 재현**하여 확인 부탁드립니다.

**환경**

- 확인일: 2026-08-31
- `v2026.08.31` / `d61c5db9252cedfbc163cd044a47671df91e1660`
- Windows / WSL Ubuntu 24.04.4 LTS / ROS 2 Jazzy
- Gazebo Sim 8.11.0 / libsdformat 14.9.0 / Ogre2
- 원본 위치의 정지 마커에 정면 진단 카메라 4개 추가: 거리 0.35 m, 높이 0.10 m, 640×480, 수평 화각 0.65 rad, 2 Hz
- 물리 초기화 지연과 분리하기 위해 이 영상 시험에서만 Physics를 제외. 차량·실차 카메라·주행 중 인식 성능 시험은 아님

## 1. 실제 폴더 구조와 albedo 경로

| 항목 | 배포 상태 |
|---|---|
| 월드 | `output_final/world.sdf` |
| 실제 이미지 | `output_final/aruco/aruco_id0.png` 등 4개 |
| SDF의 `albedo_map` | `../aruco/aruco_id0.png` 등 |
| SDF 기준으로 존재하는 상대경로 | `aruco/aruco_id0.png` 등 |

불완전한 `script` 4개만 제거한 시험 사본에서, 실제 렌더러가 아래 오류를 각 ID에 대해 출력했습니다.

```text
[Err] [SceneManager.cc:928] Unable to find file [../aruco/aruco_id0.png]
[Err] [SceneManager.cc:928] Unable to find file [../aruco/aruco_id20.png]
[Err] [SceneManager.cc:928] Unable to find file [../aruco/aruco_id45.png]
[Err] [SceneManager.cc:928] Unable to find file [../aruco/aruco_id30.png]
```

`gz sdf -k`는 이 사본에서 통과했습니다. 즉 엄격 SDF 검사만으로 실제 텍스처 로드 성공까지 확인되지는 않았습니다.

## 2. 경로 수정 후에도 검게 표시되는 재질

경로를 고치자 파일 찾기 오류는 사라졌지만 네 마커의 코드가 계속 검게 표시됐습니다. 그 상태에서 **각 마커 material에 `<diffuse>1 1 1 1</diffuse>` 한 항목만 추가**하자 패턴과 네 ID가 확인됐습니다.

| 시험 사본 | 파일 찾기 오류 | 원본 RGB의 ID 0/20/30/45 검출 |
|---|---|---|
| script 제거, 경로는 원본 | 4개 | 0/4 |
| script 제거 + 경로 수정 | 없음 | 0/4, 판 중앙 200×200 px의 밝기 전부 0 |
| 위 사본 + diffuse 흰색 명시 | 없음 | 4/4, 각 예상 ID와 일치 |

세 실행에서 트랙 링크 1,113개·시설의 위치·치수·판 방향·PNG·광원·카메라를 유지했습니다. 각 카메라에서 3프레임 이상 수신한 뒤 저장한 원본 RGB를 OpenCV 4.6.0 `DICT_4X4_50` 기본 검출기로 비교한 결과입니다. 파일 밝기 조절이나 이미지 뒤집기를 검출 성공 조건으로 사용하지 않았습니다. 출력물이 전반적으로 어두울 수는 있지만 코드 패턴을 구별하지 못하던 현상과는 분리했습니다.

SDFormat 1.8의 `diffuse`는 **필수 요소가 아니라 생략 가능하며 기본값이 `0 0 0 1`**입니다. 필수 `script/name` 누락으로 파서가 실패하는 문제와는 다릅니다. 이번 환경에서는 albedo PNG가 존재하더라도 이 기본 색 때문에 패턴이 검게 표시되는 것을 한 항목 변경 실험으로 확인했습니다.

마커 재질은 예를 들어 다음과 같이 비교할 수 있습니다. 나머지 ID도 해당 이미지 이름을 사용합니다.

```xml
<material>
  <diffuse>1 1 1 1</diffuse>
  <pbr>
    <metal>
      <albedo_map>aruco/aruco_id0.png</albedo_map>
    </metal>
  </pbr>
</material>
```

## 근거와 확인 부탁드리는 점

- [재질 생성 코드](https://github.com/MOSW626/istech-it-arena/blob/d61c5db9252cedfbc163cd044a47671df91e1660/track/track_gen.py#L1727-L1744)
- [실제 PNG 디렉터리](https://github.com/MOSW626/istech-it-arena/tree/d61c5db9252cedfbc163cd044a47671df91e1660/track/output_final/aruco)
- [SDFormat 1.8 material 명세](https://sdformat.org/spec/1.8/material/)

1. 생성기의 `albedo_map` 상대경로를 배포 구조에 맞게 수정할 수 있을까요?
2. 해당 Ogre2 환경에서 기본 재질 색을 명시하는 것이 맞는지 확인 부탁드립니다. 필요하다면 권장 렌더러·재질 설정을 안내받고 싶습니다.
3. 배포 전에 PNG 존재 확인 외에 실제 RGB에서 네 ID가 나타나는지도 간단히 대조할 수 있을까요?

이번 정면 대조에서는 PNG 사전·ID·상자 앞면 UV를 변경하지 않고 네 ID가 검출됐으므로, 사전 오류나 좌우 반전을 추가 결함으로 주장하지 않습니다. 또한 이 결과는 주행 속도·시야각·가림을 포함한 실차 인식 보장이 아닙니다.
