**어떤 파일에서**

`track/output_final/world.sdf`의 `surface_main_*`·`grid_slot_0`~`grid_slot_5`, `track/track_gen.py:write_sdf()`

**무엇이 이상한가요**

출발 그리드의 시각 형상이 노면보다 낮게 생성되어, 위에서 보면 노면에 가려지는 것을 확인했습니다. 노면 표시용 높이 오프셋의 의도와 적용값을 확인 부탁드립니다.

**환경**

- 확인 버전: `v2026.08.31` / `d61c5db9252cedfbc163cd044a47671df91e1660` (등록 전 최신 `main`과 동일함을 재확인)
- Windows / WSL Ubuntu 24.04.4 LTS / ROS 2 Jazzy / Gazebo Sim 8.11.0

## 확인한 결과

| 형상 | 중심 z [m] | 두께 [m] | 상단 z [m] |
|---|---:|---:|---:|
| 본선 노면 | 0.0015 | 0.0030 | 0.0030 |
| 그리드 표시 6개 | 0.0012 | 0.0010 | 0.0017 |

각 그리드의 평면 영역도 모두 노면 안에 포함됩니다. 표시 상단이 노면 상단보다 **1.3 mm 낮으므로** 깊이 검사에서 가려지는 배치입니다. 그리드에는 collision이 없습니다.

## 읽기 전용 재현

릴리스 ZIP을 푼 디렉터리에서 실행할 수 있습니다. 해당 파일은 모델·visual의 추가 pose가 없거나 0인 상자 형상입니다.

```bash
python3 -B - <<'PY'
import xml.etree.ElementTree as ET
links = ET.parse("output_final/world.sdf").findall(".//link")
def top(link):
    z = float(link.findtext("pose").split()[2])
    height = float(link.findtext("visual/geometry/box/size").split()[2])
    return round(z + height / 2, 7)
road = next(link for link in links
            if link.get("name", "").startswith("surface_main_"))
print("road_top_m:", top(road))
for link in links:
    if link.get("name", "").startswith("grid_slot_"):
        print(link.get("name"), "top_m:", top(link),
              "collision_count:", len(link.findall("collision")))
PY
```

노면 상단은 0.0030 m, 여섯 그리드 상단은 모두 0.0017 m, collision 수는 모두 0입니다.

- [노면 높이 생성](https://github.com/MOSW626/istech-it-arena/blob/d61c5db9252cedfbc163cd044a47671df91e1660/track/track_gen.py#L1651-L1654)
- [그리드 높이 생성](https://github.com/MOSW626/istech-it-arena/blob/d61c5db9252cedfbc163cd044a47671df91e1660/track/track_gen.py#L1681-L1691)
- [배포 SDF의 첫 그리드](https://github.com/MOSW626/istech-it-arena/blob/d61c5db9252cedfbc163cd044a47671df91e1660/track/output_final/world.sdf#L14982-L14989)

기존 전체 트랙 사진은 출발 구역과 높이 차이를 보여주기에 충분하지 않아 첨부하지 않았습니다. 높이를 임의 수정한 화면을 원본 증상처럼 제시하지도 않았습니다.

## 확인 부탁드리는 점

1. 표시를 노면 바로 위에 두려는 의도라면, 중심 z를 `road_top + 작은 간격 + 표시 두께/2`로 산정하는 방향이 맞을까요?
2. 슬롯의 XY 위치·크기와 collision 없는 현재 구조는 유지하면서 여섯 표시가 보이도록 조정할 수 있을지 검토 부탁드립니다.
