"""재생 발행 주기와 독립적으로 출력/진단만 수집하는 ROS executor."""
from collections import Counter, defaultdict
import threading
import time


def sequence_coverage(rows, completed):
    """종료 전 스냅샷까지의 연속 번호를 검사한다. 이후 콜백은 별도로 센다."""
    observed = defaultdict(Counter)
    for row in rows:
        observed[row['node']+'/'+row['callback']][row['sequence']] += 1
    result = {}
    for name, count in completed.items():
        values = observed[name]
        missing = [i for i in range(1, count+1) if i not in values]
        duplicates = sum(n-1 for i, n in values.items() if 1 <= i <= count)
        invalid = sum(n for i, n in values.items() if i < 1)
        result[name] = dict(expected_through_snapshot=count, missing=len(missing),
            first_missing=missing[:10], duplicates=duplicates, invalid=invalid,
            after_snapshot=sum(n for i, n in values.items() if i > count),
            complete=not missing and not duplicates and not invalid)
    return result


class ReplayObserver:
    """제어/센서 발행 없음. 전용 스레드만 executor를 돌리며 오류는 호출자에게 전파."""
    def __init__(self, node):
        from rclpy.executors import SingleThreadedExecutor
        self.node = node
        self.executor = SingleThreadedExecutor(context=node.context)
        self.executor.add_node(node)
        self.lock = threading.Lock()
        self.rows = defaultdict(list)
        self.halt = threading.Event()
        self.error = None
        self.thread = threading.Thread(target=self._run, name='replay-observer', daemon=True)
        self.started = False

    def record(self, key, row):
        with self.lock:
            self.rows[key].append(row)

    def snapshot(self):
        with self.lock:
            return {key: list(rows) for key, rows in self.rows.items()}

    def check(self):
        if self.error is not None:
            raise RuntimeError('Replay observer callback failed') from self.error

    def _run(self):
        try:
            while not self.halt.is_set():
                self.executor.spin_once(timeout_sec=.02)
        except Exception as error:
            self.error = error

    def start(self):
        self.thread.start()
        self.started = True

    def drain_through(self, completed, timeout=2.):
        deadline = time.monotonic()+timeout
        while True:
            self.check()
            coverage = sequence_coverage(self.snapshot().get('timing', []), completed)
            if coverage and all(v['complete'] for v in coverage.values()):
                return coverage
            if time.monotonic() >= deadline:
                return coverage
            self.halt.wait(.02)

    def close(self):
        self.halt.set()
        if self.started:
            self.thread.join(timeout=3.)
            if self.thread.is_alive():
                raise RuntimeError('Replay observer did not stop')
        self.executor.shutdown(timeout_sec=1.)
        self.executor.remove_node(self.node)
        self.node.destroy_node()
        self.check()
